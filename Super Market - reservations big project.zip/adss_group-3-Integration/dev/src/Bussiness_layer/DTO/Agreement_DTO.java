package Bussiness_layer.DTO;


import Bussiness_layer.Passive_objects.Supplier;

public class Agreement_DTO {

    private Integer product_id;
    private int supplier_id;
    private Double prod_price;
    private Integer discount_thres;
    private Double discount_percent;

    public Agreement_DTO(Integer product_id, int supplier_id, Double prod_price, Integer discount_thres, Double discount_percent) {
        this.product_id = product_id;
        this.supplier_id = supplier_id;
        this.prod_price = prod_price;
        this.discount_thres = discount_thres;
        this.discount_percent = discount_percent;
    }

    public Integer getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Integer product_id) {
        this.product_id = product_id;
    }

    public int getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }

    public Double getProd_price() {
        return prod_price;
    }

    public void setProd_price(Double prod_price) {
        this.prod_price = prod_price;
    }

    public Integer getDiscount_thres() {
        return discount_thres;
    }

    public void setDiscount_thres(Integer discount_thres) {
        this.discount_thres = discount_thres;
    }

    public Double getDiscount_percent() {
        return discount_percent;
    }

    public void setDiscount_percent(Double discount_percent) {
        this.discount_percent = discount_percent;
    }
}
