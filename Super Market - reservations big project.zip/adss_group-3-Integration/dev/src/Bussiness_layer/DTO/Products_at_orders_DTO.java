package Bussiness_layer.DTO;

import java.util.Date;

public class Products_at_orders_DTO {

    private int sid;
    private int store_num;
    private Date date;
    private int product_id;
    private int amount;
    private double price_per_unit;

    public Products_at_orders_DTO(int sid,
                                  int store_num,
                                  Date date,
                                  int product_id,
                                  int amount,double price_per_unit) {
        this.sid = sid;
        this.store_num = store_num;
        this.date = date;
        this.product_id = product_id;
        this.amount = amount;
        this.price_per_unit=price_per_unit;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getStore_num() {
        return store_num;
    }

    public void setStore_num(int store_num) {
        this.store_num = store_num;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public double getPrice_per_unit() {
        return price_per_unit;
    }

    public void setPrice_per_unit(double price_per_unit) {
        this.price_per_unit = price_per_unit;
    }
}
