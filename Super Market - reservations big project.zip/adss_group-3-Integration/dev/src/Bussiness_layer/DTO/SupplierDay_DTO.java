package Bussiness_layer.DTO;

public class SupplierDay_DTO {
    int sid;
    int supplyDay;

    public SupplierDay_DTO(int sid, int supplyDay) {
        this.sid = sid;
        this.supplyDay = supplyDay;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getSupplyDay() {
        return supplyDay;
    }

    public void setSupplyDay(int supplyDay) {
        this.supplyDay = supplyDay;
    }
}
