package Bussiness_layer.DTO;

import Bussiness_layer.DAO.Site_DAO;
import Bussiness_layer.Passive_objects.Order;
import Bussiness_layer.Passive_objects.Site;
import Bussiness_layer.Passive_objects.Store;
import Bussiness_layer.Passive_objects.Supplier;

import java.util.Date;

public class  Order_DTO {

    private int sid;
    private int store_num;
    private Date time;
    private int start_handle_after_days;


    public Order_DTO(int sid, int store_num, Date time, int start_handle_after_days) {
        this.sid = sid;
        this.store_num = store_num;
        this.time = time;
        this.start_handle_after_days=start_handle_after_days;
    }

    public int getStart_handle_after_days() {
        return start_handle_after_days;
    }

    public void setStart_handle_after_days(int start_handle_after_days) {
        this.start_handle_after_days = start_handle_after_days;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getStore_num() {
        return store_num;
    }

    public void setStore_num(int store_num) {
        this.store_num = store_num;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Order toOrderObject(Supplier supplier){
        /*
        * The store object needs more information
        * */
        return new Order(supplier.getSid(), getStore_num(), time,0, new Site(null, null, null, null), null);

    }
}