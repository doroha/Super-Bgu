package Bussiness_layer.DTO;

import java.util.Date;

public class CancellationApproval_DTO {
    private int sid;
    private int store_num;
    private Date time;
    private int approvedByStoreKeeper;
    private int approvedByTransportManager;
    private int approvedByHrManager;

    public CancellationApproval_DTO(int sid, int store_num, Date time, int approvedByStoreKeeper, int approvedByTransportManager, int approvedByHrManager) {
        this.sid = sid;
        this.store_num = store_num;
        this.time = time;
        this.approvedByStoreKeeper = approvedByStoreKeeper;
        this.approvedByTransportManager = approvedByTransportManager;
        this.approvedByHrManager = approvedByHrManager;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getStore_num() {
        return store_num;
    }

    public void setStore_num(int store_num) {
        this.store_num = store_num;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public int getApprovedByStoreKeeper() {
        return approvedByStoreKeeper;
    }

    public void setApprovedByStoreKeeper(int approvedByStoreKeeper) {
        this.approvedByStoreKeeper = approvedByStoreKeeper;
    }

    public int getApprovedByTransportManager() {
        return approvedByTransportManager;
    }

    public void setApprovedByTransportManager(int approvedByTransportManager) {
        this.approvedByTransportManager = approvedByTransportManager;
    }

    public int getApprovedByHrManager() {
        return approvedByHrManager;
    }

    public void setApprovedByHrManager(int approvedByHrManager) {
        this.approvedByHrManager = approvedByHrManager;
    }
}
