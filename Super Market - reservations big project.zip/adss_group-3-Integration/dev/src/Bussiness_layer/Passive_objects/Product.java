package Bussiness_layer.Passive_objects;

public class Product {
    private int id;
    private int weight;
    private String name;
    private int stock_amount;
    private int shelf_amount;
    private int last_sub_category;
    private int minimal_amount;
    private String location;
    private int storeNumber;
    private String producer;
    private int selling_cost;
    private int discount_cost;
    private String end_discount;

    public Product(int id, int weight, String name, int stock_amount, int shelf_amount, int last_sub_category, int minimal_amount,
                   String location, int storeNumber, String producer, int selling_cost, int discount_cost, String end_discount) {
        this.id = id;
        this.weight = weight;
        this.name = name;
        this.stock_amount = stock_amount;
        this.shelf_amount = shelf_amount;
        this.last_sub_category = last_sub_category;
        this.minimal_amount = minimal_amount;
        this.location = location;
        this.storeNumber = storeNumber;
        this.producer = producer;
        this.selling_cost = selling_cost;
        this.discount_cost = discount_cost;
        this.end_discount = end_discount;
    }

    public int getWeight() {
        return weight;
    }

    public int getId() {
        return id;
    }

    public int getStock_amount() {
        return stock_amount;
    }

    public void setStock_amount(int stock_amount) {
        this.stock_amount = stock_amount;
    }

    public int getShelf_amount() {
        return shelf_amount;
    }

    public void setShelf_amount(int shelf_amount) {
        this.shelf_amount = shelf_amount;
    }

    public int getLast_sub_category() {
        return last_sub_category;
    }

    public int getDiscount_cost() {
        return discount_cost;
    }

    public void setDiscount_cost(int discount_cost) {
        this.discount_cost = discount_cost;
    }

    public int getSelling_cost() {
        return selling_cost;
    }

    public int getStoreNumber() {
        return storeNumber;
    }

    public String getName() {return name;}

    public String getLocation() {
        return location;
    }

    public String getProducer() {
        return producer;
    }

    public int getMinimal_amount() {
        return minimal_amount;
    }

    public String getEnd_discount() {
        return end_discount;
    }

    public String to_string()
    {
        String result = "";
        result = result + " PID: " + this.getId()+ ", Name: "+this.getName()+", Last Category ID: "+this.getLast_sub_category()+", Producer: "+this.getProducer()+"\n\t"+
                "Store ID: "+this.getStoreNumber()+ ", Shelf amount: "+this.getShelf_amount()+", Stock amount: "+this.getStock_amount()+", Shelf location: "+this.getLocation()+"\n\t"+
                "Selling cost: "+this.getSelling_cost()+ ", Discount percentage: " + this.getDiscount_cost() + ", End Discount: " +
                this.getEnd_discount() + ", Minimal amount: " + this.getMinimal_amount();
        return result;
    }

    public String short_to_string()
    {
        String result = "";
        result = result + " PID: " + this.getId()+ ", Name: "+this.getName()+", Last Category ID: "+this.getLast_sub_category()+", Producer: "+this.getProducer();
        return result;
    }

    public void setEnd_discount(String end_discount) {
        this.end_discount = end_discount;
    }
}
