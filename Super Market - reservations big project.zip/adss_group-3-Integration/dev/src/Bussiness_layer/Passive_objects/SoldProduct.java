package Bussiness_layer.Passive_objects;

import java.util.Objects;

public class SoldProduct {

    private int receipt;
    private int PID;
    private int storeNumber;
    private int buyPrice;
    private int sellPrice;
    private int amount;
//
    public SoldProduct(int receipt, int PID, int storeNumber, int buyPrice, int sellPrice, int amount) {
        this.receipt = receipt;
        this.PID = PID;
        this.storeNumber = storeNumber;
        this.buyPrice = buyPrice;
        this.sellPrice = sellPrice;
        this.amount = amount;
    }

    public SoldProduct(int PID, int storeNumber, int buyPrice, int sellPrice, int amount) {
        this.PID = PID;
        this.storeNumber = storeNumber;
        this.buyPrice = buyPrice;
        this.sellPrice = sellPrice;
        this.amount = amount;
    }

    public int getPID() {
        return PID;
    }

    public int getStoreNumber() {
        return storeNumber;
    }

    public int getBuyPrice() {
        return buyPrice;
    }

    public int getSellPrice() {
        return sellPrice;
    }

    public int getAmount() {
        return amount;
    }

    public String to_string()
    {
        String result = "";
        result = result + " PID: " + this.getPID()+ ", Store: "+this.getStoreNumber()+"\n\t"+
                "Buy price: "+this.getBuyPrice()+ ", Sell price: "+this.getSellPrice()+", amount: "+this.getAmount();
        return result;
    }

    @Override
    public boolean equals(Object o) {
        SoldProduct that = (SoldProduct) o;
        return PID == that.PID &&
                storeNumber == that.storeNumber &&
                buyPrice == that.buyPrice &&
                sellPrice == that.sellPrice &&
                amount == that.amount;
    }

    @Override
    public int hashCode() {
        return Objects.hash(PID, storeNumber, buyPrice, sellPrice, amount);
    }
}
