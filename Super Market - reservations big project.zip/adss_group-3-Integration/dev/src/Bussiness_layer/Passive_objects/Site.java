package Bussiness_layer.Passive_objects;

public class Site {
    private String address;
    private String phone;
    private String areaCode;
    private String contactName;

    public Site(String address, String phone, String areaCode, String contactName) {
        this.address = address;
        this.phone = phone;
        this.areaCode = areaCode;
        this.contactName = contactName;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public String getContactName() {
        return contactName;
    }
}
