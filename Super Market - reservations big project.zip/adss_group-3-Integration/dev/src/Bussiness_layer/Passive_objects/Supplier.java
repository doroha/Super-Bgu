package Bussiness_layer.Passive_objects;

enum Routine
{
    WEEKLY_SCHEDULE, ON_DEMAND, NEEDS_TRANSPORT;
}

public class Supplier {

    private int sid;
    private int bank_acount;
    private String payment_terms;
    private int delivery_routine;
    private String site_id;

    public Supplier(int sid, int bank_acount, String payment_terms, int delivery_routine, String site_id) {
        this.sid = sid;
        this.bank_acount = bank_acount;
        this.payment_terms = payment_terms;
        this.delivery_routine = delivery_routine;
        this.site_id = site_id;
    }

    public int getSid() {
        return sid;
    }

    public int getBank_acount() {
        return bank_acount;
    }

    public String getPayment_terms() {
        return payment_terms;
    }

    public int getDelivery_routine() {
        return delivery_routine;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }


    @Override
    public String toString() {
        return "Supplier{" +
                "sid=" + sid +
                ", bank_acount=" + bank_acount +
                ", payment_terms='" + payment_terms + '\'' +
                ", delivery_routine=" + delivery_routine +
                ", site_id=" +site_id+
                '}';
    }
}
