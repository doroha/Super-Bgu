package Bussiness_layer.Passive_objects;

public class DamagedProduct {
    private int pid;
    private int store_num;
    private String location;
    private int amount;

    public DamagedProduct(int pid, int store_num, String location, int amount) {
        this.pid = pid;
        this.store_num = store_num;
        this.location = location;
        this.amount = amount;
    }

    public int getPid() {
        return pid;
    }

    public int getStore_num() {
        return store_num;
    }

    public String getLocation() {
        return location;
    }

    public int getAmount() {
        return amount;
    }
    public String to_string()
    {
        String result = "";
        result = "PID: "+this.getPid()+", Store_num: "+this.getStore_num()+", location: "+this.getLocation()+", Amount: "+this.getAmount()+"\n";
        return result;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DamagedProduct that = (DamagedProduct) o;
        return pid == that.pid &&
                store_num == that.store_num &&
                amount == that.amount &&
                location.equals(that.location);
    }

}
