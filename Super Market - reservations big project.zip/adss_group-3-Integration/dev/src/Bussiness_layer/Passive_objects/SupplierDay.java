package Bussiness_layer.Passive_objects;

public class SupplierDay {
    private int sid;
    private int supplyDay;

    public SupplierDay(int sid, int supplyDay) {
        this.sid = sid;
        this.supplyDay = supplyDay;
    }

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getSupplyDay() {
        return supplyDay;
    }

}
