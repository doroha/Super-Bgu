package Bussiness_layer.Passive_objects;

public class CancellationOrder {
    Order order;
    private boolean approvedByStoreKeeper;
    private boolean approvedByTransportManager;
    private boolean approvedByHrManager;

    public CancellationOrder(Order order, boolean approvedByStoreKeeper, boolean approvedByTransportManager, boolean approvedByHrManager) {
        this.order = order;
        this.approvedByStoreKeeper = approvedByStoreKeeper;
        this.approvedByTransportManager = approvedByTransportManager;
        this.approvedByHrManager = approvedByHrManager;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public boolean isApprovedByStoreKeeper() {
        return approvedByStoreKeeper;
    }

    public void setApprovedByStoreKeeper(boolean approvedByStoreKeeper) {
        this.approvedByStoreKeeper = approvedByStoreKeeper;
    }

    public boolean isApprovedByTransportManager() {
        return approvedByTransportManager;
    }

    public void setApprovedByTransportManager(boolean approvedByTransportManager) {
        this.approvedByTransportManager = approvedByTransportManager;
    }

    public boolean isApprovedByHrManager() {
        return approvedByHrManager;
    }

    public void setApprovedByHrManager(boolean approvedByHrManager) {
        this.approvedByHrManager = approvedByHrManager;
    }
}
