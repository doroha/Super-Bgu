package Bussiness_layer.Passive_objects;

public class ProductAtOrder {
    private Order order;
    private Integer pid;
    private Integer amount;
    private Double price_per_unit;

    public ProductAtOrder(Order order, Integer amount, Integer pid, Double price_per_unit) {
        this.order = order;
        this.pid=pid;
        this.amount = amount;
        this.price_per_unit=price_per_unit;
    }

    public ProductAtOrder(Integer amount, Integer pid, Double price_per_unit) {
        this.pid=pid;
        this.amount = amount;
        this.price_per_unit=price_per_unit;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public int getPid() {
        return pid;
    }

    public Double getPrice_per_unit() {
        return price_per_unit;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }
}
