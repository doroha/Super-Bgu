package Bussiness_layer.Passive_objects;

public class User {
    private String username;
    private String password;
    private int ssn;
    private int permissions;

    public User(String username, int ssn, String password, int permissions) {
        this.username = username;
        this.password = password;
        this.ssn = ssn;
        this.permissions = permissions;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getSsn() {
        return ssn;
    }

    public int permissionLevel() {
        return permissions;
    }
}
