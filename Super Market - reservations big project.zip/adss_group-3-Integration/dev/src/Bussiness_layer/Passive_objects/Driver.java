package Bussiness_layer.Passive_objects;

public class Driver {

    private int licenseType;
    private int occupied;
    private Worker worker;

    public Driver(int licenseType, int occupied, Worker worker) {
        this.worker = worker;
        this.licenseType = licenseType;
        this.occupied = occupied;
    }

    public Worker getWorker() { return worker; }

    public int getSsn() {
        return worker.getSsn();
    }

    public int getOccupied() {
        return occupied;
    }

    public int getLicenseType() {
        return licenseType;
    }
}
