package Bussiness_layer.Passive_objects;


public class Availability {
    private int ssn;
    private int day1;
    private int day2;
    private int day3;
    private int day4;
    private int day5;
    private int day6;
    private int day7;

    public Availability(int ssn, int day1, int day2, int day3, int day4, int day5, int day6, int day7){
        this.ssn =ssn;
        this.day1=day1;
        this.day2=day2;
        this.day3=day3;
        this.day4=day4;
        this.day5=day5;
        this.day6=day6;
        this.day7=day7;
    }


    public int[] getDays() {
        return new int[]{this.get_day1(), this.get_day2(), this.get_day3(), this.get_day4(), this.get_day5(), this.get_day6(), this.get_day7()};
    }

    public String toString() {
        return "worker ssn: " + this.getSsn() + " work in day number 1: " + this.get_day1() + " work in day number 2: " + this.get_day2() + " work in day number 3: " + this.get_day3() + " work in day number 4: " + this.get_day4() + " work in day number 5: " + this.get_day5() + " work in day number 6: " + this.get_day6() + " work in day number 7: " + this.get_day7();
    }

    public void setDayX(int x, int cons) {
        switch (x) {
            case 1:
                setDay1(cons);
                break;
            case 2:
                setDay2(cons);
                break;
            case 3:
                setDay3(cons);
                break;
            case 4:
                setDay4(cons);
                break;
            case 5:
                setDay5(cons);
                break;
            case 6:
                setDay6(cons);
                break;
            case 7:
                setDay7(cons);
                break;
        }
    }

    public int getSsn() {
        return this.ssn;
    }

    public int get_day1() {return this.day1; }

    public int get_day2() {
        return this.day2;
    }

    public int get_day3() {
        return this.day3;
    }

    public int get_day4() {
        return this.day4;
    }

    public int get_day5() {
        return this.day5;
    }

    public int get_day6() {
        return this.day6;
    }

    public int get_day7() {
        return this.day7;
    }

    public void setDay1(int day1) {
        this.day1 = day1;
    }

    public void setDay2(int day2) {
        this.day2 = day2;
    }

    public void setDay3(int day3) {
        this.day3 = day3;
    }

    public void setDay4(int day4) {
        this.day4 = day4;
    }

    public void setDay5(int day5) {
        this.day5 = day5;
    }

    public void setDay6(int day6) {
        this.day6 = day6;
    }

    public void setDay7(int day7) {
        this.day7 = day7;
    }
}
