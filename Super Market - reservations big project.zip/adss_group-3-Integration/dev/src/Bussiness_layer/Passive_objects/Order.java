package Bussiness_layer.Passive_objects;


import java.util.Date;
import java.util.List;

public class Order
{
    private List<Pair<Product, Integer>> order;
    private int store_id;
    private int supplier_id;
    private Date order_time;
    private Site destination;
    private int routeIdx;

    // Takes a list of pairs, <ProductID, AmountNeeded>
    public Order(int supplier_id, int store_id, Date order_time, int routeIdx, Site destination, List<Pair<Product, Integer>> order) {
        this.supplier_id = supplier_id;
        this.order_time = order_time;
        this.store_id = store_id;
        this.order = order;
        this.destination = destination;
        this.routeIdx = routeIdx;
    }

    public List<Pair<Product, Integer>> getOrder() {
        return order;
    }

    public int getStoreId() {
        return store_id;
    }

    public int getSupplierId() {
        return supplier_id;
    }

    public Date getTime() {
        return order_time;
    }

    public int getTotalWeight() {
        int total_weight = 0;
        for (Pair<Product, Integer> prod_amount : order) {
            total_weight += prod_amount.getValue() * prod_amount.getKey().getWeight();
        }
        return total_weight;
    }

    @Override
    public String toString() {
        if(order==null)
            return "";
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Supplier id: %s, Store id: %s, Date: %s\n", supplier_id, store_id, order_time.toString()));
        int total_weight = 0;
        for (Pair<Product, Integer> prod_amount : order) {
            total_weight += prod_amount.getValue() * prod_amount.getKey().getWeight();
            sb.append(String.format("Product id: %d, Amount: %d, Weight: %d\n", prod_amount.getKey().getId(), prod_amount.getValue(), prod_amount.getKey().getWeight()));
        }
        sb.append(String.format("Total weight: %d", total_weight));
        return sb.toString();
    }

    public int getRouteIdx() {
        return routeIdx;
    }

    public Site getDestination() {
        return destination;
    }

    /*@Override
    public int compareTo(Order o) {
        boolean cond = o.store_id == this.store_id && o.supplier_id == this.supplier_id;
        if(cond && (o.order_time.compareTo(this.order_time) == 0))
            return 0;
        if(this.order_time.after(o.order_time))
            return 1;
        return -1;
    }*/
}
