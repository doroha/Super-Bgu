package Bussiness_layer.Passive_objects;

import java.util.Date;

public class Transport {
    private Date beganAt;
    private String truckId;
    private int dssn;
    private Site origin;

    public Transport(Date beganAt, String truckId, int dssn, Site origin) {
        this.beganAt = beganAt;
        this.truckId = truckId;
        this.dssn = dssn;
        this.origin = origin;
    }

    public Date getBeganAt() {
        return beganAt;
    }

    public String getTruckId() {
        return truckId;
    }

}
