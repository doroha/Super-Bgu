package Bussiness_layer.Passive_objects;

public class BuyPrice {
    private int orderNumber;
    private int storeNumber;
    private int PID;
    private int buyPrice;
    private int currentAmount;

    public BuyPrice(int storeNumber, int PID, int buyPrice, int currentAmount) {
        this.storeNumber = storeNumber;
        this.PID = PID;
        this.buyPrice = buyPrice;
        this.currentAmount = currentAmount;
    }

    public BuyPrice(int orderNumber, int storeNumber, int PID, int buyPrice, int currentAmount) {
        this.orderNumber = orderNumber;
        this.storeNumber = storeNumber;
        this.PID = PID;
        this.buyPrice = buyPrice;
        this.currentAmount = currentAmount;
    }

    public int getOrderNumber() {
        return orderNumber;
    }

    public int getStoreNumber() {
        return storeNumber;
    }

    public int getPID() {
        return PID;
    }

    public int getBuyPrice() {
        return buyPrice;
    }

    public int getCurrentAmount() {
        return currentAmount;
    }

    public void setCurrentAmount(int currentAmount) {
        this.currentAmount = currentAmount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BuyPrice buyPrice1 = (BuyPrice) o;
        return storeNumber == buyPrice1.storeNumber &&
                PID == buyPrice1.PID &&
                buyPrice == buyPrice1.buyPrice &&
                currentAmount == buyPrice1.currentAmount;
    }

}
