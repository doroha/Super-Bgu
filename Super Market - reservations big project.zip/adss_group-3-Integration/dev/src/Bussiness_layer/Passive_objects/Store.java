package Bussiness_layer.Passive_objects;

public class Store {

        private int id;
        private String site_id;

        public Store(int id, String site_id) {
            this.id = id;
            this.site_id = site_id;
        }

        public String getAddress() {
            return this.site_id;
        }

        public int getID() {
            return this.id;
        }

        public void setAddress(String _address) {
            this.site_id = _address;
        }

        public void setID(int id) {
            this.id = id;
        }

        public String toString() {
            return "Store ID: " + this.id + " address: " + this.site_id;
        }
}