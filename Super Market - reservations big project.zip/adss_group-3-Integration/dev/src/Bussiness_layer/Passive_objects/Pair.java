package Bussiness_layer.Passive_objects;

public class Pair<F, S>  {
    private F f;
    private S s;

    public  Pair( F f, S s ) {
        this.f = f;
        this.s = s;
    }

    public F getKey() {
        return f;
    }

    public S getValue() {
        return s;
    }

}