package Bussiness_layer.Passive_objects;

public class ProductToOrder {

    private int pid;
    private int amount;
    private double pricePerUnit;
    private int storeNum;

    public ProductToOrder( int pid,int storeNum, int amount, double pricePerUnit) {

        this.pid = pid;
        this.amount = amount;
        this.pricePerUnit = pricePerUnit;
        this.storeNum=storeNum;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public double getPricePerUnit() {
        return pricePerUnit;
    }

    public int getStoreNum() {
        return storeNum;
    }

}
