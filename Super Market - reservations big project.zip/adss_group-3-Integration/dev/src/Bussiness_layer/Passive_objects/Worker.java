package Bussiness_layer.Passive_objects;

public class Worker {
    private int ssn;
    private String fname;
    private String lname;
    private int bankAccount;
    private String startDate;
    private String conditions;
    private String job;
    private int storeId;
    private int salary;

    public Worker(int id, String fname, String ln, int bA, String startDay, String c, int s, int sid, String j) {
        this.ssn = id;
        this.fname = fname;
        this.lname = ln;
        this.bankAccount = bA;
        this.conditions = c;
        this.job = j;
        this.salary = s;
        this.startDate = startDay;
        this.storeId = sid;
    }

    public int getSsn() {
        return ssn;
    }

    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public int getBankAccount() {
        return bankAccount;
    }

    public int getSalsry() {
        return salary;
    }

    public int getStoreId() {
        return storeId;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getConditions() {
        return conditions;
    }

    public String getJob() {
        return job;
    }

    public String toString() {
        return fname + " " + lname + " " + job + " ";
    }
}

