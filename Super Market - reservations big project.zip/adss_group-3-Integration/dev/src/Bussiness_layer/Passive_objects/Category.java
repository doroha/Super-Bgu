package Bussiness_layer.Passive_objects;

import java.util.LinkedList;
import java.util.List;

public class Category {
    //private Category father;//?
    private int fatherID;
    private List<Category> sons;
    private int ID;
    private String name;
    private int my_discount;
    private int best_discount;
    //private Date my_date_discount;
    private String my_date_discount;

    public Category(int fatherID, int ID, String name) {
        //this.father = father;
        this.fatherID = fatherID;
        this.sons = new LinkedList<Category>();
        this.ID = ID;
        this.name = name;
        this.my_discount = 0;
        this.best_discount = 0;
        this.my_date_discount = "12/12/12";
    }
    // For the DB constructor in the CategoDAO
    public Category(int ID, int fatherID, String name, int my_discount, int best_discount, String my_date_discount) {
        this.fatherID = fatherID;
        this.sons = new LinkedList<Category>();
        this.ID = ID;
        this.name = name;
        this.my_discount = my_discount;
        this.best_discount = best_discount;
        this.my_date_discount = my_date_discount;
    }

    public int getFatherID() {
        return fatherID;
    }

    public List<Category> getSons() {
        return sons;
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public int getMy_discount() {
        return my_discount;
    }

    public int getBest_discount() {
        return best_discount;
    }

    public String getMy_date_discount() {
        return my_date_discount;
    }

    public void setMy_discount(int my_discount) {
        this.my_discount = my_discount;
    }

    public void setBest_discount(int best_discount) {
        this.best_discount = best_discount;
    }

    public void setMy_date_discount(String my_date_discount) {
        this.my_date_discount = my_date_discount;
    }

    public void setSons(List<Category> sons) {
        this.sons = sons;
    }

    public void insertson(Category son)
    {
        if(!this.iscontain(son))
        {
            this.sons.add(son);
        }

    }

    public boolean iscontain(Category son)
    {
        for (Category each_son: sons)
        {
            if(each_son.getName().equals(son.getName()) && each_son.getID() == son.getID())
            {
                return true;
            }
        }
        return false;
    }

}
