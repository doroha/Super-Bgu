package Bussiness_layer.Passive_objects;

public class Agreement {
    private int pid;
    private Supplier supplier;
    private Double prod_price;
    private Integer discount_thres;
    private double discount_percent;

    public Agreement(int pid,
                     Supplier supplier,
                     double prod_price,
                     Integer discount_thres,
                     double discount_percent) {
        this.pid = pid;
        this.supplier = supplier;
        this.prod_price = prod_price;
        this.discount_thres = discount_thres;
        this.discount_percent = discount_percent;
    }


    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public double getProd_price() {
        return prod_price;
    }

    public Integer getDiscount_thres() {
        return discount_thres;
    }

    public double getDiscount_percent() {
        return discount_percent;
    }

}
