package Bussiness_layer.Passive_objects;
//package Passive_objects;

public class Shift {

    private int ssn;
    private String date;
    private int shift_type;

    public Shift(int ssn, String date, int shift_type) {
        this.date = date;
        this.ssn = ssn;
        this.shift_type = shift_type;
    }

    public String getDate() {
        return date.split(" ")[0];
    }

    public String getDateTime() {
        return date;
    }

    public int getSsn() {
        return this.ssn;
    }

    public int getShift_type() {
        return this.shift_type;
    }

    public void setId(int id) {
        this.ssn = id;
    }

    public String toString() {
        String day;
        if (this.shift_type == 1) {
            day = "morning";
        } else if (this.shift_type == 2) {
            day = "evening";
        } else {
            day = "full shift";
        }
        return "shift: " + this.ssn + " date: " + this.date + "shift type: " + this.shift_type + " " + day;
    }
}
