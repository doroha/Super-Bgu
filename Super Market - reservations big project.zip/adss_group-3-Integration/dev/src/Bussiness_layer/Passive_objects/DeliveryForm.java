package Bussiness_layer.Passive_objects;

import java.util.Date;

public class DeliveryForm {
    private Date beganAt;
    private String truckId;
    private int supplierId;
    private int storeId;
    private Date requestDate;

    public DeliveryForm(Date beganAt, String truckId, int supplierId, int storeId, Date requestDate) {

        this.beganAt = beganAt;
        this.truckId = truckId;
        this.supplierId = supplierId;
        this.storeId = storeId;
        this.requestDate = requestDate;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public int getStoreId() {
        return storeId;
    }

    public String getTruckId() {
        return truckId;
    }

    public Date getBeganAt() {
        return beganAt;
    }

    public int getSupplierId() {
        return supplierId;
    }

}
