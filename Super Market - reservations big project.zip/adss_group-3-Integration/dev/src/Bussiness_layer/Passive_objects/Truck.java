package Bussiness_layer.Passive_objects;

public class Truck {
    private String plateId;
    private int model;
    private int netWeight;
    private int maxWeight;
    public Truck(String plateId, int model, int netWeight, int maxWeight) {
        this.plateId = plateId;
        this.model = model;
        this.netWeight = netWeight;
        this.maxWeight = maxWeight;
    }

    public String getPlateId() {
        return plateId;
    }

    public int getModel() {
        return model;
    }

    public int getNetWeight() {
        return netWeight;
    }

    public int getMaxWeight() {
        return maxWeight;
    }
}
