package Bussiness_layer;

import java.util.Arrays;
import java.util.List;

public final class Config {
    public static int ssn_limit = 32767;

    public static final int TYPE_0_LICENSE_MAX_WEIGHT = 12000; // 12 tons
    public static final int TYPE_1_LICENSE_MAX_WEIGHT = 15000; // 15 tons
    public static final String timestamp_pattern = "yyyy-MM-dd HH:mm:ss";
    public static final int SAME_REGION_DELIVERY_TIME = 5000; // 5 seconds, we pretty fast these days.
    public static final List<String> validToShowTables = Arrays.asList("trucks", "drivers", "sites", "transports");
    public static final List<String> validAreas = Arrays.asList("T", "D", "M");
    public static final String dbFile = "./data.db";
    public static final String day_shift_start_time = "04:00:00";
    public static final String day_shift_end_time = "13:59:59";
    public static final String night_shift_start_time = "14:00:00";
    public static final String night_shift_end_time = "23:59:59";
    public static final int type_shift_no_shift = 0;
    public static final int type_shift_day_shift = 1;
    public static final int type_shift_night_shift = 2;
    public static final int type_shift_double_shift = 3;
    public static String logFile = "./logs";
    public static int seconds_per_day = 100;
}