package Bussiness_layer;

import Bussiness_layer.Passive_objects.Agreement;
import Persistent_layer.DatabaseManager;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

public class AutomaticOrdersHandler implements Runnable {

    private boolean shouldStop;
    private DatabaseManager dbManager;
    private Connection connection;
    private User_Handler mainHandler;
    private DaysThread dt;
    int day=1;


    public AutomaticOrdersHandler(DatabaseManager dbManager,User_Handler mainHandler, DaysThread dt) {
        this.dt = dt;
        shouldStop=false;
        this.mainHandler=mainHandler;
        this.dbManager=dbManager;
    }

    public synchronized void run() {
        try {
            Thread.sleep(1000);
            doOrders();
            while (!shouldStop) {
                try {
                    Thread.sleep(Config.seconds_per_day * 1000);
                    doOrders();
                    day = (dt.getDay()) % 7;
                } catch (InterruptedException e) {
                    shouldStop = true;
                    dbManager.getConn().close();
                }
            }
            System.out.println("Automatic Orders System has finished");
        } catch (Exception e) {}
    }
    private synchronized void doOrders(){

        int supDeliveryDay=0;
        if (day==7){ //do orders for 1'st day (sunday)
            supDeliveryDay=1;
        } else {
            supDeliveryDay=day+1;
        }
        //Assumption 1 : on routinely delivery every supplier supply 50 products for each product in the agreement
        //Assumption 2 : on routinely delivery the products are supplied to all the stores. (the supplier works with all the stores)

        //get supplier which should make delivery tomorrow, place the order today, they need to be prepared
        List<Integer> supplierList=mainHandler.getSidBySupplyDay(supDeliveryDay);

        //HashMap between supplier to his agreements
        HashMap<Integer,List<Agreement>> suppliersAgreemtnsHash=new HashMap<>();
        for (int i=0;i<supplierList.size();i++){
            suppliersAgreemtnsHash.put(supplierList.get(i),mainHandler.getSupplierAgreementsBySID(supplierList.get(i)));
        }
        connection=dbManager.getConn();
        for(Integer sid:suppliersAgreemtnsHash.keySet()){
            List<Agreement> suppliersAgreements=suppliersAgreemtnsHash.get(sid);
            for (Agreement agreement: suppliersAgreements){
                mainHandler.addRoutinelyAutomaticOrder(agreement);
            }
        }
    }
    public void stopExecution(){
        this.shouldStop=true;
    }
}

