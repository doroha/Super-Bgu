package Bussiness_layer;


import Bussiness_layer.DAO.*;
import Bussiness_layer.DTO.*;
import Bussiness_layer.Passive_objects.*;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;
import Persistent_layer.ResultSetPrinter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ObjectsContainer {

    private DatabaseManager dbManager;
    private Connection con;

    private static int agreementCount;
    private static int ordersCount;
    private static int productsAtOrdersCount;
    private static int suppliersCount;
    private static int supplyDayCount;

    //Suppliers
    private Supplier_DAO supplierDao;
    private Agreements_DAO agreementsDao;
    private Contacts_DAO contacts_dao;
    private Orders_DAO orders_dao;
    private ProductsAtOrders_DAO productsAtOrders_dao;
    private SupplierDay_DAO supplierDay_dao;
    private CancellationApproval_DAO cancellationApproval_dao;
    private SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);


    private static HashMap<Integer, Agreement> co_agreements;
    private static HashMap<Integer, Contact> co_contacts;
    private static HashMap<Integer, Store> co_stores;
    private static HashMap<Integer, Supplier> co_suppliers;
    private static ConcurrentHashMap<Integer, Order> co_orders;
    private static HashMap<Integer, ProductAtOrder> co_productsAtOrders;
    private static HashMap<SupplierDay, String> co_SuppliersBySupplyDay;
    private static HashMap<Order, CancellationOrder> co_CancellationOrderaApprovals;


    public ObjectsContainer(DatabaseManager dbmg) {
        this.dbManager = dbmg;
        co_agreements = new HashMap<>();
        co_contacts = new HashMap<>();
        co_stores = new HashMap<>();
        co_suppliers = new HashMap<>();
        co_orders = new ConcurrentHashMap<>();
        co_productsAtOrders = new HashMap<>();
        co_SuppliersBySupplyDay = new HashMap<>();
        co_CancellationOrderaApprovals = new HashMap<>();

        agreementCount = 0;
        ordersCount = 0;
        productsAtOrdersCount = 0;
        suppliersCount = 0;
        supplyDayCount = 0;

        supplierDao = new Supplier_DAO(dbmg);
        agreementsDao = new Agreements_DAO(dbmg);
        contacts_dao = new Contacts_DAO(dbmg);
        orders_dao = new Orders_DAO(dbmg);
        productsAtOrders_dao = new ProductsAtOrders_DAO(dbmg);
        supplierDay_dao = new SupplierDay_DAO(dbmg);
        cancellationApproval_dao = new CancellationApproval_DAO(dbmg);


        updateContainerWithSotres();
        updateContainerWithSuppliers();
        updateContainerWithAgreements();
        updateContainerWithContacts();
        updateContainerWithOrders();
        updateContainerWithSuppliersDays();
        updateContainerWithCancellationOrders();


    }


    //Dao SupplierCards
    public void addSupCard_Dao(Supplier_DTO sup_dto) {
        if (getSupplerFromContainer(sup_dto.getSid()) != null) {
            System.out.println("\nError: supplier with id " + sup_dto.getSid() + " already exist!\n");
        } else {
            supplierDao.Insert(sup_dto);
            //updating container on succsessfull insertion
            addSupplierToConatiner(new Supplier(sup_dto.getSid(),
                    sup_dto.getBank_acount(),
                    sup_dto.getPayment_terms(),
                    sup_dto.getDelivery_routine(),
                    sup_dto.getSite_id()));

        }
    }

    public void updateSupCard_Dao(Supplier_DTO sup_dto) {

        supplierDao.Update(sup_dto);
        //updating container after sucsesfull update in the db
        deleteSupplierFromContainer(sup_dto.getSid());
        addSupplierToConatiner(new Supplier(sup_dto.getSid(),
                sup_dto.getBank_acount(),
                sup_dto.getPayment_terms(),
                sup_dto.getDelivery_routine(),
                sup_dto.getSite_id()));

    }

    public void printAllSuppliers_Dao() {
        supplierDao.printSuppliers();
    }

    public void printSup_Dao(Supplier_DTO sup_dto) {
        supplierDao.Print(sup_dto);
    }

    public Supplier_DTO getSupCard_Dao(Supplier_DTO sup_dto) {
        return supplierDao.Get(sup_dto);
    }

    public void DeleteSupCard_Dao(Supplier_DTO sup_dto) {
        supplierDao.Delete(sup_dto);
        //delete supplier from container after deletion from db
        deleteSupplierFromContainer(sup_dto.getSid());
    }

    //Dao SuppliersDay
    public void InsertSupplyDay_Dao(SupplierDay_DTO supplierDay_dto) {
        if (!isExistSupplierDayContainer(new SupplierDay(supplierDay_dto.getSid(), supplierDay_dto.getSupplyDay()))) {
            supplierDay_dao.Insert(supplierDay_dto);
            addSupplierDayToContainer(new SupplierDay(supplierDay_dto.getSid(), supplierDay_dto.getSupplyDay()));
        }
    }

    public void DeleteSupplierDays_Dao(int sid) {
        supplierDay_dao.Delete(new SupplierDay_DTO(sid, -1));
        deleteSupplierDaysFromContainer(sid);
    }


    //Dao Agreements
    public void addSingleProdToAgre_Dao(Agreement_DTO agreement_dto) {
        agreementsDao.Insert(agreement_dto);
        //updating container after successfull addition
        addAgreementToContainer(new Agreement(agreement_dto.getProduct_id(),
                getSupplerFromContainer(agreement_dto.getSupplier_id()),
                agreement_dto.getProd_price(),
                agreement_dto.getDiscount_thres(),
                agreement_dto.getDiscount_percent()));

    }

    public void updateProductAtAgreement_Dao(Agreement_DTO agreement_dto) {
        agreementsDao.Update(agreement_dto);
        //updating container
        deleteAgreementFromContainer(agreement_dto.getProduct_id(), agreement_dto.getSupplier_id());
        addAgreementToContainer(new Agreement(agreement_dto.getProduct_id(),
                getSupplerFromContainer(agreement_dto.getSupplier_id()),
                agreement_dto.getProd_price(),
                agreement_dto.getDiscount_thres(),
                agreement_dto.getDiscount_percent()));


    }

    public void printAgreement_Dao(int sup_id) {
        agreementsDao.printAgreementsWithSupplier(sup_id);
    }

    public void deleteProdFromAgreement_Dao(Agreement_DTO agreement_dto) {
        agreementsDao.Delete(agreement_dto);
        //updating container
        deleteAgreementFromContainer(agreement_dto.getProduct_id(), agreement_dto.getSupplier_id());

    }

    public void printSupFullAgreement_Dao(int sup_id) {
        agreementsDao.printAgreementsWithSupplier(sup_id);
    }

    public Agreement_DTO getAgreementRecord_Dao(Agreement_DTO agreement_dto) {
        return agreementsDao.Get(agreement_dto);
    }

    public void printAllSuplierSupplyProduct_Dao(int pid) {
        agreementsDao.printSupplierByProduct(pid);
    }

    //   <<<Contacts Dao functions >>
    public void addNewContact_Dao(Contact_DTO contact_dto) {
        contacts_dao.Insert(contact_dto);
        //updating container
        Supplier_DTO supplier_dto = supplierDao.Get(new Supplier_DTO(contact_dto.getSid(), null, null, null, null));
        Supplier supplier = supplier_dto.toSupplierObject();
        addContactToContainer(contact_dto.toContactObject(supplier));
    }

    public void updateConatct_Dao(Contact_DTO contact_dto) {
        contacts_dao.Update(contact_dto);
        //updating container
        deleteContactFromContainer(contact_dto.getCid());
        addContactToContainer(new Contact(contact_dto.getCid(),
                contact_dto.getFirst_name(),
                contact_dto.getLast_name(),
                contact_dto.getPhone(),
                contact_dto.getEmail(),
                getSupplerFromContainer(contact_dto.getSid())));

    }

    public void deleteContact_Dao(Contact_DTO contact_dto) {
        contacts_dao.Delete(contact_dto);
        //updating container
        deleteContactFromContainer(contact_dto.getCid());
    }
    //   <<<Contacts Dao functions >>

    //   <<<Orders Dao functions >>
    public void addOrder_Dao(Order_DTO order_dto) {
        if(orders_dao.Insert(order_dto)){
            addOrderToContainer(new Order(order_dto.getSid(),order_dto.getStore_num(),order_dto.getTime(),order_dto.getStart_handle_after_days(),null,null));
        }
    }

    public void deleteOrder_Dao(Order_DTO order_dto) {
        orders_dao.Delete(order_dto);
        deleteOrderFromContainer(order_dto.getSid(), order_dto.getStore_num(), order_dto.getTime());
    }
    //   <<<Orders Dao functions >>

    //   <<<Products At Orders Dao functions >>
    public void addProductAtOrder_Dao(Products_at_orders_DTO prod_at_order_dto) {
        productsAtOrders_dao.Insert(prod_at_order_dto);
        //updating container
        addProductAtOrderToContainer(new ProductAtOrder(getOrderFromContainer(prod_at_order_dto.getSid(), prod_at_order_dto.getStore_num(), prod_at_order_dto.getDate()),
                prod_at_order_dto.getAmount(),
                prod_at_order_dto.getProduct_id(),
                prod_at_order_dto.getPrice_per_unit()));
    }

    public void updateProductAtOrder_Dao(Products_at_orders_DTO prod_at_order_dto) {

        productsAtOrders_dao.Insert(prod_at_order_dto);
        //updating container
        deleteProductAtOrderFromContainer(prod_at_order_dto.getSid(), prod_at_order_dto.getStore_num(), prod_at_order_dto.getDate(), prod_at_order_dto.getProduct_id());
        addProductAtOrderToContainer(new ProductAtOrder(getOrderFromContainer(prod_at_order_dto.getSid(), prod_at_order_dto.getStore_num(), prod_at_order_dto.getDate()),
                prod_at_order_dto.getAmount(),
                prod_at_order_dto.getProduct_id(),
                prod_at_order_dto.getPrice_per_unit()));
    }

    public void deleteProductAtOrder_Dao(Products_at_orders_DTO prod_at_order_dto) {
        productsAtOrders_dao.Delete(prod_at_order_dto);
        //updating container
        deleteProductAtOrderFromContainer(prod_at_order_dto.getSid(), prod_at_order_dto.getStore_num(), prod_at_order_dto.getDate(), prod_at_order_dto.getProduct_id());
    }

    public Products_at_orders_DTO getProductAtOrder_Dao(Products_at_orders_DTO dto_obj) {
        return productsAtOrders_dao.Get(dto_obj);
    }


    //------------------------ORDER CANCELLATION DAO--------------------//
    boolean storekeeperApproved;
    boolean transportManagerApproved;
    boolean hrManagerApproved;

    public void insertNewCancellationOrderApproval_Dao(CancellationApproval_DTO dto) {

        if (cancellationApproval_dao.Insert(dto)) { //insert successed
            fillRolesApprovments(dto);
            addOrderCancellationToContainer(getOrderFromContainer(dto.getSid(), dto.getStore_num(), dto.getTime()), storekeeperApproved, transportManagerApproved, hrManagerApproved);
        } else {
            System.out.println("cancel order faild due to wrong input, please try again");
        }
    }

    public void deleteOrderCancellarion_Dao(CancellationApproval_DTO dto) {
        if (cancellationApproval_dao.Delete(dto)) { //if successed remove from container
            co_CancellationOrderaApprovals.remove(returnOrderToCancel(new Order(dto.getSid(),dto.getStore_num(),dto.getTime(),0,null,null)));
        }
    }

    public void updateOrderCancellation_Dao(CancellationApproval_DTO dto) {
        if (cancellationApproval_dao.Update(dto)) {
            fillRolesApprovments(dto);
            Order order = (returnOrderToCancel(new Order(dto.getSid(),dto.getStore_num(),dto.getTime(),0,null,null)));
            updateOrderCancellationAtContainer(order, new CancellationOrder(order, storekeeperApproved, transportManagerApproved, hrManagerApproved));
        }
    }
    private Order returnOrderToCancel(Order order) {
        Collection<CancellationOrder> cancelationOrderLst = co_CancellationOrderaApprovals.values();
        for (CancellationOrder cancelOrder : cancelationOrderLst) {
            if (order.getSupplierId() == cancelOrder.getOrder().getSupplierId() && order.getStoreId() == cancelOrder.getOrder().getStoreId() && order.getTime().getTime() == cancelOrder.getOrder().getTime().getTime()) {
                return cancelOrder.getOrder();
            }
        }
        return null; // agreement not found
    }
    private void fillRolesApprovments(CancellationApproval_DTO dto) {
        if (dto.getApprovedByStoreKeeper() == 1) {
            storekeeperApproved = true;
        } else {
            storekeeperApproved = false;
        }
        if (dto.getApprovedByTransportManager() == 1) {
            transportManagerApproved = true;
        } else {
            transportManagerApproved = false;
        }
        if (dto.getApprovedByHrManager() == 1) {
            hrManagerApproved = true;
        } else {
            hrManagerApproved = false;
        }
    }

    //--------------------------AGREEMENTS----------------------//

    public Agreement getAgreement(int pid, int sid) {
        Collection<Agreement> agreements = co_agreements.values();
        for (Agreement agreement : agreements) {
            if (agreement.getPid() == pid && agreement.getSupplier().getSid() == sid)
                return agreement;
        }
        return null; // agreement not found
    }

    public List<Agreement> getFullAgreementBySidFromContainer(int sid) {
        List<Agreement> supplierAgreements = new LinkedList<>();

        Set<Map.Entry<Integer, Agreement>> entrySet = co_agreements.entrySet();
        for (Map.Entry entry : entrySet) {
            if (((Agreement) entry.getValue()).getSupplier().getSid() == sid) {
                supplierAgreements.add(((Agreement) entry.getValue()));
            }
        }
        return supplierAgreements;
    }

    public void addAgreementToContainer(Agreement agreement) {
        co_agreements.put(agreementCount, agreement);
        agreementCount++; //prepare next slot for agreement
    }

    public void deleteAgreementFromContainer(int pid, int sid) {
        Set<Map.Entry<Integer, Agreement>> entrySet = co_agreements.entrySet();
        for (Map.Entry entry : entrySet) {
            if (((Agreement) entry.getValue()).getPid() == pid && ((Agreement) entry.getValue()).getSupplier().getSid() == sid) {
                co_agreements.remove(entry.getKey());
                agreementCount--;
                return; //removed, can return
            }
        }
    }


    //--------------------------CONTACTS----------------------//

    public Contact getContact(int cid) {
        return co_contacts.get(cid);
    }

    public void addContactToContainer(Contact contactToAdd) {
        co_contacts.put(contactToAdd.getCid(), contactToAdd);
    }

    public void deleteContactFromContainer(int cid) {
        co_contacts.remove(cid);
    }


    //--------------------------SUPPLIERS----------------------//

    public Supplier getSupplerFromContainer(int sid) {
        return co_suppliers.get(sid);
    }

    public void addSupplierToConatiner(Supplier supplierToAdd) {

        co_suppliers.put(supplierToAdd.getSid(), supplierToAdd);
        suppliersCount++;
    }

    public void deleteSupplierFromContainer(int sid) {
        co_suppliers.remove(sid);
        suppliersCount--;
    }

    //---------------------------Supply_Days----------------------//
    public void addSupplierDayToContainer(SupplierDay supplierDay) {
        co_SuppliersBySupplyDay.put(supplierDay, "");
        supplyDayCount++;
    }

    public void deleteSupplierDaysFromContainer(int sid) {
        List<SupplierDay> lst = new LinkedList<>();
        for (SupplierDay supplierDay : co_SuppliersBySupplyDay.keySet()) {
            if (supplierDay.getSid() == sid) {
                lst.add(supplierDay);
                supplyDayCount--;
            }
        }
        for (SupplierDay supplierDay : lst) {
            co_SuppliersBySupplyDay.remove(supplierDay);
        }
    }

    private boolean isExistSupplierDayContainer(SupplierDay supplierDay) {
        boolean ans = false;
        for (SupplierDay supDay : co_SuppliersBySupplyDay.keySet()) {
            if (supplierDay.getSid() == supDay.getSid() && supplierDay.getSupplyDay() == supDay.getSupplyDay()) {
                ans = true;
            }
        }
        return ans;
    }

    public List<Integer> getSupplyDays_BySID_Container(int sid) {
        List<Integer> supplyDays = new LinkedList<>();
        for (SupplierDay supplierDay : co_SuppliersBySupplyDay.keySet()) {
            if (supplierDay.getSid() == sid) {
                supplyDays.add(supplierDay.getSupplyDay());
            }
        }
        return supplyDays;
    }

    public List<Integer> getSID_BySupplyDay_Container(int supplyDay) {
        List<Integer> supplierList = new LinkedList<>();
        for (SupplierDay supplierDay : co_SuppliersBySupplyDay.keySet()) {
            if (supplierDay.getSupplyDay() == supplyDay) {
                supplierList.add(supplierDay.getSid());
            }
        }
        return supplierList;
    }

    //---------------------------STORES----------------------//

    public Store getStoreFromContainer(int store_num) {
        return co_stores.get(store_num);
    }

    public void addStoreToContainer(Store storeToAdd) {
        co_stores.put(storeToAdd.getID(), storeToAdd);
    }

    public void deleteStore(int store_num) {
        co_contacts.remove(store_num);
    }

    //------------------------------ORDERS----------------------//

    public synchronized Order getOrderFromContainer(int sid, int store_num, Date date) {
        Collection<Order> orders = co_orders.values();
        for (Order order : orders) {
            if (order.getSupplierId() == sid && order.getStoreId() == store_num && order.getTime().getTime() == date.getTime()) {
                return order;
            }
        }
        return null; // agreement not found
    }

    public Order getOrderFromDb(int sid, int store_num, Date date) {
        try {
            PreparedStatement pstmt = dbManager.getConn().prepareStatement(Queries.getOrder);
            pstmt.setString(1,formatter.format(date));
            pstmt.setInt(2,store_num);
            pstmt.setInt(3,sid);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Order(sid, store_num, date, 0, null, null);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // agreement not found
    }

    public synchronized void addOrderToContainer(Order orderToAdd) {
        co_orders.put(ordersCount, orderToAdd);
        ordersCount++;
    }

    public synchronized List<Order> getAllOrdersFromContainer() {
        List<Order> lstOrders = new LinkedList<>();
        for (Integer orderNum : co_orders.keySet()) {
            lstOrders.add(co_orders.get(orderNum));
        }
        return lstOrders;
    }

    public synchronized void deleteOrderFromContainer(int sid, int store_num, Date date) {
        Set<Map.Entry<Integer, Order>> entrySet = co_orders.entrySet();
        for (Map.Entry entry : entrySet) {
            if (((Order) entry.getValue()).getSupplierId() == sid &&
                    ((Order) entry.getValue()).getStoreId() == store_num &&
                    ((Order) entry.getValue()).getTime() == date) {
                co_orders.remove(entry.getKey());
                ordersCount--;
                return; //removed, can return
            }
        }
    }

    //------------------------PRODUCTS AT ORDERS--------------------//

    public ProductAtOrder getPAO(int sid, int store_num, Date date, int product_id) {
        Collection<ProductAtOrder> paos = co_productsAtOrders.values();
        for (ProductAtOrder pao : paos) {
            if (pao.getPid() == product_id
                    && pao.getOrder().getSupplierId() == sid
                    && pao.getOrder().getTime() == date
                    && pao.getOrder().getStoreId() == store_num)
                return pao;
        }
        return null; // agreement not found
    }

    public void addProductAtOrderToContainer(ProductAtOrder pao) {
        co_productsAtOrders.put(productsAtOrdersCount, pao);
        productsAtOrdersCount++;
    }

    public void deleteProductAtOrderFromContainer(int sid, int store_num, Date date, int product_id) {
        Set<Map.Entry<Integer, ProductAtOrder>> entrySet = co_productsAtOrders.entrySet();
        for (Map.Entry entry : entrySet) {
            if (((ProductAtOrder) entry.getValue()).getOrder().getSupplierId() == sid &&
                    ((ProductAtOrder) entry.getValue()).getOrder().getStoreId() == store_num &&
                    ((ProductAtOrder) entry.getValue()).getOrder().getTime() == date &&
                    ((ProductAtOrder) entry.getValue()).getPid() == product_id) {
                co_productsAtOrders.remove(entry.getKey());
                productsAtOrdersCount--;
                return; //removed, can return
            }
        }
    }

    public List<ProductAtOrder> getAllProductsAtOrderByOrder(Order order) {
        List<ProductAtOrder> lstPrdouctsAtOrder = new LinkedList<>();
        Set<Map.Entry<Integer, ProductAtOrder>> entrySet = co_productsAtOrders.entrySet();
        for (Map.Entry entry : entrySet) {
            if (((ProductAtOrder) entry.getValue()).getOrder().getSupplierId() == order.getSupplierId() &&
                    ((ProductAtOrder) entry.getValue()).getOrder().getStoreId() == order.getStoreId() &&
                    ((ProductAtOrder) entry.getValue()).getOrder().getTime() == order.getTime()) {
                lstPrdouctsAtOrder.add(co_productsAtOrders.get(entry.getKey()));
            }
        }
        return lstPrdouctsAtOrder;
    }

    //------------------------OrderCancellation--------------------//
    public void addOrderCancellationToContainer(Order order, boolean approvedByStoreKeeper, boolean approvedByTransportManager, boolean approvedByHrManager) {
        co_CancellationOrderaApprovals.put(order, new CancellationOrder(order, approvedByStoreKeeper, approvedByTransportManager, approvedByHrManager));
    }

    public void deleteOrderCnacellationFromConatiner(Order order) {
        co_CancellationOrderaApprovals.remove(order);
    }

    public void updateOrderCancellationAtContainer(Order order, CancellationOrder cancellationOrder) {
        co_CancellationOrderaApprovals.remove(order);
        co_CancellationOrderaApprovals.put(order, cancellationOrder);
    }

    public List<CancellationOrder> getAllCancelledOrders() {
        List<CancellationOrder> lstCancellationOrder = new LinkedList<>();
        for (Order order : co_CancellationOrderaApprovals.keySet()) {
            lstCancellationOrder.add(co_CancellationOrderaApprovals.get(order));
        }
        return lstCancellationOrder;
    }

    private synchronized void updateContainerWithSotres() {
        /*
        String sql = "SELECT * FROM Stores";
        con=dbManager.getConn();
        try {
            PreparedStatement pstmt  = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()) {
                addStoreToContainer(new Store(rs.getInt("store_num")));
            }
            pstmt.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
        */
    }

    public synchronized void updateContainerWithSuppliers() {
        String sql = "SELECT * FROM Suppliers";
        con = dbManager.getConn();
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                addSupplierToConatiner(new Supplier(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getInt(4),
                        rs.getString(5)));
            }
            pstmt.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public synchronized void updateContainerWithAgreements() {
        String sql = "SELECT * FROM Agreements";
        con = dbManager.getConn();
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                addAgreementToContainer(new Agreement((rs.getInt(2)),
                        getSupplerFromContainer(rs.getInt("supplier_id")),
                        rs.getDouble(3),
                        rs.getInt(4),
                        rs.getDouble(5)));
            }

            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public synchronized void updateContainerWithContacts() {
        String sql = "SELECT * FROM Contacts";
        con = dbManager.getConn();
        try {

            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                addContactToContainer(new Contact(rs.getInt(1),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        getSupplerFromContainer(rs.getInt(2))));
            }

            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public synchronized void updateContainerWithOrders() {

        String sql = "SELECT * FROM orders";
        con = dbManager.getConn();
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            Site_DAO site_dao = new Site_DAO(dbManager);
            while (rs.next()) {
                Date d = null;
                try {
                    d = formatter.parse(rs.getString("date"));
                    addOrderToContainer(new Order(rs.getInt("sid"), rs.getInt("store_num"), d, 0, site_dao.getDestSite(rs.getInt("sid")), null));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }

    }

    private synchronized void updateContainerWithSuppliersDays() {
        String sql = "SELECT * FROM Supply_Days";
        con = dbManager.getConn();
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                addSupplierDayToContainer(new SupplierDay(rs.getInt("SID"), rs.getInt("Day")));
            }

            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
    }

    private synchronized void updateContainerWithCancellationOrders() {
        boolean approvedByStoreKeeper;
        boolean approvedByTransportManager;
        boolean approvedByHrManager;
        String sql = "SELECT * FROM orders_Cancellation_Approvals";
        con = dbManager.getConn();
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Date d = formatter.parse(rs.getString("date"));
                Order order = getOrderFromContainer(rs.getInt("sid"), rs.getInt("store_num"), d);
                if (rs.getInt("storeKeeperApproved") == 1) {
                    approvedByStoreKeeper = true;
                } else {
                    approvedByStoreKeeper = false;
                }
                if (rs.getInt("TransportMangerApproved") == 1) {
                    approvedByTransportManager = true;
                } else {
                    approvedByTransportManager = false;
                }
                if (rs.getInt("HrManagerApproved") == 1) {
                    approvedByHrManager = true;
                } else {
                    approvedByHrManager = false;
                }
                addOrderCancellationToContainer(order, approvedByStoreKeeper, approvedByTransportManager, approvedByHrManager);
            }

            pstmt.close();
            rs.close();

        } catch (SQLException e) {

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public CancellationOrder getCancellationOrderApprovmentsFromContainer(Order order) {
        Collection<CancellationOrder> cancelationOrderLst = co_CancellationOrderaApprovals.values();
        for (CancellationOrder cancelOrder : cancelationOrderLst) {
            if (order.getSupplierId() == cancelOrder.getOrder().getSupplierId() && order.getStoreId() == cancelOrder.getOrder().getStoreId() && order.getTime().getTime() == cancelOrder.getOrder().getTime().getTime()) {
                return cancelOrder;
            }
        }
        return null; // agreement not found

    }

    public List<Agreement> getAgreementsByProductId_Dao(int productId) {
        return agreementsDao.getAgreementsByProductID(productId);
    }


    public int getAgreementCount() {
        return agreementCount;
    }

    public int getOrdersCount() {
        return ordersCount;
    }

    public int getProductsAtOrdersCount() {
        return productsAtOrdersCount;
    }

    public int getSuppliersCount() {
        return suppliersCount;
    }

    public List<DeliveryForm> getDeliveries(int curStoreNum) {
        return productsAtOrders_dao.getDeliveries(curStoreNum);
    }

    public List<ProductAtOrder> getProductsAtOrdersByDelivery(DeliveryForm deliveryForm) {
        return productsAtOrders_dao.getByDelivery(deliveryForm);
    }

    public void resolveDelivery(DeliveryForm delv, String issues) {
        productsAtOrders_dao.resolveDelivery(delv, issues);
    }
}
