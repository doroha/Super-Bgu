package Bussiness_layer.DAO;
import Bussiness_layer.DTO.Supplier_DTO;
import Bussiness_layer.Passive_objects.Supplier;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;
import Persistent_layer.ResultSetPrinter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


 public class Supplier_DAO extends Object_DAO<Supplier_DTO> {

     public Supplier_DAO(DatabaseManager dbManger) {
        super(dbManger);
    }


    public synchronized boolean Insert(Supplier_DTO dto_Obj){
        try {
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Insert"));
            ps.setInt(1, dto_Obj.getSid());
            ps.setInt(2, dto_Obj.getBank_acount());
            ps.setString(3, dto_Obj.getPayment_terms());
            ps.setInt(4, dto_Obj.getDelivery_routine());
            ps.setString(5,dto_Obj.getSite_id());

            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
        return false;
    }

    public synchronized void Update(Supplier_DTO dto_Obj) {
         if(dto_Obj==null) {return;}
        try {
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Update"));
            ps.setInt(1, dto_Obj.getBank_acount());
            ps.setString(2, dto_Obj.getPayment_terms());
            ps.setInt(3, dto_Obj.getDelivery_routine());
            ps.setInt(4, dto_Obj.getSid());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
    }

    @Override
   public synchronized boolean Delete(Supplier_DTO dto_Obj) {
         if(dto_Obj==null) {
             return false;
         }
        try {
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Delete"));
            ps.setInt(1, dto_Obj.getSid());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
        return false;
    }

     //get supplier by id
     public synchronized Supplier_DTO Get(Supplier_DTO dto_Obj) {
         ResultSet rs=null;
         try {
             String sql = getQueryByOperation("GET");
             PreparedStatement st = conn.prepareStatement(sql);
             st.setInt(1,dto_Obj.getSid());
             rs=st.executeQuery();
         } catch (SQLException e) {
             e.printStackTrace();
             System.out.println("Exception: "+e.getMessage());
         }
         try {
             if(rs != null && !rs.isClosed())
             return getSupplierDtoByResultSet(rs);
         } catch (SQLException e) {
             e.printStackTrace();
         }
        return null;
     }

     public synchronized void Print(Supplier_DTO dto_Obj) {
         try {
             //the same as for the "get query", but another purpose.
             PreparedStatement ps=conn.prepareStatement(getQueryByOperation("GET"));
             ps.setInt(1, dto_Obj.getSid());
             PreparedStatement ps_clone=conn.prepareStatement(getQueryByOperation("GET"));
             ps_clone.setInt(1, dto_Obj.getSid());
             ResultSet rs=ps.executeQuery();
             ResultSet rs_clone=ps_clone.executeQuery();

             if(!rs_clone.next())
             {
                 System.out.println("\nError: No matches found!\n");
                 return;
             }
             ResultSetPrinter.printResultSet(rs);
             ps.close();
             rs.close();
         } catch (SQLException e) {
             e.printStackTrace();
             System.out.println("Exception: "+e.getMessage());
         }
     }



     private Supplier_DTO getSupplierDtoByResultSet(ResultSet rs){
         try {
             Supplier_DTO dto= new Supplier_DTO(rs.getInt("id"),rs.getInt("bank_account"),rs.getString("payment_terms"),rs.getInt("delivery_routine"), rs.getString("site_id"));
             return dto;
         } catch (SQLException e) {
             e.printStackTrace();
             System.out.println("Exception: "+e.getMessage());
         }
         return null;
     }

     protected String getQueryByOperation(String operation) {
        String Query=null;
        switch (operation) {
            case "Insert":
                Query="INSERT INTO suppliers "
                        + "(id, Bank_account, payment_terms, delivery_routine, site_id) VALUES"
                        + "(?,?,?,?,?)";
                break;
            case "Update":
                Query="UPDATE suppliers "
                        + "SET Bank_account = ? , payment_terms = ?, delivery_routine = ? "
                        + "WHERE id = ?";
                break;
            case "Delete":
                Query="DELETE FROM suppliers "
                        +  "WHERE id = ?";
                break;
            case "GET":
                Query="SELECT * FROM suppliers WHERE id = ? ";
                break;

             default:
                 try {
                     throw new Exception("in valid operation type");
                 } catch (Exception e) {
                     e.printStackTrace();
                     System.out.println("Exception: "+e.getMessage());
                 }
        }
        return Query;
    }

     public synchronized void printSuppliers() {
         String sql = "SELECT * FROM suppliers";

         try {
             PreparedStatement pstmt  = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery();
             if(!rs.isBeforeFirst())
             {
                 System.out.println("\nError: No matches found!\n");
                 return;
             }

             ResultSetPrinter.printResultSet(rs);

             pstmt.close();
             rs.close();

         } catch (SQLException e) {
             e.printStackTrace();
             System.out.println("Exception: "+e.getMessage());
         }
     }

     public boolean isExist(int id) {
         boolean ans = false;
         try {
             PreparedStatement ps = conn.prepareStatement(Queries.supplier_by_id);
             ps.setInt(1, id);
             ResultSet rs = ps.executeQuery();
             ans = rs.next();
             rs.close();
         } catch (SQLException e) {
             System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
         }
         return ans;
     }
 }
