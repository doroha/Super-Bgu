package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.DamagedProduct;
import Persistent_layer.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

public class DamagedItemsDAO {
    private DatabaseManager dbmg;

    public DamagedItemsDAO(DatabaseManager dbmg) {
        this.dbmg = dbmg;
    }

    public synchronized LinkedList<DamagedProduct> getAllByStoreId(int storeId)
    {
        LinkedList<DamagedProduct> dmg_prod = new LinkedList<>();
        try {
            Connection con = dbmg.getConn();
            String sql = "SELECT * FROM Damaged_products WHERE store_num=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,storeId);
            ResultSet rs= st.executeQuery();
            // loop through the result set
            while (rs.next()) {
                int pid = rs.getInt("PID");
                int store_num = rs.getInt("store_num");
                String location = rs.getString("location");
                int amount = rs.getInt("amount");
                DamagedProduct cur_product = new DamagedProduct(pid,store_num,location,amount);
                dmg_prod.add(cur_product);

            }
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
        return dmg_prod;

    }
    public synchronized void update(DamagedProduct p) {
        try{
            Connection con = dbmg.getConn();
            String sql = "UPDATE Damaged_products SET amount = ? WHERE PID=? ";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, p.getAmount());
            st.setInt(2, p.getPid());
            st.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println("Could'nt update product in the ID: "+p.getPid());
        }
    }
    public synchronized void insert(DamagedProduct p)
    {
        try{
            Connection con = dbmg.getConn();
            String sql = "INSERT INTO Damaged_products(PID,store_num,location,amount) VALUES(?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,p.getPid());
            st.setInt(2,p.getStore_num());
            st.setString(3,p.getLocation());
            st.setInt(4,p.getAmount());
            st.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());;
        }
    }

}
