package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.SoldProduct;
import Persistent_layer.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class SellingsDAO {
    private DatabaseManager dbmg;
    private int highestID;

    public SellingsDAO(DatabaseManager dbmg) {
        synchronized (this) {
            this.dbmg = dbmg;
            try {
                Connection con = dbmg.getConn();
                String sql = "SELECT MAX(receipt_ID) FROM Sellings";
                PreparedStatement st = con.prepareStatement(sql);
                ResultSet rs = st.executeQuery();
                rs.next();
                highestID = rs.getInt("MAX(receipt_ID)");
            } catch (SQLException e) {
                highestID = 0;
            }
        }

    }

    public synchronized List<SoldProduct> getAllByStoreId(int storeId) {
        List<SoldProduct> result = new LinkedList<>();
        try{
            Connection con = dbmg.getConn();
            String sql = "SELECT * FROM Sellings WHERE store_num = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,storeId);
            ResultSet rs= st.executeQuery();
            // loop through the result set
            while (rs.next()) {
                int receipt = rs.getInt("receipt_ID");
                int PID = rs.getInt("PID");
                int buyPrice = rs.getInt("buy_price");
                int sellPrice = rs.getInt("sell_price");
                int amount = rs.getInt("amount");
                SoldProduct sp = new SoldProduct(receipt,PID, storeId, buyPrice,sellPrice, amount);
                result.add(sp);

            }
        }
        catch (SQLException e)
        {
            return result;
        }
        return result;
    }

    public synchronized void insert(SoldProduct sp) {
        try{
            highestID++;
            Connection con = dbmg.getConn();
            String sql = "INSERT INTO Sellings" +
                    "(receipt_ID,PID,store_num,buy_price,sell_price,amount) values" +
                    "(?,?,?,?,?,?);";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,highestID);
            st.setInt(2,sp.getPID());
            st.setInt(3, sp.getStoreNumber());
            st.setInt(4, sp.getBuyPrice());
            st.setInt(5, sp.getSellPrice());
            st.setInt(6,sp.getAmount());

            st.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println("Could'nt insert Selling in the PID: "+sp.getPID());
            highestID--;
        }
    }
}
