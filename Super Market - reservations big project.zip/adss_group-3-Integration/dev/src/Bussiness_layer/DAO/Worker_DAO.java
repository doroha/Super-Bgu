package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.*;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;
import Persistent_layer.ResultSetPrinter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

public class Worker_DAO extends Object_DAO<Worker> {

    public Worker_DAO(DatabaseManager dbm) {
        super(dbm);
    }

    public boolean Insert(Worker w) {
        boolean ans;
        User_DAO udao = new User_DAO(dbm);
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.workers_insert);
            stmt.setInt(1, w.getSsn());
            stmt.setString(2, w.getFname());
            stmt.setString(3, w.getLname());
            stmt.setInt(4, w.getBankAccount());
            stmt.setString(5, w.getStartDate());
            stmt.setString(6, w.getConditions());
            stmt.setInt(7, w.getSalsry());
            // StoreId of -1 indicates a driver which doesn't belong to a specific store.
            stmt.setInt(8, w.getStoreId());
            stmt.setString(9, w.getJob());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to insert Worker.");
                ans = false;
            }
            else {
                // Attach user
                ans = udao.Insert(new User(Integer.toString(w.getSsn()), w.getSsn(), Integer.toString(w.getBankAccount()), 0));
            }
            stmt.close();
        } catch (SQLException e) {
            ans = false;
            e.printStackTrace();
        }
        return ans;
    }

    public boolean Delete(Worker w) {
        // First delete this worker shifts and availability
        Availability_DAO adao = new Availability_DAO(dbm);
        adao.Delete(new Availability(w.getSsn(), 0, 0, 0, 0, 0, 0, 0));
        Shift_DAO shiftDao = new Shift_DAO(dbm);
        shiftDao.DeleteAllWorkerShifts(w);
        User_DAO userdao = new User_DAO(dbm);
        userdao.Delete(new User("", w.getSsn(), "", 0));
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.delete_worker_by_ssn);
            ps.setInt(1, w.getSsn());
            if (ps.executeUpdate() != 1) {
                System.out.println("Failed to delete a Worker.");
                ans = true;
            } else {
                System.out.println("Succeeded to delete a Worker.");

                // Now delete possible roles this worker could have take.
                PreparedStatement ps1 = conn.prepareStatement(Queries.delete_driver_by_ssn);
                PreparedStatement ps2 = conn.prepareStatement(Queries.delete_store_cashier_by_ssn);
                PreparedStatement ps3 = conn.prepareStatement(Queries.delete_store_manager_by_ssn);
                PreparedStatement ps4 = conn.prepareStatement(Queries.delete_storekeeper_by_ssn);
                ps1.setInt(1, w.getSsn());
                ps2.setInt(1, w.getSsn());
                ps3.setInt(1, w.getSsn());
                ps4.setInt(1, w.getSsn());
                ps1.executeUpdate();
                ps2.executeUpdate();
                ps3.executeUpdate();
                ps4.executeUpdate();
                ps1.close();
                ps2.close();
                ps3.close();
                ps4.close();
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public boolean updateBankAccount(int ssn, int bankAccount) {
        String q = "UPDATE workers SET bankAcount=" + bankAccount + " WHERE worker_ssn=" + ssn;
        try {
            return executeStatement(q);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateSalary(int ssn, int salary) {
        String q = "UPDATE workers SET salary=" + salary + "	WHERE worker_ssn=" + ssn;
        try {
            return executeStatement(q);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateStoreId(int ssn, int s) {
        String q = "UPDATE workers SET storeId=" + s + " WHERE worker_ssn=" + ssn;
        try {
            return executeStatement(q);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateCondition(int ssn, String c) {
        String q = "UPDATE workers SET conditions='" + c + "'	WHERE worker_ssn=" + ssn;
        try {
            return executeStatement(q);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateJob(int ssn, String job) {
        String q = "UPDATE workers SET job='" + job + "'	WHERE worker_ssn=" + ssn;
        try {
            return executeStatement(q);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean workerExist(int ssn) {
        ResultSet rs;
        boolean ans;
        try {
            PreparedStatement st = conn.prepareStatement(Queries.getWorkerBySsn);
            st.setInt(1, ssn);
            rs = st.executeQuery();
            ans = rs.next();
            rs.close();
        } catch (SQLException e) {
            return false;
        }
        return ans;
    }


    private boolean executeStatement(String q) {
        try {
            PreparedStatement ps = conn.prepareStatement(q);
            ps.executeUpdate();
            ps.close();
        } catch (Exception ex) {
            return false;
        }
        return true;
    }

    public Worker getWorker(int id) {
        Worker worker = null;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.getWorkerBySsn);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            rs.next();
            worker = new Worker(
                    rs.getInt("worker_ssn"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getInt("bankAcount"),
                    rs.getString("startDate"),
                    rs.getString("conditions"),
                    rs.getInt("salary"),
                    rs.getInt("storeId"),
                    rs.getString("job")
            );
            ps.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return worker;
    }


    public void printWorker(int id) {
        try {
            PreparedStatement pstmt = conn.prepareStatement(Queries.getWorkerBySsn);
            pstmt.setInt(1,id);
            ResultSet rs = pstmt.executeQuery();
            //we 'clone' the result set just in order to use .next method without missing the first row.
            PreparedStatement pstmt_clone = conn.prepareStatement(Queries.getWorkerBySsn);
            pstmt_clone.setInt(1,id);
            ResultSet rs_clone = pstmt_clone.executeQuery();

            if (rs_clone.next()) {
                ResultSetPrinter.printResultSet(rs);
            } else {
                System.out.println("Error: there is no worker " + id + "\n");
            }
            pstmt.close();
            rs.close();
            pstmt_clone.close();
            rs_clone.close();
        } catch (SQLException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public LinkedList<Worker> getWorkers() {
        String q = Queries.get_all_workers;
        try {
            PreparedStatement ps = conn.prepareStatement(q);
            ResultSet rs = ps.executeQuery();
            LinkedList<Worker> workers = new LinkedList<>();

            while (rs.next()) {
                workers.add(new Worker(
                        rs.getInt("worker_ssn"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getInt("bankAcount"),
                        rs.getString("startDate"),
                        rs.getString("conditions"),
                        rs.getInt("salary"),
                        rs.getInt("storeId"),
                        rs.getString("job")
                ));
            }
            ps.close();
            rs.close();
            return workers;

        } catch (SQLException e) {
            return null;
        }
    }

    public void makeStoreManager(int ssn) {
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.insert_manager);
            stmt.setInt(1, ssn);
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void makeStoreKeeper(int ssn) {
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.insert_storekeeper);
            stmt.setInt(1, ssn);
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean isManager(int ssn) {
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.store_keeper_by_ssn);
            ps.setInt(1, ssn);
            ResultSet rs = ps.executeQuery();
            ans = rs.next();
            rs.close();
        } catch (SQLException e) {
            System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
        }
        return ans;
    }

    public boolean isStoreKeeper(int ssn) {
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.store_manager_by_ssn);
            ps.setInt(1, ssn);
            ResultSet rs = ps.executeQuery();
            ans = rs.next();
            rs.close();
        } catch (SQLException e) {
            System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
        }
        return ans;
    }
}
