package Bussiness_layer.DAO;


import Bussiness_layer.Passive_objects.Category;
import Persistent_layer.DatabaseManager;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class CategoryDAO {
    private final String table = "Category";
    public CategoryDAO() {}
    //Get DBMG connection and r=take all categories from DB and each category
    // Create a Category object and insert it into LinkedList and return the list
    public synchronized List<Category> getallcategories(DatabaseManager dbmg)
    {
        LinkedList<Category> allcategories = new LinkedList<>();
        try{
            Connection con = dbmg.getConn();
            String sql = "SELECT * FROM categories";
            Statement st = con.createStatement();
            ResultSet rs= st.executeQuery(sql);
            // loop through the result set
            while (rs.next()) {
                int cid = rs.getInt("CID");
                int fid = rs.getInt("FID");
                String name = rs.getString("Name");
                String end_date = rs.getString("end_date");
                int my_disc = rs.getInt("my_discount");
                int curr_disc = rs.getInt("current_discount");
                Category cur_category = new Category(cid,fid,name,my_disc,curr_disc,end_date);
                allcategories.add(cur_category);

            }
        }
        catch (SQLException e)
        {
            return allcategories;
        }
        return allcategories;
    }

    //Need to insert the new category into the DB
    public synchronized void insertcategory(Category n_category, DatabaseManager dbmg)
    {
        try{
            Connection con = dbmg.getConn();
            String sql = "INSERT INTO categories(CID,FID,Name,end_date,my_discount,current_discount) VALUES(?,?,?,NULL ,0,0)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,n_category.getID());
            st.setInt(2,n_category.getFatherID());
            st.setString(3,n_category.getName());
            st.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());;
        }
    }

    public synchronized LinkedList<Category> getallsons(int father_ID, DatabaseManager dbmg)
    {
        LinkedList<Category> sons = new LinkedList<>();
        try{
            Connection con = dbmg.getConn();
            String sql = "SELECT * FROM categories WHERE FID=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,father_ID);
            ResultSet rs= st.executeQuery();
            // loop through the result set
            while (rs.next()) {
                int cid = rs.getInt("CID");
                int fid = rs.getInt("FID");
                String name = rs.getString("Name");
                String end_date = rs.getString("end_date");
                int my_disc = rs.getInt("my_discount");
                int curr_disc = rs.getInt("current_discount");
                Category cur_category = new Category(cid,fid,name,my_disc,curr_disc,end_date);
                sons.add(cur_category);

            }
        }
        catch (SQLException e)
        {
            return sons;
        }
        return sons;
    }
    public synchronized void delete_tree(int cid, DatabaseManager dbmg)
    {
        try{
            Connection con = dbmg.getConn();
            String sql = "DELETE FROM categories WHERE CID=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,cid);
            st.executeUpdate();

        }
        catch (SQLException e)
        {
            System.out.println("Could'nt remove: "+cid);
        }
    }
    public synchronized void updateM(int cid, int precentage,String e_date, DatabaseManager dbmg)
    {
        try{
            Connection con = dbmg.getConn();
            String sql = "UPDATE categories SET my_discount = ?, end_date = ? WHERE CID=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,precentage);
            st.setString(2,e_date);
            st.setInt(3,cid);
            st.executeUpdate();

        }
        catch (SQLException e)
        {
            System.out.println("Could'nt update personal discounts in the ID: "+cid);
        }

    }
    public synchronized void updateC(int cid, int precentage, DatabaseManager dbmg)
    {
        try{
            Connection con = dbmg.getConn();
            String sql = "UPDATE categories SET current_discount = ? WHERE CID=?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,precentage);
            st.setInt(2,cid);
            st.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println("Could'nt update personal discounts in the ID: "+cid);
        }

    }

}
