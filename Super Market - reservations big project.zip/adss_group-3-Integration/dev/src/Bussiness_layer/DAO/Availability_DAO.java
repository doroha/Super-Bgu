package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.Availability;
import Bussiness_layer.Passive_objects.Worker;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;
import Persistent_layer.ResultSetPrinter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Availability_DAO extends Object_DAO<Availability> {


    public Availability_DAO(DatabaseManager dbm) {
        super(dbm);
    }

    public void printAvailabilityBySsn(int ssn) {
        try {
            PreparedStatement pstmt = conn.prepareStatement(Queries.getAvailabilityBySsn);
            pstmt.setInt(1,ssn);
            ResultSet rs = pstmt.executeQuery();
            //we 'clone' the result set just in order to use .next method without missing the first row.
            PreparedStatement pstmt_clone = conn.prepareStatement(Queries.getAvailabilityBySsn);
            pstmt_clone.setInt(1,ssn);
            ResultSet rs_clone = pstmt_clone.executeQuery();
            if (rs_clone.next()) {
                ResultSetPrinter.printResultSet(rs);
            } else {
                System.out.println(String.format("Worker with ssn: %d didn't specify one yet.\n", ssn));
            }
            pstmt.close();
            rs.close();
            pstmt_clone.close();
            rs_clone.close();
        } catch (SQLException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public Availability getSchedule(int ssn) {
        Availability availability;
        try {
            PreparedStatement pstmt = conn.prepareStatement(Queries.getAvailabilityBySsn);
            pstmt.setInt(1, ssn);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                availability = new Availability(
                        ssn,
                        rs.getInt("day1"),
                        rs.getInt("day2"),
                        rs.getInt("day3"),
                        rs.getInt("day4"),
                        rs.getInt("day5"),
                        rs.getInt("day6"),
                        rs.getInt("day7"));
            }
            else {
                availability = new Availability(ssn, 3, 3, 3, 3, 3, 3,3);
            }
            pstmt.close();
            rs.close();
        } catch (SQLException e) {
            return null;
        }
        return availability;
    }

    public boolean Insert(Availability wa) {
        Delete(wa); // If there is old record, delete it first.
        if (wa == null) {
            return false;
        }
        boolean ans = false;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.insert_availability);
            stmt.setInt(1, wa.getSsn());
            stmt.setInt(2, wa.get_day1());
            stmt.setInt(3, wa.get_day2());
            stmt.setInt(4, wa.get_day3());
            stmt.setInt(5, wa.get_day4());
            stmt.setInt(6, wa.get_day5());
            stmt.setInt(7, wa.get_day6());
            stmt.setInt(8, wa.get_day7());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to insert Schedule");
            } else {
                ans = true;
                System.out.println("Schedule inserted");
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public boolean Delete(Availability w) {
        Shift_DAO shift_dao = new Shift_DAO(dbm);
        shift_dao.DeleteAllWorkerShifts(new Worker(w.getSsn(), "", "", 0, "", "", 0, 0, ""));
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.delete_availability_by_ssn);
            ps.setInt(1, w.getSsn());
            ans = ps.executeUpdate() != 1;
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public boolean updateConstraints(Worker w, Availability av) {
        Delete(av);
        Insert(av);
        Shift_DAO shift_dao = new Shift_DAO(dbm);
        shift_dao.DeleteAllWorkerShifts(w);
        return true;
    }
}
