package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.Store;
import Bussiness_layer.Passive_objects.User;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;
import Persistent_layer.ResultSetPrinter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class Store_DAO extends Object_DAO<Store> {


    public Store_DAO(DatabaseManager dbm) {
        super(dbm);
    }


    public boolean Insert(Store s) {
        if (s == null) {
            return false;
        }
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.store_insert);
            ps.setInt(1, s.getID());
            ps.setString(2, s.getAddress());
            if (ps.executeUpdate() != 1) {
                System.out.println("Failed to insert Worker.");
            } else {
                ans = true;
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public boolean Delete(Store s) {
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.delete_store_by_id);
            ps.setInt(1, s.getID());
            if (ps.executeUpdate() != 1) {
                System.out.println("Failed to delete Store");
            } else {
                ans = true;
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public LinkedList<Store> getStores() {
        String q = Queries.get_all_stores;
        LinkedList<Store> r = new LinkedList<>();
        try {
            PreparedStatement ps = conn.prepareStatement(q);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                r.add(new Store(rs.getInt("id"), rs.getString("site_id")));
            }
            ps.close();
            rs.close();
        } catch (SQLException var4) {
            return null;
        }
        return r;
    }

    public synchronized List<Integer> getactivestores()
    {
        LinkedList<Integer> stores = new LinkedList<>();
        try{
            String sql = "SELECT id FROM stores";
            Statement st = conn.createStatement();
            ResultSet rs= st.executeQuery(sql);
            // loop through the result set
            while (rs.next()) {
                Integer num = rs.getInt("id");
                stores.add(num);
            }
        }
        catch (SQLException e)
        {
            return stores;
        }
        return stores;
    }

    // returns -1 on failure.
    public int getStoreIdBySsn(int ssn) {
        int ans = -1;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.store_id_by_ssn);
            ps.setInt(1, ssn);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ans = rs.getInt("storeId");
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
        }
        return ans;
    }
    // returns -1 on failure.
    public int getStorekeeperIdBySsn(int ssn) {
        int ans = -1;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.store_id_by_ssn_storekeeper);
            ps.setInt(1, ssn);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ans = rs.getInt("storeId");
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
        }
        return ans;
    }

    public void printStoreById(int id) {
        try {
            PreparedStatement pstmt = conn.prepareStatement(Queries.store_by_id);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            //we 'clone' the result set just in order to use .next method without missing the first row.
            PreparedStatement pstmt_clone = conn.prepareStatement(Queries.store_by_id);
            pstmt_clone.setInt(1,id);
            ResultSet rs_clone = pstmt_clone.executeQuery();
            if (rs_clone.next()) {
                ResultSetPrinter.printResultSet(rs);
            } else {
                System.out.println("Error: there is no store " + id + "\n");
            }
            pstmt.close();
            rs.close();
            pstmt_clone.close();
            rs_clone.close();
        } catch (SQLException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public boolean isExist(int id) {
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.store_by_id);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            ans = rs.next();
            rs.close();
        } catch (SQLException e) {
            System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
        }
        return ans;
    }
}
