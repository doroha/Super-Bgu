package Bussiness_layer.DAO;
import Bussiness_layer.DTO.SupplierDay_DTO;
import Persistent_layer.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class SupplierDay_DAO extends Object_DAO<SupplierDay_DTO> {

    String tbl_SupplyDays="Supply_Days";
    String col_SID ="SID";
    String col_Day ="Day";

    public SupplierDay_DAO(DatabaseManager dbManger) {
        super(dbManger);
    }
    @Override
    public synchronized boolean Insert(SupplierDay_DTO dto_Obj) {
        try {
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Insert"));
            ps.setInt(1, dto_Obj.getSid());
            ps.setInt(2, dto_Obj.getSupplyDay());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
        return false;
    }

    public synchronized void Update(SupplierDay_DTO dto_Obj) {

        if(dto_Obj==null) {return;}
        try {
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Update"));
            ps.setInt(1,dto_Obj.getSupplyDay());
            ps.setInt(2, dto_Obj.getSid());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
    }

    @Override
    public synchronized boolean Delete(SupplierDay_DTO dto_Obj) {
        if(dto_Obj==null){
            return false;
        }
        try {
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Delete"));
            ps.setInt(1, dto_Obj.getSid());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
        return false;
    }

    public synchronized SupplierDay_DTO Get(SupplierDay_DTO dto_Obj) {
           return null;
    }
    public synchronized List<Integer> getSupplyDaysBySid(SupplierDay_DTO dto_Obj){
        List<Integer>supplyDays=new LinkedList<>();
        ResultSet rs=null;
        try {
            String sql = getQueryByOperation("Get_SID_BySupplyDay");
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1,dto_Obj.getSid());
            rs=st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            if(!rs.isClosed())
                while (rs.next()){
                    supplyDays.add(rs.getInt(col_Day));
                }
                return supplyDays;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public synchronized List<Integer> getSidBySupplyDay(Integer supplyDay){
        List<Integer>suppliers=new LinkedList<>();
        ResultSet rs=null;
        try {
            String sql = getQueryByOperation("GET_SupplyDays");
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1,supplyDay);
            rs=st.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
        try {
            if(!rs.isClosed())
                while (rs.next()){
                    suppliers.add(rs.getInt(col_SID));
                }
            return suppliers;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public synchronized void Print(SupplierDay_DTO dto_Obj) {

    }

    protected String getQueryByOperation(String operation) {
        String Query=null;
        switch (operation) {
            case "Insert":
                Query="INSERT INTO " +tbl_SupplyDays
                        + " ("+ col_SID +","+col_Day+") VALUES"
                        + "(?,?)";
                break;
            case "Update":
                Query="UPDATE "+tbl_SupplyDays
                        + " SET "+col_Day+" = ? "
                        + "WHERE "+col_SID+" = ?";
                break;
            case "Delete":
                Query="DELETE FROM "+tbl_SupplyDays
                        +  " WHERE "+col_SID+" = ?";
                break;
            case "GET_SupplyDays":
                Query="SELECT "+col_Day+" FROM "+tbl_SupplyDays+" WHERE "+col_SID+" = ? ";
                break;
            case "Get_SID_BySupplyDay":
                Query="SELECT "+col_SID+" FROM "+tbl_SupplyDays+" WHERE "+col_Day+" = ? ";
            default:
                try {
                    throw new Exception("in valid operation type");
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("Exception: "+e.getMessage());
                }
        }
        return Query;
    }
}
