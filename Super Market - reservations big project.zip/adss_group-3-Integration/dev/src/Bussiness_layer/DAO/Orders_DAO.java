package Bussiness_layer.DAO;

import Bussiness_layer.Config;
import Bussiness_layer.DTO.Order_DTO;
import Bussiness_layer.Passive_objects.Order;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

public class Orders_DAO extends Object_DAO<Order_DTO> {

    public Orders_DAO(DatabaseManager dbManger) {
        super(dbManger);
    }
    private SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);

    @Override
    public synchronized boolean Insert(Order_DTO dto_Obj) {
        try {
            String result = formatter.format(dto_Obj.getTime());
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Insert"));
            ps.setString(1, result);
            ps.setInt(2,dto_Obj.getStart_handle_after_days());
            ps.setInt(3, dto_Obj.getStore_num());
            ps.setInt(4, dto_Obj.getSid());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public synchronized void Update(Order_DTO dto_Obj) {
      // nothing to update
    }

    @Override
    public boolean Delete(Order_DTO dto_Obj) {
        String result = formatter.format(dto_Obj.getTime());
        try {
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Delete"));
            ps.setString(1, result);
            ps.setInt(2, dto_Obj.getStore_num());
            ps.setInt(3, dto_Obj.getSid());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public synchronized Order_DTO Get(Order_DTO dto_Obj) {
        //not implemented
        return null;
    }

    public synchronized void Print(Order_DTO dto_Obj) {
        //nit implemented yet.
    }

    protected String getQueryByOperation(String operation) {
        String Query=null;
        switch (operation) {
            case "Insert":
                Query="INSERT INTO orders "
                        + "(date,start_handle_after_days, store_num, sid) VALUES"
                        + "(?,?,?,?)";
                break;
            case "Delete":
                Query="DELETE FROM orders "
                        + "WHERE date = ? AND store_num = ? and sid = ?";
                break;


            default:
                try {
                    throw new Exception("in valid operation type");
                } catch (Exception e) {
                    e.printStackTrace();
                }
        }
        return Query;
    }

}
