package Bussiness_layer.DAO;

import Bussiness_layer.Config;
import Bussiness_layer.DTO.Products_at_orders_DTO;
import Bussiness_layer.Passive_objects.DeliveryForm;
import Bussiness_layer.Passive_objects.Order;
import Bussiness_layer.Passive_objects.ProductAtOrder;
import Persistent_layer.DatabaseManager;
import Persistent_layer.ResultSetPrinter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class ProductsAtOrders_DAO extends Object_DAO<Products_at_orders_DTO> {
    private SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);

    public ProductsAtOrders_DAO(DatabaseManager dbManger) {
        super(dbManger);
    }

    @Override
    public synchronized boolean Insert(Products_at_orders_DTO dto_Obj) {
        try {
            String result = formatter.format(dto_Obj.getDate());
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Insert"));
            ps.setInt(1, dto_Obj.getSid());
            ps.setInt(2, dto_Obj.getStore_num());
            ps.setString(3, result);
            ps.setInt(4, dto_Obj.getProduct_id());
            ps.setInt(5, dto_Obj.getAmount());
            ps.setDouble(6,dto_Obj.getPrice_per_unit());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public synchronized void Update(Products_at_orders_DTO dto_Obj) {
        try {
            String result = formatter.format(dto_Obj.getDate());
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("Update"));
            ps.setInt(1, dto_Obj.getSid());
            ps.setInt(2, dto_Obj.getStore_num());
            ps.setString(3, result);
            ps.setDouble(4, dto_Obj.getProduct_id());
            ps.setDouble(5, dto_Obj.getAmount());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    //this function will delete only spesific product from agreement with supplier
    public synchronized boolean Delete(Products_at_orders_DTO dto_Obj) {
        try {
            String result = formatter.format(dto_Obj.getDate());
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("DeleteProduct"));
            ps.setInt(1,dto_Obj.getSid());
            ps.setInt(2,dto_Obj.getStore_num());
            ps.setString(3,result);
            ps.setInt(4,dto_Obj.getProduct_id());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    //this function will return single product in the Agreement with supplier
    public synchronized Products_at_orders_DTO Get(Products_at_orders_DTO dto_Obj) {
        ResultSet rs=null;
        try {
            String result = formatter.format(dto_Obj.getDate());
            PreparedStatement ps=conn.prepareStatement(getQueryByOperation("GetProductAtAgreement"));
            ps.setInt(1,dto_Obj.getSid());
            ps.setInt(2,dto_Obj.getStore_num());
            ps.setString(3, result);
            ps.setInt(4,dto_Obj.getProduct_id());

            rs=ps.executeQuery();
            rs.next();
        }  catch (SQLException e) {
            e.printStackTrace();
        }
        //printing the supplier to screen
        if(rs!=null){
            ResultSetPrinter.printResultSet(rs);
        }
        return convertResultSetToProductAtOrderDto(rs);
        //need handle the null situation ?
    }

    //this function will print to screen the whole Agreement with supplier
    public synchronized void Print(Products_at_orders_DTO dto_Obj) {

    }

    protected String getQueryByOperation(String operation) {

        String Query=null;
        switch (operation) {
            case "Insert":
                Query="INSERT INTO products_at_orders "
                        + "(sid, store_num, date, product_id, amount, price_per_unit) VALUES"
                        + "(?,?,?,?,?,?)";
                break;
            case "Update":
                Query="UPDATE products_at_orders "
                        + "SET amount = ?, sid = ?, store_num = ? , date= ? ,product_id= ? "
                        + "WHERE sid = ? AND store_num = ?, AND date= ?  AND product_id= ?  AND amount= ?";
                break;
            case "Delete":
                Query="DELETE FROM products_at_orders "
                        + "WHERE sid = ? AND store_num = ?, AND date= ?  AND product_id= ?  AND amount= ?";
                break;
            default:
                try {
                    throw new Exception("invalid operation type");
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("Exception: "+e.getMessage());
                }
        }
        return Query;
    }

    private Products_at_orders_DTO convertResultSetToProductAtOrderDto(ResultSet rs) {
        try {
            if(rs!=null) {
                return new Products_at_orders_DTO(  rs.getInt("sid"),
                                                    rs.getInt("store_num"),
                                                    rs.getDate("date"),
                                                    rs.getInt("product_id"),
                                                    rs.getInt("amount"),
                                                    rs.getDouble("price_per_unit"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: "+e.getMessage());
        }
        return null;
    }

    public List<DeliveryForm> getDeliveries(int store_id) {

        LinkedList<DeliveryForm> delvs = new LinkedList<>();
        try {
            Connection con = super.dbm.getConn();
            String sql = "SELECT * FROM delivery_forms WHERE revised = 0 AND store_num = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, store_id);
            PreparedStatement st1 = con.prepareStatement(sql);
            st1.setInt(1, store_id);
            ResultSet rs_c = st1.executeQuery();
            ResultSet rs = st.executeQuery();
            // loop through the result set
            while (rs.next()) {
                Date beginAt = formatter.parse(rs.getString("began_at"));
                int truckId = rs.getInt("truck_id");
                int supplierId = rs.getInt("sid");
                Date reqDate = formatter.parse(rs.getString("date"));

                DeliveryForm deliveryForm = new DeliveryForm(beginAt, String.valueOf(truckId), supplierId, store_id, reqDate);
                delvs.add(deliveryForm);
            }

            ResultSetPrinter.printResultSet(rs_c);
            rs.close();
            rs_c.close();

        } catch (SQLException e) {
            e.printStackTrace();
            return delvs;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return delvs;
    }

    public List<ProductAtOrder> getByDelivery(DeliveryForm deliveryForm) {
        LinkedList<ProductAtOrder> paos = new LinkedList<>();
        try {
            Connection con = super.dbm.getConn();
            String sql = "select products_at_orders.* from delivery_forms inner join orders on\n" +
                    "\tdelivery_forms.date=orders.date and\n" +
                    "\tdelivery_forms.sid=orders.sid and\n" +
                    "\tdelivery_forms.store_num=orders.store_num\n" +
                    "\tinner join products_at_orders on\n" +
                    "\tproducts_at_orders.date=orders.date and\n" +
                    "\tproducts_at_orders.sid=orders.sid and\n" +
                    "\tproducts_at_orders.store_num=orders.store_num\n" +
                    "\twhere orders.sid = ? and orders.store_num=? and orders.date = ?;\n";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, deliveryForm.getSupplierId());
            st.setInt(2, deliveryForm.getStoreId());
            st.setString(3, formatter.format(deliveryForm.getRequestDate()));

            ResultSet rs = st.executeQuery();
            // loop through the result set
            while (rs.next()) {
                int pid = rs.getInt("product_id");
                int amount = rs.getInt("amount");
                double price = rs.getDouble("price_per_unit");


                ProductAtOrder pao = new ProductAtOrder(amount, pid, price);
                paos.add(pao);
            }

            rs.close();


        } catch (SQLException e) {
            e.printStackTrace();
            return paos;
        }
        return paos;
    }

    public void resolveDelivery(DeliveryForm delv, String issues) {
        try {
            Connection con = super.dbm.getConn();
            String sql = "update delivery_forms set issues = ?, revised = 1 " +
            "where delivery_forms.sid = ? and delivery_forms.store_num=? and delivery_forms.date = ?;" ;
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, issues);
            st.setInt(2, delv.getSupplierId());
            st.setInt(3, delv.getStoreId());
            st.setString(4, formatter.format(delv.getRequestDate()));

            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Could'nt update delivery");
        }
    }
}
