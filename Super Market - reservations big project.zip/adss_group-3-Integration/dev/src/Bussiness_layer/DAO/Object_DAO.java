package Bussiness_layer.DAO;


import Persistent_layer.DatabaseManager;

import java.sql.Connection;

abstract public class Object_DAO<T> {
    protected DatabaseManager dbm;
    protected Connection conn;

    public Object_DAO(DatabaseManager dbm) {
        this.dbm = dbm;
        this.conn = dbm.getConn();
    }
    abstract public boolean Insert(T dtoObj);
    abstract public boolean Delete(T dtoObj);

}

