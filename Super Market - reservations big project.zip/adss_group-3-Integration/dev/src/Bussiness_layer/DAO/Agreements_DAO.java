package Bussiness_layer.DAO;

import Bussiness_layer.DTO.Agreement_DTO;
import Bussiness_layer.Passive_objects.Agreement;
import Bussiness_layer.Passive_objects.Supplier;
import Persistent_layer.DatabaseManager;
import Persistent_layer.ResultSetPrinter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class Agreements_DAO extends Object_DAO<Agreement_DTO> {

    private Connection con;

    public Agreements_DAO(DatabaseManager dbManger) {
        super(dbManger);
        con= dbManger.getConn();
    }

    @Override
    public synchronized boolean Insert(Agreement_DTO dto_Obj) {
        try {
            // (supplier_id, product_id, prod_price, discount_thres, discount_percent)
            PreparedStatement ps = con.prepareStatement(getQueryByOperation("Insert"));
            ps.setInt(1, dto_Obj.getSupplier_id());
            ps.setInt(2, dto_Obj.getProduct_id());
            ps.setDouble(3, dto_Obj.getProd_price());
            ps.setInt(4, dto_Obj.getDiscount_thres());
            ps.setDouble(5, dto_Obj.getDiscount_percent());

            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println("\nThis agreement is already been made!\n");
            return false;
        }
    }

    public synchronized void Update(Agreement_DTO dto_Obj) {
        try {
            PreparedStatement ps = con.prepareStatement(getQueryByOperation("Update"));
            ps.setDouble(1, dto_Obj.getProd_price());
            ps.setInt(2, dto_Obj.getDiscount_thres());
            ps.setDouble(3, dto_Obj.getDiscount_percent());
            ps.setInt(4, dto_Obj.getSupplier_id());
            ps.setInt(5, dto_Obj.getProduct_id());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    //this function will delete only spesific product from agreement with supplier
    public synchronized boolean Delete(Agreement_DTO dto_Obj) {
        try {
            PreparedStatement ps = con.prepareStatement(getQueryByOperation("DeleteProduct"));
            ps.setInt(1, dto_Obj.getSupplier_id());
            ps.setInt(2, dto_Obj.getProduct_id());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //this function will return single product in the Agreement with supplier
    public synchronized Agreement_DTO Get(Agreement_DTO dto_Obj) {
        ResultSet rs = null;
        try {
            PreparedStatement ps = con.prepareStatement(getQueryByOperation("GetProductAtAgreement"));
            ps.setInt(1, dto_Obj.getSupplier_id());
            ps.setInt(2, dto_Obj.getProduct_id());
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return convertResultSetToAgreementDto(rs);
    }

    // this function will get the whole agreement with Supplier
    public synchronized List<Agreement_DTO> GetAgreement(Agreement_DTO dto_Obj) {
        List<Agreement_DTO> lstProducts = new LinkedList<>();
        ResultSet rs = getResultSetBySupplier(dto_Obj.getSupplier_id());
        if (rs == null) {
            return null;
        }
        try {
            while (rs.next()) {
                lstProducts.add(convertResultSetToAgreementDto(rs));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return lstProducts;
    }

    //this function will print to screen the whole Agreement with supplier
    public synchronized void Print(Agreement_DTO dto_Obj) {
        ResultSet rs = getResultSetBySupplier(dto_Obj.getSupplier_id());
        ResultSetPrinter.printResultSet(rs);
    }

    public synchronized void printSuppliersByProductId(int productid) {
        ResultSet rs = getResultSetByProductId(productid);
        if (rs != null) {
            ResultSetPrinter.printResultSet(rs);
        }
    }

    protected String getQueryByOperation(String operation) {

        String Query = null;
        switch (operation) {
            case "Insert":
                Query = "INSERT INTO Agreements "
                        + "(supplier_id, product_id, prod_price, discount_thres, discount_percent) VALUES"
                        + "(?,?,?,?,?)";
                break;
            case "Update":
                Query = "UPDATE Agreements "
                        + "SET prod_price = ?, discount_thres = ?, discount_percent = ? "
                        + "WHERE supplier_id = ? AND product_id = ?";
                break;
            case "Delete":
                Query = "DELETE FROM Agreements "
                        + "WHERE supplier_id=? AND product_id=? AND prod_price=? AND discount_thres=? AND discount_percent=?";
                break;
            case "DeleteProduct":
                Query = "DELETE FROM Agreements "
                        + "WHERE supplier_id = ? AND product_id = ? ";
                break;
            case "GetProductAtAgreement":
                Query = "SELECT * FROM Agreements "
                        + "WHERE supplier_id = ? AND product_id = ? ";
                break;
            case "GET_Suppliers_by_prodId":
                Query = "SELECT supplier_id FROM Agreements " +
                        "WHERE product_id = ? ";
                break;
            case "GET_FULL":
                Query = "SELECT * FROM Agreements "
                        + "WHERE supplier_id = ? ";
                break;
            case "GET_Agreements_ProductID":
                Query = "SELECT * FROM Agreements " +
                        "WHERE product_id = ? ";


        }
        return Query;
    }

    private ResultSet getResultSetBySupplier(int supplier_id) {
        try {
            PreparedStatement ps = con.prepareStatement(getQueryByOperation("GET_FULL"));
            ps.setInt(1, supplier_id);
            ResultSet rs = ps.executeQuery();
            if (rs == null) {
                return null;
            }
            return rs;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
        return null;
    }

    private Agreement_DTO convertResultSetToAgreementDto(ResultSet rs) {
        try {
            if (!rs.isClosed()) {
                return new Agreement_DTO(rs.getInt("product_id"), rs.getInt("supplier_id"),
                        rs.getDouble("prod_price"),
                        rs.getInt("discount_thres"), rs.getDouble("discount_percent"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
        return null;
    }

    private ResultSet getResultSetByProductId(int productId) {

        try {
            PreparedStatement ps = con.prepareStatement(getQueryByOperation("GET_Suppliers_by_prodId"));
            ps.setInt(1, productId);
            return ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
        return null;
    }

    public synchronized List<Agreement> getAgreementsByProductID(int productId) {
        List<Agreement> lstAgreement = new LinkedList<>();
        try {
            PreparedStatement ps = con.prepareStatement(getQueryByOperation("GET_Agreements_ProductID"));
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lstAgreement.add(new Agreement(rs.getInt("product_id"), new Supplier(rs.getInt("supplier_id"), -1, "", 1,"")
                        , rs.getDouble("prod_price"), rs.getInt("discount_thres")
                        , rs.getDouble("discount_percent")));
            }
            return lstAgreement;
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
        return null;
    }

    public synchronized void printAgreements() {
        String sql = "SELECT * FROM Agreements";
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            ResultSetPrinter.printResultSet(rs);

            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public synchronized void printAgreementsWithSupplier(int supplier_num) {
        String sql = "SELECT * FROM Agreements WHERE supplier_id=(?)";
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, supplier_num);
            ResultSet rs = pstmt.executeQuery();
            //we 'clone' the result set just in order to use .next method without missing the first row.
            PreparedStatement pstmt_clone = con.prepareStatement(sql);
            pstmt_clone.setInt(1, supplier_num);
            ResultSet rs_clone = pstmt_clone.executeQuery();

            if (rs_clone.next()) {
                ResultSetPrinter.printResultSet(rs);
            } else {
                System.out.println("Error: no agreements made for supplier " + supplier_num + "\n");
                return;
            }
            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public synchronized void printSupplierByProduct(int product_id) {
        String sql = "SELECT supplier_id FROM Agreements WHERE product_id=(?)";
        try {

            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, product_id);
            ResultSet rs = pstmt.executeQuery();
            //we 'clone' the result set just in order to use .next method without missing the first row.
            PreparedStatement pstmt_clone = con.prepareStatement(sql);
            pstmt_clone.setInt(1, product_id);
            ResultSet rs_clone = pstmt_clone.executeQuery();

            if (rs_clone.next()) {
                ResultSetPrinter.printResultSet(rs);
            } else
                System.out.println("\nError: no supplier for product id " + product_id + "\n");

            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
