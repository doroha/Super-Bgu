package Bussiness_layer.DAO;


import Bussiness_layer.DTO.Contact_DTO;
import Persistent_layer.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Contacts_DAO extends Object_DAO<Contact_DTO> {

    public Contacts_DAO(DatabaseManager dbManger) {
        super(dbManger);
    }

    @Override
    public synchronized boolean Insert(Contact_DTO dto_Obj) {
        try {
            PreparedStatement ps = conn.prepareStatement(getQueryByOperation("Insert"));
            ps.setInt(1, dto_Obj.getCid());
            ps.setInt(2, dto_Obj.getSid());
            ps.setString(3, dto_Obj.getFirst_name());
            ps.setString(4, dto_Obj.getLast_name());
            ps.setString(5, dto_Obj.getPhone());
            ps.setString(6, dto_Obj.getEmail());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public synchronized void Update(Contact_DTO dto_Obj) {
        try {
            PreparedStatement ps = conn.prepareStatement(getQueryByOperation("Update"));
            ps.setString(1, dto_Obj.getFirst_name());
            ps.setString(2, dto_Obj.getLast_name());
            ps.setString(3, dto_Obj.getPhone());
            ps.setString(4, dto_Obj.getEmail());
            ps.setInt(5, dto_Obj.getCid());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public synchronized boolean Delete(Contact_DTO dto_Obj) {
        try {
            PreparedStatement ps = conn.prepareStatement(getQueryByOperation("Delete"));
            ps.setInt(1, dto_Obj.getCid());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public synchronized Contact_DTO Get(Contact_DTO dto_Obj) {
        //not implemented
        return null;
    }

    public synchronized void Print(Contact_DTO dto_Obj) {
        //not implemented yet.
    }

    protected String getQueryByOperation(String operation) {
        String Query = null;
        switch (operation) {
            case "Insert":
                Query = "INSERT INTO contacts "
                        + "(cid, sid, first_name, last_name, phone_num, email) VALUES"
                        + "(?,?,?,?,?,?)";
                break;
            case "Update":
                Query = "UPDATE contacts "
                        + "SET first_name = ?, last_name = ?, phone_num = ?, email = ? "
                        + "WHERE cid = ?";
                break;
            case "Delete":
                Query = "DELETE FROM contacts "
                        + "WHERE cid = ?";
                break;

            default:
                try {
                    throw new Exception("in valid operation type");
                } catch (Exception e) {
                    e.printStackTrace();
                }
        }
        return Query;

    }


}
