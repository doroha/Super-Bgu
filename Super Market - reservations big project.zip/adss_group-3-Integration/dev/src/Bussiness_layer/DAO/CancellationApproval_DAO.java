package Bussiness_layer.DAO;

import Bussiness_layer.Config;
import Bussiness_layer.DTO.CancellationApproval_DTO;
import Persistent_layer.DatabaseManager;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

public class CancellationApproval_DAO extends Object_DAO<CancellationApproval_DTO> {
    public CancellationApproval_DAO(DatabaseManager dbm) {
        super(dbm);
    }
    private SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);
    @Override
    public boolean Insert(CancellationApproval_DTO dtoObj) {
        String date = formatter.format(dtoObj.getTime());
        try {
            String Query="INSERT INTO orders_Cancellation_Approvals "
                    + "(sid, store_num, date,storeKeeperApproved,TransportMangerApproved,HrManagerApproved) VALUES"
                    + "(?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(Query);
            ps.setInt(1, dtoObj.getSid());
            ps.setInt(2, dtoObj.getStore_num());
            ps.setString(3,date);
            ps.setInt(4, dtoObj.getApprovedByStoreKeeper());
            ps.setInt(5, dtoObj.getApprovedByTransportManager());
            ps.setInt(6, dtoObj.getApprovedByHrManager());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean Update(CancellationApproval_DTO dtoObj) {
        try {
            String date = formatter.format(dtoObj.getTime());
            String  Query = "UPDATE orders_Cancellation_Approvals "
                    + "SET storeKeeperApproved = ?, TransportMangerApproved = ?, HrManagerApproved = ? "
                    + "WHERE sid = ? AND store_num = ? AND date = ?";
            PreparedStatement ps = conn.prepareStatement(Query);
            ps.setInt(1, dtoObj.getApprovedByStoreKeeper());
            ps.setInt(2, dtoObj.getApprovedByTransportManager());
            ps.setInt(3,dtoObj.getApprovedByHrManager());
            ps.setInt(4, dtoObj.getSid());
            ps.setInt(5, dtoObj.getStore_num());
            ps.setString(6, date);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

    }

    @Override
    public boolean Delete(CancellationApproval_DTO dtoObj) {
        try {
            String date = formatter.format(dtoObj.getTime());
            String Query="DELETE FROM orders_Cancellation_Approvals "
                    + "WHERE sid=? AND store_num=? AND date=?";
            PreparedStatement ps = conn.prepareStatement(Query);
            ps.setInt(1, dtoObj.getSid());
            ps.setInt(2, dtoObj.getStore_num());
            ps.setString(3, date);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}

