package Bussiness_layer.DAO;

import Bussiness_layer.Config;
import Bussiness_layer.Passive_objects.Driver;
import Bussiness_layer.Passive_objects.Worker;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Helper;
import Persistent_layer.Queries;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Driver_DAO extends Object_DAO<Driver> {

    public Driver_DAO(DatabaseManager dbm) {
        super(dbm);
    }

    @Override
    public boolean Insert(Driver dtoObj) {
        if (dtoObj == null) { return false; }
        boolean ans = false;
        Worker_DAO worker = new Worker_DAO(dbm);
        worker.Insert(dtoObj.getWorker());
        try {
            String query = Queries.insert_driver;
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, dtoObj.getSsn());
            stmt.setInt(2, dtoObj.getLicenseType());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to insert a driver.");
            }
            else {
                ans = true;
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    @Override
    public boolean Delete(Driver dtoObj) {
        boolean ans = false;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.delete_driver_by_ssn);
            stmt.setInt(1, dtoObj.getSsn());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to delete a driver.");
            }
            else {
                Worker_DAO worker_dao = new Worker_DAO(dbm);
               ans =  worker_dao.Delete(new Worker(dtoObj.getSsn(), "", "", 0, "", "", 0, 0, ""));
            }
            stmt.close();
        } catch (SQLException e) {
            ans = false;
            e.printStackTrace();
        }
        return ans;
    }

    public boolean freeDriver(int ssn) {
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.driver_release);
            stmt.setInt(1, ssn);
            if (stmt.executeUpdate() != 1) {
                return false;
            }
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String getDriverName(int ssn)
    {
        String name = "";
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.driver_name);
            stmt.setInt(1, ssn);
            ResultSet res = stmt.executeQuery();
            if(res.next())
            {
                name = "" + res.getString(1) +" "+ res.getString(2);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return name;
    }

    public Driver getDriverForWeightOf(int totalWeight) {
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.select_driver);
            stmt.setInt(1,dbm.getShiftType());
            stmt.setInt(2, totalWeight <= Config.TYPE_0_LICENSE_MAX_WEIGHT ? 0 : 1);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                Worker_DAO wdao = new Worker_DAO(dbm);
                Driver d = new Driver(res.getInt("license_type"), res.getInt("occupied"), wdao.getWorker(res.getInt("ssn")));
                PreparedStatement stmt2 = conn.prepareStatement(Queries.driver_occupation);
                stmt2.setInt(1, res.getInt("ssn"));
                if (stmt2.executeUpdate() != 1) {
                    return null;
                }
                stmt2.close();
                stmt.close();
                return d;
            }
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean driverExist(int ssn) {
        ResultSet rs;
        boolean ans;
        try {
            PreparedStatement st = conn.prepareStatement(Queries.getDriverBySsn);
            st.setInt(1, ssn);
            rs = st.executeQuery();
            ans = rs.next();
            rs.close();
        } catch (SQLException e) {
            return false;
        }
        return ans;
    }
}
