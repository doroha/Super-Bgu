package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.Shift;
import Bussiness_layer.Passive_objects.Worker;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;
import Persistent_layer.ResultSetPrinter;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;


public class Shift_DAO extends Object_DAO<Shift> {

    public Shift_DAO(DatabaseManager dbm) {
        super(dbm);
    }

    @Override
    public boolean Insert(Shift dtoObj) {
        Delete(dtoObj); // If already exists, first remove old.
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.shift_insert);
            ps.setInt(1, dtoObj.getSsn());
            ps.setString(2, dtoObj.getDateTime());
            ps.setInt(3, dtoObj.getShift_type());
            if (ps.executeUpdate() != 1) {
                System.out.println("Failed to insert Shift");
            }
            else {
                ans = true;
            }
            ps.close();
        } catch (SQLException e) {
            System.out.println("Failed to insert a shift");
        }
        return ans;
    }

    @Override
    public boolean Delete(Shift dtoObj) {
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.delete_shift_by_date_ssn);
            ps.setString(1,"%"+dtoObj.getDate()+"%");
            ps.setInt(2, dtoObj.getSsn());
            if (ps.executeUpdate() == 1) {
                ans = true;
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public void printShift(int ssn) {
        try {
            PreparedStatement pstmt = conn.prepareStatement(Queries.getShiftBySsn);
            pstmt.setInt(1, ssn);
            ResultSet rs = pstmt.executeQuery();
            //we 'clone' the result set just in order to use .next method without missing the first row.
            PreparedStatement pstmt_clone = conn.prepareStatement(Queries.getShiftBySsn);
            pstmt_clone.setInt(1,ssn);
            ResultSet rs_clone = pstmt_clone.executeQuery();

            if (rs_clone.next()) {
                ResultSetPrinter.printResultSet(rs);
            } else
                System.out.println("Error: there is no shift " + ssn + "\n");
            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public LinkedList<Shift> getShifts() {
        LinkedList<Shift> r = new LinkedList<>();
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.get_all_shifts);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                r.add(new Shift(
                        rs.getInt("ssn"),
                        rs.getString("date"),
                        rs.getInt("shift_type"))
                );
            }
        } catch (SQLException e) {
            System.out.println("Failed to fetch shifts");
        }
        return r;
    }

    public LinkedList<Integer> getWorkersOfShift(String date, int shift_type) {
        LinkedList<Integer> res = null;
        try {
            PreparedStatement pstmt = conn.prepareStatement(Queries.get_shift_by_date_type_or_double);
            pstmt.setString(1, "%" + date + "%");
            pstmt.setInt(2, shift_type);
            ResultSet rs = pstmt.executeQuery();
            res = new LinkedList<>();
            while (rs.next()) {
                res.add(rs.getInt("ssn"));
            }
            pstmt.close();
            rs.close();
        } catch (SQLException var4) {
            System.out.println("Failed to fetch in getWorkersOfShift");
        }
        return res;
    }

    public LinkedList<Shift> getShiftsOfWorker(int ssn) {
        LinkedList<Shift> res = null;
        try {
            PreparedStatement pstmt = conn.prepareStatement(Queries.getShiftBySsn);
            pstmt.setInt(1, ssn);
            ResultSet rs = pstmt.executeQuery();
            res = new LinkedList<>();
            while (rs.next()) {
                res.add(new Shift(
                        rs.getInt("ssn"),
                        rs.getString("date"),
                        rs.getInt("shift_type"))
                );
            }
            pstmt.close();
            rs.close();
        } catch (SQLException var4) {
            System.out.println("Failed to fetch in getShiftsOfWorker");
        }
        return res;
    }

    public void DeleteAllWorkerShifts(Worker w) {
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.delete_shift_by_ssn);
            ps.setInt(1, w.getSsn());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

