package Bussiness_layer.DAO;


import Bussiness_layer.Passive_objects.Order;
import Bussiness_layer.Passive_objects.Product;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;
import Persistent_layer.ResultSetPrinter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class ProductDAO {
    private DatabaseManager dbmg;

    public ProductDAO(DatabaseManager dbmg) {
        this.dbmg = dbmg;
    }

    public boolean isExists(int id) {
        boolean ans;
        try {
            PreparedStatement st = dbmg.getConn().prepareStatement(Queries.get_product_by_id);
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            ans = rs.next();
            rs.close();
        } catch (SQLException e) {
            return false;
        }
        return ans;
    }

    public Product getProductById(int id) {
        Product prod = null;
        try {
            Connection con = dbmg.getConn();
            String sql = Queries.get_product_by_id;
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            // loop through the result set
            if (rs.next()) {
                int pid = rs.getInt("id");
                int weight = rs.getInt("weight");
                String name = rs.getString("name");
                int st_amount = rs.getInt("st_amount");
                int sh_amount = rs.getInt("Sh_amount");
                int Last_category = rs.getInt("last_category");
                int minimal_amount = rs.getInt("minimal_amount");
                String location = rs.getString("location");
                int storeid = rs.getInt("store_num");
                String producer = rs.getString("producer");
                int selling_cost = rs.getInt("selling_cost");
                int discount_cost = rs.getInt("discount_cost");
                String end_date = rs.getString("end_discount");
                prod = new Product(pid, weight, name, st_amount, sh_amount, Last_category, minimal_amount, location, storeid, producer, selling_cost, discount_cost, end_date);
            }
            return prod;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public synchronized List<Product> getAllByStoreId(int store_id) {
        LinkedList<Product> prod = new LinkedList<>();
        try {
            Connection con = dbmg.getConn();
            String sql = "SELECT * FROM products WHERE store_num = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, store_id);
            ResultSet rs = st.executeQuery();
            // loop through the result set
            while (rs.next()) {
                int pid = rs.getInt("id");
                int weight = rs.getInt("weight");
                String name = rs.getString("name");
                int st_amount = rs.getInt("st_amount");
                int sh_amount = rs.getInt("Sh_amount");
                int Last_category = rs.getInt("last_category");
                int minimal_amount = rs.getInt("minimal_amount");
                String location = rs.getString("location");
                int storeid = rs.getInt("store_num");
                String producer = rs.getString("producer");
                int selling_cost = rs.getInt("selling_cost");
                int discount_cost = rs.getInt("discount_cost");
                String end_date = rs.getString("end_discount");
                Product cur_product = new Product(pid, weight, name, st_amount, sh_amount, Last_category, minimal_amount, location, storeid, producer, selling_cost, discount_cost, end_date);
                prod.add(cur_product);

            }
        } catch (SQLException e) {
            e.printStackTrace();
            return prod;
        }
        return prod;
    }

    public synchronized void update(Product p) {
        try {
            Connection con = dbmg.getConn();
            String sql = "UPDATE products SET name = ?, st_amount = ?, sh_amount = ?," +
                    "last_category = ?, minimal_amount = ?, location = ?," +
                    "producer = ?, selling_cost = ?, " +
                    "discount_cost = ?, end_discount = ?, weight = ? " +
                    "WHERE id=? and store_num =?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, p.getName());
            st.setInt(2, p.getStock_amount());
            st.setInt(3, p.getShelf_amount());
            st.setInt(4, p.getLast_sub_category());
            st.setInt(5, p.getMinimal_amount());
            st.setString(6, p.getLocation());
            st.setString(7, p.getProducer());
            st.setInt(8, p.getSelling_cost());
            st.setInt(9, p.getDiscount_cost());
            st.setString(10, p.getEnd_discount());
            st.setInt(11,p.getWeight());
            st.setInt(12, p.getId());
            st.setInt(13, p.getStoreNumber());
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Could'nt update product in the ID: " + p.getId());
        }
    }

    public synchronized boolean insert(Product p) {
        try {
            Connection con = dbmg.getConn();
            String sql = "INSERT INTO Products(id,name,st_amount,sh_amount" +
                    ",last_category,minimal_amount,location,store_num,producer," +
                    "selling_cost,discount_cost,end_discount,weight) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, p.getId());
            st.setString(2, p.getName());
            st.setInt(3, p.getStock_amount());
            st.setInt(4, p.getShelf_amount());
            st.setInt(5, p.getLast_sub_category());
            st.setInt(6, p.getMinimal_amount());
            st.setString(7, p.getLocation());
            st.setInt(8, p.getStoreNumber());
            st.setString(9, p.getProducer());
            st.setInt(10, p.getSelling_cost());
            st.setInt(11, p.getDiscount_cost());
            st.setString(12, p.getEnd_discount());
            st.setInt(13,p.getWeight());
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }

        return true;
    }

    public synchronized void delete(Product prod) {

        try {
            Connection con = dbmg.getConn();
            String sql = "DELETE FROM products WHERE id = ? AND store_num = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, prod.getId());
            st.setInt(2, prod.getStoreNumber());

            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Could'nt delete product in the ID: " + prod.getId());
        }

    }

    public synchronized void printProducts() {
        String sql = "SELECT id,name,store_num,last_category,producer FROM products";
        Connection con = dbmg.getConn();
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            ResultSetPrinter.printResultSet(rs);
            pstmt.close();
            rs.close();

        } catch (SQLException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

    public synchronized void Print(Product p) {
        try {
            Connection con = dbmg.getConn();
            //the same as for the "get query", but another purpose.
            PreparedStatement ps = con.prepareStatement("SELECT * FROM products WHERE PID = ? ");
            ps.setInt(1, p.getId());
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                System.out.println("\nError: No matches found!\n");
                return;
            }
            ResultSetPrinter.printResultSet(rs);
            ps.close();
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
        }
    }

    // return -1 if no products stored in the database
    public synchronized int getMaxMinimalAmount() {
        int maxMinimal;
        try {
            Connection con = dbmg.getConn();
            String sql = "SELECT MAX(minimal_amount) FROM products";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            if (!rs.next()) {
                // No products in database
                return -1;
            }

            maxMinimal = rs.getInt("MAX(minimal_amount)");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Exception: " + e.getMessage());
            maxMinimal = 0;
        }

        return maxMinimal;
    }
}
