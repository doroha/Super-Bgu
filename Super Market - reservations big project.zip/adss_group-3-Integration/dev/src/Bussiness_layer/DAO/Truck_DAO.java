package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.Truck;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Truck_DAO extends Object_DAO<Truck> {

    public Truck_DAO(DatabaseManager dbm) {
        super(dbm);
    }

    @Override
    public boolean Insert(Truck dtoObj) {
        if (dtoObj == null) {
            return false;
        }
        boolean ans = false;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.truck_insert);
            stmt.setString(1, dtoObj.getPlateId());
            stmt.setInt(2, dtoObj.getModel());
            stmt.setInt(3, dtoObj.getNetWeight());
            stmt.setInt(4, dtoObj.getMaxWeight());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to insert a truck.");
            } else {
                ans = true;
            }
            stmt.close();
        } catch (SQLException e) {
            System.out.println("A truck with that plate id already exists");
        }
        return ans;
    }

    @Override
    public boolean Delete(Truck dtoObj) {
        boolean ans = false;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.delete_truck_by_id);
            stmt.setString(1, dtoObj.getPlateId());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to delete a truck.");
            } else {
                ans = true;
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public Truck getTruckForWeightOf(int totalWeight) {
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.get_truck);
            stmt.setInt(1, totalWeight);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                Truck t = new Truck(res.getString("plate_id"), res.getInt("model"), res.getInt("net_weight"), res.getInt("max_weight"));
                PreparedStatement stmt2 = conn.prepareStatement(Queries.truck_occupation);
                stmt2.setString(1, res.getString("plate_id"));
                if (stmt2.executeUpdate() != 1) {
                    return null;
                }
                stmt2.close();
                stmt.close();
                return t;
            }
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean freeTruck(String plate_id) {
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.truck_release);
            stmt.setString(1, plate_id);
            if (stmt.executeUpdate() != 1) {
                return false;
            }
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
