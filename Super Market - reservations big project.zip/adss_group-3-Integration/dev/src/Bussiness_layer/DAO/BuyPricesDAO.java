package Bussiness_layer.DAO;


import Bussiness_layer.Passive_objects.BuyPrice;
import Persistent_layer.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class BuyPricesDAO {
    private DatabaseManager dbmg;
    private int highestID;

    public BuyPricesDAO(DatabaseManager dbmg) {
        this.dbmg = dbmg;

        try{
            Connection con = dbmg.getConn();
            String sql = "SELECT MAX(order_num) FROM Buy_prices";
            PreparedStatement st = con.prepareStatement(sql);
            ResultSet rs= st.executeQuery();
            rs.next();
            highestID = rs.getInt("MAX(order_num)");

        }
        catch (SQLException e)
        {
            highestID = 0;
        }
    }

    public synchronized void insert(int storeNumber, int PID, int price, int amount) {
        try{
            highestID++;
            Connection con = dbmg.getConn();
            String sql = "INSERT INTO Buy_prices" +
                    "(order_num,PID,store_num,buy_price,current_amount) values" +
                    "(?,?,?,?,?);";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,highestID);
            st.setInt(2,PID);
            st.setInt(3, storeNumber);
            st.setInt(4, price);
            st.setInt(5, amount);

            st.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println("Could'nt insert buy order in the PID: "+PID);
            highestID--;
        }
    }

    public synchronized List<BuyPrice> getBuyPricesByID(int storeNumber, int PID) {
        List<BuyPrice> result = new LinkedList<>();
        try{
            Connection con = dbmg.getConn();
            String sql = "SELECT * FROM Buy_prices WHERE store_num = ? AND PID = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1,storeNumber);
            st.setInt(2,PID);
            ResultSet rs= st.executeQuery();
            // loop through the result set
            while (rs.next()) {
                int orderNum = rs.getInt("order_num");
                int buyPrice = rs.getInt("buy_price");
                int currAmount = rs.getInt("current_amount");
                BuyPrice bp = new BuyPrice(orderNum, storeNumber,PID, buyPrice, currAmount);
                result.add(bp);

            }
        }
        catch (SQLException e)
        {
            return result;
        }
        return result;
    }

    public synchronized void update(BuyPrice bp) {
        try{
            Connection con = dbmg.getConn();
            String sql = "UPDATE Buy_prices SET PID = ?, store_num = ?, buy_price = ?," +
                    "current_amount = ?" +
                    "WHERE order_num =?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, bp.getPID());
            st.setInt(2,bp.getStoreNumber());
            st.setInt(3,bp.getBuyPrice());
            st.setInt(4,bp.getCurrentAmount());
            st.setInt(5, bp.getOrderNumber());

            st.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println("Could'nt update buy price in the ID: "+bp.getOrderNumber());
        }
    }

    public synchronized void delete(BuyPrice bp) {
        try{
            Connection con = dbmg.getConn();
            String sql = "DELETE FROM Buy_prices WHERE order_num =?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, bp.getOrderNumber());

            st.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println("Could'nt delete buy price in the ID: "+bp.getOrderNumber());
        }
    }
}
