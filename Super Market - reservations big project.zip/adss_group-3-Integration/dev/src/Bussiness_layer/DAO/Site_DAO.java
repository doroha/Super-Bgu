package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.Site;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Site_DAO extends Object_DAO<Site> {

    public Site_DAO(DatabaseManager dbm) {
        super(dbm);
    }

    @Override
    public boolean Insert(Site dtoObj) {
        if (dtoObj == null) {
            return false;
        }
        boolean ans = false;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.site_insert);
            stmt.setString(1, dtoObj.getAddress());
            stmt.setString(2, dtoObj.getPhone());
            stmt.setString(3, dtoObj.getAreaCode());
            stmt.setString(4, dtoObj.getContactName());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to insert a site.");
            } else {
                ans = true;
            }
            stmt.close();
        } catch (SQLException e) {
            System.out.println("A site with that address already exists");
        }
        return ans;
    }

    public Site getDestSite(int supId) {
        Site s = null;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.siteBySupplierId);
            ps.setInt(1, supId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                s = new Site(rs.getString("address"), rs.getString("phone"), rs.getString("area"), rs.getString("contact_name"));
            }
            rs.close();
            ps.close();
        } catch (SQLException e) {
            System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
        }
        return s;
    }

    @Override
    public boolean Delete(Site dtoObj) {
        boolean ans = false;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.delete_site_by_address);
            stmt.setString(1, dtoObj.getAddress());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to delete a site.");
            } else {
                ans = true;
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public boolean isExist(String addr) {
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.site_by_id);
            ps.setString(1, addr);
            ResultSet rs = ps.executeQuery();
            ans = rs.next();
            rs.close();
        } catch (SQLException e) {
            System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
        }
        return ans;
    }

    public boolean isAllocated(String addr) {
        boolean ans = false;
        try {
            PreparedStatement ps = conn.prepareStatement(Queries.site_inner_stores_by_id);
            ps.setString(1, addr);
            ResultSet rs = ps.executeQuery();
            ans = rs.next();
            rs.close();
        } catch (SQLException e) {
            System.out.println(String.format("isExist threw an error: %s", e.getMessage()));
        }
        return ans;
    }
}
