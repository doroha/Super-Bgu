package Bussiness_layer.DAO;

import Bussiness_layer.Passive_objects.User;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Queries;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class User_DAO extends Object_DAO<User> {
    public User_DAO(DatabaseManager dbm) {
        super(dbm);
    }

    @Override
    public boolean Insert(User dtoObj) {
        if (dtoObj == null) { return false; }
        boolean ans = false;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.insert_user);
            stmt.setString(1, dtoObj.getUsername());
            stmt.setString(3, dtoObj.getPassword());
            stmt.setInt(4, dtoObj.permissionLevel());
            stmt.setInt(2, dtoObj.getSsn());

            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to insert a user.");
            }
            else {
                ans = true;
            }
            stmt.close();
        } catch (SQLException e) {
            System.out.println("A user with that username already exists");
        }
        return ans;
    }

    @Override
    public boolean Delete(User dtoObj) {
        boolean ans = false;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.delete_user_by_ssn);
            stmt.setInt(1, dtoObj.getSsn());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to delete a user.");
            }
             else {
                 ans = true;
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ans;
    }

    public boolean updatePassword(User user) {
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.update_user_password);
            stmt.setString(1, user.getUsername());
            if (stmt.executeUpdate() != 1) {
                System.out.println("Failed to set user password.");
                return false;
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return true;
    }
}
