package Bussiness_layer;

import Bussiness_layer.DAO.Driver_DAO;
import Bussiness_layer.DAO.Truck_DAO;
import Bussiness_layer.Passive_objects.DeliveryForm;
import Bussiness_layer.Passive_objects.Driver;
import Bussiness_layer.Passive_objects.Order;
import Bussiness_layer.Passive_objects.Truck;
import Persistent_layer.AppendHelper;
import Persistent_layer.DatabaseManager;

import java.util.List;
import java.util.Timer;
import java.util.function.BinaryOperator;
import java.util.stream.IntStream;

public class MovingShipment {
    private Driver driver;
    private Truck truck;
    private List<Order> orders;
    private List<DeliveryForm> forms;

    public MovingShipment(Driver driver, Truck truck, List<Order> orders, List<DeliveryForm> forms) {
        this.driver = driver;
        this.truck = truck;
        this.orders = orders;
        this.forms = forms;
    }

    public Timer beginSimulation(DatabaseManager dbm) {
        Truck_DAO truck_dao = new Truck_DAO(dbm);
        Driver_DAO driver_dao = new Driver_DAO(dbm);
        Timer timer = new Timer();
        int iterIdx = 0;
        // The array thing is a trick to be able to update the currentWeight within the inner class.
        final Integer[] currentWeight = {orders.stream().map(Order::getTotalWeight).reduce(0, (weight, acc) -> acc + weight)};
        for (DeliveryForm form : forms) {
            timer.schedule(new SimulationTimer(driver, truck, form, iterIdx, orders.get(iterIdx).getTotalWeight(), orders.size()) {
                @Override
                public void run() {
                    int afterWeight = currentWeight[0] - orders.get(getRouteIdx()).getTotalWeight();
                    AppendHelper.append(String.format("Shipment<%d> to Store <%s> was arrived. Before products weight: <%d>, After products weight: <%d>", getRouteIdx(), getForm().getStoreId(), currentWeight[0], afterWeight));
                    currentWeight[0] = afterWeight;
                    if (!dbm.updateFormWithTruckWeight(getTruck(), getForm(), afterWeight)) {
                        AppendHelper.append(String.format("Failed to update Shipment<%d> form weight", getRouteIdx()));
                    }
                    if (getNumOfOrders() - 1 == getRouteIdx()) {
                        driver_dao.freeDriver(getDriver().getSsn());
                        truck_dao.freeTruck(getTruck().getPlateId());
                        AppendHelper.append("Shipment finalized, all resources are cleared.");
                    }
                }
            }, (iterIdx+1)*Config.SAME_REGION_DELIVERY_TIME);
            iterIdx++;
        }
        return timer;
    }

    public Driver getDriver() {
        return driver;
    }

    public Truck getTruck() {
        return truck;
    }

    public List<Order> getOrders() {
        return orders;
    }

    public List<DeliveryForm> getForms() {
        return forms;
    }
}
