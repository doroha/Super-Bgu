package Bussiness_layer;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseConnector {

    private static DatabaseConnector dbm;
    private static Connection conn;

    public static Connection getConn(String dbPath) {
        if(dbm == null) {
            dbm = new DatabaseConnector();
            conn = dbm.connect(dbPath);
        }
        return conn;
    }

    private Connection connect(String dbPath) {
        try {
            Class.forName("org.sqlite.JDBC");
            String connSting = "jdbc:sqlite:" + dbPath;
            conn = DriverManager.getConnection(connSting);
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
}
