package Bussiness_layer;

import Bussiness_layer.DAO.BuyPricesDAO;
import Bussiness_layer.DAO.DamagedItemsDAO;
import Bussiness_layer.DAO.ProductDAO;
import Bussiness_layer.DAO.SellingsDAO;
import Bussiness_layer.Passive_objects.BuyPrice;
import Bussiness_layer.Passive_objects.DamagedProduct;
import Bussiness_layer.Passive_objects.Product;
import Bussiness_layer.Passive_objects.SoldProduct;
import Persistent_layer.DatabaseManager;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

class Product_Container {
    private int storeNumber;
    private HashMap<Integer, Product> products;
    private List<SoldProduct> soldProducts;
    private LinkedList<DamagedProduct> damagedProducts;
    private ProductDAO productDAO;
    private SellingsDAO sellingsDAO;
    private BuyPricesDAO buyPricesDAO;
    private DamagedItemsDAO damagedItemsDAO;

    Product_Container(DatabaseManager dbmg) {
        productDAO = new ProductDAO(dbmg);
        sellingsDAO = new SellingsDAO(dbmg);
        buyPricesDAO = new BuyPricesDAO(dbmg);
        damagedItemsDAO = new DamagedItemsDAO(dbmg);

        storeNumber = -1;
    }

    public void printAllProducts_Dao(){
        productDAO.printProducts();
    }

    void setStoreNumber(int storeNumber) {
        if (this.storeNumber != storeNumber) {
            this.storeNumber = storeNumber;
            products = new HashMap<>();
            soldProducts = new LinkedList<>();
            damagedProducts = new LinkedList<DamagedProduct>();

            for (Product p :productDAO.getAllByStoreId(storeNumber)){
                products.put(p.getId(), p);
            }
            soldProducts = sellingsDAO.getAllByStoreId(storeNumber);
            damagedProducts = damagedItemsDAO.getAllByStoreId(storeNumber);
        }
    }

    int getMaxMinimalAmount() {
        return productDAO.getMaxMinimalAmount();
    }

    List<Product> getProducts() {
        return new LinkedList<>(products.values());
    }

    List<SoldProduct> getSoldProducts() {
        return soldProducts;
    }

    LinkedList<DamagedProduct> getDamagedProducts() {
        return damagedProducts;
    }

    Product getProduct(int PID) {
        return products.get(PID);
    }

    void buyProduct(Product p, Double price, int amount) {
        int newAmount = p.getStock_amount() + amount;
        p.setStock_amount(newAmount);
        productDAO.update(p);
    }

    void sellProduct(Product p, int amount, int discount) {
        int newStockAmount = p.getStock_amount();
        int newShelfAmount = p.getShelf_amount() - amount;
        if (newShelfAmount < 0) {
            newShelfAmount += newStockAmount;
            newStockAmount = 0;
        }

        p.setStock_amount(newStockAmount);
        p.setShelf_amount(newShelfAmount);
        productDAO.update(p);

        int sellPrice = p.getSelling_cost();
        if (discount>0) {
            sellPrice = (sellPrice * discount) / 100;
        }
        List<BuyPrice> buyPrices = buyPricesDAO.getBuyPricesByID(p.getStoreNumber(),p.getId());
        Iterator<BuyPrice> buyPriceItr = buyPrices.iterator();
        while (amount > 0 && buyPriceItr.hasNext()) {
            BuyPrice currBuyPrice = buyPriceItr.next();
            int buyPrice = currBuyPrice.getBuyPrice();
            int currAmountForPrice = currBuyPrice.getCurrentAmount();
            int soldAmount = amount;

            if (amount < currAmountForPrice) {
                amount = 0;
                currBuyPrice.setCurrentAmount(currAmountForPrice-amount);
                buyPricesDAO.update(currBuyPrice);
            } else {
                amount-=currAmountForPrice;
                soldAmount = currAmountForPrice;
                buyPricesDAO.delete(currBuyPrice);
            }

            SoldProduct sp = new SoldProduct(p.getId(), p.getStoreNumber(), buyPrice, sellPrice, soldAmount);
            soldProducts.add(sp);
            sellingsDAO.insert(sp);
        }
    }

    String stringofproducts() {
        String result = "";
        result = result +"=====================================\n";
        for (Product p : products.values()) {
            result = result +p.to_string();
            result = result +"\n=====================================\n";
        }
        return result;
    }
    void update_discount(int storeNumber, int pid, int precentage, String end_date)
    {
        Product prod = products.get(pid);
        if (prod != null) {
            prod.setDiscount_cost(precentage);
            prod.setEnd_discount(end_date);
            productDAO.update(prod);
        }
    }

    String stringOfProductsByCategories(List<Integer> categories) {
        String result = "";
        for (Product p: products.values()) {
            if (categories.contains(p.getLast_sub_category())) {
                result = result + p.to_string() + "\n";
            }
        }

        return result;
    }

    List<Product> getCriticalProducts() {
        List<Product> criticalP = new LinkedList<>();
        for (Product p: products.values()) {
            if (p.getStock_amount()+p.getShelf_amount()<p.getMinimal_amount()) {
                criticalP.add(p);
            }
        }
        return criticalP;
    }

    public int getsehlfamount(int pid)
    {
        Product p = products.get(pid);
        if (p == null) {
            return -1;
        }
        return p.getShelf_amount();
    }
    public void reduce_adddmg(int pid, int amount)
    {
        Product p = products.get(pid);
        if (p == null) {
            System.out.println("PID not found");
            return;
        }
        p.setShelf_amount(p.getShelf_amount()-amount);
        if(p.getShelf_amount() == 0)
        {
            p.setShelf_amount(p.getStock_amount());
            p.setStock_amount(0);
        }
        productDAO.update(p);
        DamagedProduct dmg = finddmgproduct(pid);
        if(dmg == null)
        {
            dmg = new DamagedProduct(pid,storeNumber,p.getLocation(),amount);
            damagedProducts.add(dmg);
            damagedItemsDAO.insert(dmg);
        }
        else
        {
            dmg.setAmount(dmg.getAmount()+amount);
            damagedItemsDAO.update(dmg);

        }

    }
    private DamagedProduct finddmgproduct(int pid)
    {
        for (DamagedProduct d_product:damagedProducts)
        {
            if(d_product.getPid()==pid){return d_product;}

        }
        return null;
    }
    public void insert(int product_id, int weight, String name,int category,int minimal_amount,String location,int storedID,String producer,int price)
    {
        Product p = new Product(product_id,weight, name,0,0,category,minimal_amount,location,storedID,producer,price,0,null);
        if (productDAO.insert(p)) {
            products.put(p.getId(),p);
        }
    }
    public boolean id_exsist(int pid)
    {
        return products.containsKey(pid);
    }

    public void deleteProduct(int pid) {
        Product p = products.get(pid);
        if (p != null) {
            products.remove(pid);
            productDAO.delete(p);
        } else {
            System.out.println("Could not found the product, is it yours?");
        }
    }
}
