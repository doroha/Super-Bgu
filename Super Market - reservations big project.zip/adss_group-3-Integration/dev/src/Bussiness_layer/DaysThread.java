package Bussiness_layer;

import Persistent_layer.AppendHelper;
import Persistent_layer.Queries;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DaysThread implements Runnable {

    private int day = 0;
    private boolean shouldStop = false;
    private Connection conn;
    private int sleepCount = 0;

    public DaysThread(Connection conn) {
        this.conn = conn;
    }

    @Override
    public synchronized void run() {
        while (!shouldStop) {
            try {
                Thread.sleep(1000);
                sleepCount++;
                if (Config.seconds_per_day == sleepCount) {
                    sleepCount = 0;
                    day++;
                    AppendHelper.append(String.format("Day %d began", day));
                    updateExpiredOrdersWithMin1();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateExpiredOrdersWithMin1() {
        try {
            PreparedStatement pstmt = conn.prepareStatement(Queries.expired_orders_update_min1);
            pstmt.setInt(1, day);
            pstmt.executeUpdate();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getDay() {
        return day;
    }

    public void stop() {
        shouldStop = true;
    }
}
