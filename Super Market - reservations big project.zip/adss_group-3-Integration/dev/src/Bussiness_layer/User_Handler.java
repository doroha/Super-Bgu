package Bussiness_layer;


import Bussiness_layer.DAO.ProductDAO;
import Bussiness_layer.DAO.Store_DAO;
import Bussiness_layer.DTO.*;
import Bussiness_layer.Passive_objects.*;
import Persistent_layer.DatabaseManager;

import java.util.*;

 enum Role{
    StoreKeeper(0),TransportManager(1),HrManager(2);

    private int id;

    Role(int id){
        this.id = id;
    }

    public int getRoleId(){
        return id;
    }
}
public class User_Handler {
    private DatabaseManager dbmg;
    private Category_Container allcategories; //Holds all the categories
    private Product_Container productContainer;
    private Store_DAO store;
    private static Scanner reader=new Scanner(System.in);
    private AutomaticOrdersHandler automaticOrdersHandler;
    private HashMap<Integer, List<ProductToOrder>> ordersPerSupplier;
    //Supp
    private ObjectsContainer supplierContainer;
    private  int curStoreNum=-1;
    private Thread automaticOrdersHandlerThread;

    public User_Handler(DatabaseManager dbm, DaysThread dt){
        this.dbmg = dbm;
        productContainer = new Product_Container(dbmg);
        supplierContainer = new ObjectsContainer(dbmg);
        allcategories = new Category_Container();
        store = new Store_DAO(dbmg);
        allcategories.cdbupdate(dbmg);
        allcategories.updatesons(dbmg);
        //Supplier
        //Activate Automatic orders handler
        automaticOrdersHandler= new AutomaticOrdersHandler(dbmg,this, dt);
        automaticOrdersHandlerThread = new Thread(automaticOrdersHandler);
        //automaticOrdersHandlerThread.start();
    }

    public AutomaticOrdersHandler getAutomaticOrdersHandler() {
        return automaticOrdersHandler;
    }

    public Thread getAutomaticOrdersHandlerThread() {
        return automaticOrdersHandlerThread;
    }

    //Suppliers
    public  void addNewSupplierCard(){

        System.out.print("Enter Supplier id : ");
        int supplierid = 0;
        try {
            supplierid = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }

        System.out.print("Enter Supplier site id : ");
        reader.nextLine();
        String supplierSiteId=reader.nextLine();

        System.out.print("Enter Bank Account : ");
        int bankAccount = 0;
        try {
            bankAccount = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }
        System.out.print("Enter Supplier PaymentTerms : ");
        reader.nextLine();
        String paymentTerms=reader.nextLine();
        System.out.println("Enter Supplier Routine Method :\n0 for fixedDays routine \n1 for delivery after order routine \n2 for not delivery routine");
        int deliveryRoutine = 0;
        try {
            deliveryRoutine = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }
        supplierContainer.addSupCard_Dao(new Supplier_DTO(supplierid,bankAccount,paymentTerms,deliveryRoutine, supplierSiteId));
        //checks if user selected a 0 in delivery routine = fixedDays delivery
        if(deliveryRoutine==0){
            System.out.println("How many fixed Supply days you want to add ? ");
            int numOfDays = 0;
            try {
                numOfDays = reader.nextInt();
            } catch (Exception e) {
                reader.nextLine(); //clears buffer from string mistakenly inserted
                System.out.println("Invalid input, expected int");
                return;
            }
            while (numOfDays<1 ||numOfDays>7){
                System.out.println("you must enter number between 1 and 7, please choose again : ");
                try {
                    numOfDays = reader.nextInt();
                } catch (Exception e) {
                    reader.nextLine(); //clears buffer from string mistakenly inserted
                    System.out.println("Invalid input, expected int");
                    return;
                }
            }
            for(int i=0;i<numOfDays;i++){
                insertSupplierDay(supplierid);
            }
        }
    }
    public void updateSupplierCard(){
        int input_num=0;
        String input;

        //printing all suppliers
        supplierContainer.printAllSuppliers_Dao();
        Supplier_DTO supplier_dto=getSupplierDtoByKey();

        if(supplier_dto==null) {
           return;
        }

        //and printing only it
        supplierContainer.printSup_Dao(new Supplier_DTO(supplier_dto.getSid(),null,null,null,null));

        //update the appropriate column
        System.out.println("Choose column to update (2-4): ");
        input_num=readInput(2,4);
        System.out.println("Enter new value: ");
        input=reader.nextLine();

        //creating the modified supplier object (to be passed to DAO updater)
        switch (input_num) {
            case 1: //id update
                supplier_dto.setSid(Integer.parseInt(input));
                break;
            case 2: //bank account update
                supplier_dto.setBank_acount(Integer.parseInt(input));
                break;
            case 3: //payment terms
                try{supplier_dto.setPayment_terms(input);} catch(Exception ex) {
                    System.out.println("\n***INVALID INPUT, RETURNING***\n");
                    //updating fails
                    return;
                }
                break;
            case 4: //delivery routine update
                try{supplier_dto.setDelivery_routine(Integer.parseInt(input));} catch(Exception ex) {
                    System.out.println("\n***INVALID INPUT, RETURNING***\n");
                     //update fails
                }
                break;
        }
        supplierContainer.updateSupCard_Dao(supplier_dto);
    }
    public void deleteSupplierCard(){
        supplierContainer.printAllSuppliers_Dao();
        Supplier_DTO selectedSup=getSupplierDtoByKey();
        if(selectedSup==null) //no supplier card
            return;
        supplierContainer.DeleteSupCard_Dao(selectedSup);
        deleteSupplierDays(selectedSup.getSid());
    }
    public void printSupplierCard(){
        Supplier_DTO sup_dto=getSupplierDtoByKey();
        if(sup_dto!=null)
            supplierContainer.printSup_Dao(sup_dto);
    }
    public void printAllSuppliers(){
        supplierContainer.printAllSuppliers_Dao();
    }

    private  Supplier_DTO getSupplierDtoByKey(){
        System.out.print("Enter supplier id : ");
        int supplierid=0;
        try {
            supplierid = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return null;
        }
        if(supplierContainer.getSupplerFromContainer(supplierid)==null) {
            System.out.println("\nError: no matches found!\n");
            return null; }
        //the sid is the only field required, thus other fields data irrelevant
        return supplierContainer.getSupCard_Dao(new Supplier_DTO(supplierid,-1,null,null, ""));
    }

    //Supplier's supplying Days

    //activate when adding new Supplier card
    private void insertSupplierDay(int sid){
        System.out.print("Choose supplying day : ");
        int supplyingDay = 0;
        try {
            supplyingDay = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            insertSupplierDay(sid);
            return;
        }
        while(supplyingDay<1||supplyingDay>7){
            System.out.println("Day must be between 1 and 7, please choose again : ");
            try {
                supplyingDay = reader.nextInt();
            } catch (Exception e) {
                reader.nextLine(); //clears buffer from string mistakenly inserted
                System.out.println("Invalid input, expected int");
                insertSupplierDay(sid);
                return;
            }
        }
        supplierContainer.InsertSupplyDay_Dao(new SupplierDay_DTO(sid,supplyingDay));
    }
    public List<Integer> getSupplyDaysBySid(int sid){
        return supplierContainer.getSupplyDays_BySID_Container(sid);
    }

    public List<Integer> getSidBySupplyDay(int day){
        return supplierContainer.getSID_BySupplyDay_Container(day);
    }
    //method will delete all supplier's day (this will be activate wehn supplier card deleted)
    private void deleteSupplierDays(int sid){
        supplierContainer.DeleteSupplierDays_Dao(sid);
    }

    //Agreements
    public void addProductsToAgreement(){
        Supplier curr_supplier;
        Product curr_product;
        int sid, pid,discount_thres;
        double prod_price, discount_percent;

        System.out.println("Welcome to agreements manger.\n" +
                "How many products would you like to add? ");
        int numberOfProdutsToAdd=0;
        try {
            numberOfProdutsToAdd = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }
        System.out.println("Will now display suppliers and products details");
        try{Thread.sleep(700);} catch(InterruptedException ex) {}
        System.out.print(".");
        try{Thread.sleep(700);} catch(InterruptedException ex) {}
        System.out.print(".");
        try{Thread.sleep(700);} catch(InterruptedException ex) {}
        System.out.print(".");
        try{Thread.sleep(700);} catch(InterruptedException ex) {}

        //printing current tables from db
        supplierContainer.printAllSuppliers_Dao();
        productContainer.printAllProducts_Dao();

        System.out.print("Enter supplier id: ");
        try {
            sid = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }
        curr_supplier=supplierContainer.getSupplerFromContainer(sid);
        if(curr_supplier==null) {
            System.out.println("Error: supplier " + sid + " does not exist!");
            return;
        }
        for (int i = 0; i < numberOfProdutsToAdd; i++) {
            System.out.println("Products left to add: "+(numberOfProdutsToAdd-i));
            System.out.print("Enter new product id: ");
            try {
                pid = reader.nextInt();
                ProductDAO productDAO = new ProductDAO(dbmg);
                if (!productDAO.isExists(pid)) {
                    System.out.println("Product does not exist!");
                    return;
                }
            } catch (Exception e) {
                reader.nextLine(); //clears buffer from string mistakenly inserted
                System.out.println("Invalid input, expected int");
                return;
            }
            System.out.print("Enter product price:");
            prod_price=0.0;
            try {
                prod_price = reader.nextDouble();
            } catch (Exception e) {
                System.out.println("Invalid input, expected double");
                return;
            }
            System.out.print("Enter discount threshold:");
            discount_thres=0;
            try {
                discount_thres = reader.nextInt();
            } catch (Exception e) {
                reader.nextLine(); //clears buffer from string mistakenly inserted
                System.out.println("Invalid input, expected int");
                return;
            }
            System.out.print("Enter agreed discount percent:");
            discount_percent=0.0;
            try {
                discount_percent = reader.nextDouble();
            } catch (Exception e) {
                System.out.println("Invalid input, expected double");
                return;
            }
            Agreement_DTO toBeAdded=new Agreement_DTO(pid,sid,prod_price,discount_thres,discount_percent);
            supplierContainer.addSingleProdToAgre_Dao(toBeAdded);
            System.out.println("Done adding agreements!");
        }
    }
    public void updateProductAtAgreement(){
        Agreement_DTO agreementDtoByKey=getAgreementDtoByKey();
        if(agreementDtoByKey==null) {
            System.out.println("\nNo matches Found!\n");
            return;
        }
        Agreement_DTO newDTO=agreementDtoByKey;
        System.out.println("To update price enter 1\n" +
                "To update discount threshold enter 2\n" +
                "To update discount percentage enter 3\n");
        int input=0;
        try {
            input = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }
        System.out.print("Enter new value: ");
        switch (input) {
            case 1:
                double newPrice=reader.nextDouble();
                newDTO.setProd_price(newPrice);
                break;
            case 2:
                int newThresh=0;
                try {
                    newThresh = reader.nextInt();
                } catch (Exception e) {
                    reader.nextLine(); //clears buffer from string mistakenly inserted
                    System.out.println("Invalid input, expected int");
                    return;
                }
                newDTO.setDiscount_thres(newThresh);
                break;
            case 3:
                double newPercent=reader.nextDouble();
                newDTO.setDiscount_percent(newPercent);
                break;
        }
        supplierContainer.updateProductAtAgreement_Dao(newDTO);
    }

    public void deleteProductFromAgreement(){
        int sid, pid;
        Supplier curr_supplier;
        Product curr_product;

        System.out.println("\nNOTE: this will delete certain record from agreements regarding a specific product.\n" +
                "ie. the agreements regarding 'Bisli' with supplier 'Dijkstra sapakim'\n\n");
        supplierContainer.printAllSuppliers_Dao();

        System.out.print("Enter supplier number: ");
        try {
            sid = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }
        curr_supplier=supplierContainer.getSupplerFromContainer(sid);
        if(curr_supplier==null) {
            System.out.println("Error: supplier with id " + sid + " does not exist!");
            return;
        }
        System.out.println("\nPrinting all agreements made with chosen supplier:\n");
        supplierContainer.printSupFullAgreement_Dao(curr_supplier.getSid());
        System.out.print("Enter product id: ");
        try {
            pid = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }
        Agreement_DTO toBeDeleted=new Agreement_DTO(pid,sid,null,null,null);
        supplierContainer.deleteProdFromAgreement_Dao(toBeDeleted);

    }

    public void printSuppliersByProdId(){
        System.out.print("Enter product id : ");
        int pid = 0;
        try {
            pid = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return;
        }
        supplierContainer.printAllSuplierSupplyProduct_Dao(pid);
    }
    public List<Agreement> getSupplierAgreementsBySID(int sid){
    return supplierContainer.getFullAgreementBySidFromContainer(sid);
    }

    private  Agreement_DTO getAgreementDtoByKey(){
        Agreement_DTO agreements_dto;
        System.out.print("Enter supplier id : ");
        int supplierid=0;
        try {
            supplierid = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return null;
        }
        supplierContainer.printAgreement_Dao(supplierid);
        System.out.print("Enter product id : ");
        int productId=0;
        try {
            productId = reader.nextInt();
        } catch (Exception e) {
            reader.nextLine(); //clears buffer from string mistakenly inserted
            System.out.println("Invalid input, expected int");
            return null;
        }
        //the sid  and supplierid are the only field required, thus other fields data irrelevant
        agreements_dto = supplierContainer.getAgreementRecord_Dao(new Agreement_DTO(productId,supplierid,null,null,null));
        return agreements_dto;
    }


    //Orders
    private void InsertOrder(Order_DTO dto){
        supplierContainer.addOrder_Dao(dto);
    }
    private void InsetProductAtOrder(Products_at_orders_DTO dto){
        supplierContainer.addProductAtOrder_Dao(dto);
    }

    //on routinely Automatic we order 50 products each time. we add each product to all stores
    public void addRoutinelyAutomaticOrder(Agreement agreement){
        Date nTime = new Date(Calendar.getInstance().getTimeInMillis());
        int amountToOrder=productContainer.getMaxMinimalAmount();
        if(amountToOrder==-1){
            amountToOrder=50;
        }
        double prodPrice=0;
        try {
            List<Integer> stores = getactivestores();
            for (int i=0;i<stores.size();i++){
                Order_DTO order_dto = new Order_DTO(agreement.getSupplier().getSid(),stores.get(i),nTime, 0);
                if(agreement.getDiscount_thres()<=amountToOrder) {
                    prodPrice=agreement.getProd_price()*((100-agreement.getDiscount_percent())/100);
                } else{
                    prodPrice=agreement.getProd_price();
                }
                Products_at_orders_DTO pao_dto = new Products_at_orders_DTO(agreement.getSupplier().getSid(),stores.get(i),nTime,agreement.getPid(),amountToOrder,prodPrice);
                supplierContainer.addOrder_Dao(order_dto);
                supplierContainer.addProductAtOrder_Dao(pao_dto);
            }
        } catch (Exception ex){
            System.out.println("Error while trying to add orders automatically");
        }

    }




    public List<Integer> getactivestores(){

        return store.getactivestores();
    }

    public Category_Container getAllcategories() {
        return allcategories;
    }

    public void printallcategories()
    {
        for (Category cat: allcategories.getAllcategories())
        {
            System.out.println("Category ID: "+cat.getID()+", Category name: "+cat.getName());
            System.out.println("============================");
        }
    }

    public void setStoreNumber(int storeNumber) {
        curStoreNum=storeNumber;
        productContainer.setStoreNumber(storeNumber);
    }

    public List<Product> getAllProducts() {
        return productContainer.getProducts();
    }

    private void buyProduct(int PID, double price, int amount) {
        Product p = productContainer.getProduct(PID);
        if (p != null) {
            productContainer.buyProduct(p, price, amount);
        }else {
            System.out.println("Product not exist!");
        }

    }

    // Removed feature due to integration
    public void sellProduct(int PID, int amount) {
        Product p = productContainer.getProduct(PID);
        if (p != null) {
            if (p.getShelf_amount()+p.getStock_amount() < amount) {
                System.out.println("There is not enough amount in the store");
                return;
            }

            int c = p.getLast_sub_category();
            Category cat = allcategories.findcategory(c);
            int discount = Math.max(cat.getBest_discount(), p.getDiscount_cost());

            productContainer.sellProduct(p, amount, discount);
        } else {
            System.out.println("Product not exist!");
        }
    }
    public void printcategory(int id)
    {
        for (Category son: allcategories.getAllcategories())
        {
            if(son.getID() == id)
            {
                System.out.println("Category ID: "+son.getID()+", Category name: "+son.getName());
                System.out.println("---------------------------");
                break;
            }

        }
    }
    public void printallsons(int id)
    {
        Category father = getcfromid(id);

        if(father == null)
        {
            System.out.println("No such Category ID");
            return;
        }
        System.out.println("------------father:-----------");
        System.out.println("Category ID: "+father.getID()+", Category name: "+father.getName());
        System.out.println("------------Sons:-------------");

        for (Category son: father.getSons())
        {
            System.out.println("Category ID: "+son.getID()+", Category name: "+son.getName());
        }
    }
    public Category getcfromid(int id)
    {
        Category father = null;
        for (Category son: allcategories.getAllcategories())
        {
            if(son.getID() == id){father= son;}
        }
        return father;
    }
    public void printAllSoldProducts() {
        for(SoldProduct sp :productContainer.getSoldProducts()) {
            System.out.println(sp.to_string());
        }
    }


    public void insertnewcategory(String name, int father_id)
    {
        allcategories.InsertCategory(name,father_id,dbmg);
        allcategories.cdbupdate(dbmg);
        allcategories.updatesons(dbmg);
    }

    public void delete_ctree(int cid)
    {
        allcategories.delete_ctree(cid, dbmg);
        allcategories.cdbupdate(dbmg);
        allcategories.updatesons(dbmg);
    }
    public void insert_discount(int cid, int discount_p, String date)
    {
        allcategories.insert_discount(cid,discount_p,date,dbmg);
    }
    public void print_all_products_By_categories(List<Integer> Category_lis)
    {
        String report = productContainer.stringOfProductsByCategories(Category_lis);
        System.out.println(report);
    }
    public void print_list_of_products()
    {
        String list = "";
        list = productContainer.stringofproducts();
        System.out.println(list);
    }
    public void insert_product_discount(int store_id,int pid, int precentage,String date)
    {
        productContainer.update_discount(store_id,pid,precentage,date);
    }
    public void print_list_of_damaged_products()
    {
        List<DamagedProduct> dmg_prod = productContainer.getDamagedProducts();
        for (DamagedProduct dmg: dmg_prod)
        {
            System.out.println(dmg.to_string());
        }
    }

    public void checkProductsMinimalAmount() {
        List<Product> warnProduct = productContainer.getCriticalProducts();
        if (!warnProduct.isEmpty()) {
            System.out.println("WARNING!! Products reached there minimal amount");
            System.out.println("=====================================");
            for (Product p : warnProduct) {
                System.out.println(p.to_string());
            }
            System.out.println("=====================================");
        }
        if(!warnProduct.isEmpty())
            orderMissingProducts(warnProduct);
    }
    public void checkProductsMinimalAmountAllStores() {
        List<Integer> aStores = getactivestores();
        for (int store_id:aStores) {
            productContainer.setStoreNumber(store_id);
            checkProductsMinimalAmount();
        }
    }
    public void orderMissingProducts(List<Product> missingProducts){
        ordersPerSupplier=new HashMap<>();
        double min=999999999;
        int supid=-1;
        double temp;

        for (Product product:missingProducts) {
            List<Agreement> prod_agree=supplierContainer.getAgreementsByProductId_Dao(product.getId());
            for (Agreement agree:prod_agree) {
                if(agree.getDiscount_thres()<=product.getMinimal_amount()*2){
                    temp=((100-agree.getDiscount_percent())/100)*agree.getProd_price();
                    if(temp<min) {
                        min = temp;
                        supid = agree.getSupplier().getSid();
                    }
                }
                temp=agree.getProd_price();
                if(temp<min) {
                    min = temp;
                    supid = agree.getSupplier().getSid();
                }
            }
            if(supid==-1){
                System.out.println("There is not avialable supplier that can supply "+product.getId());
            } else {
                summarizeOrders(supid,product.getStoreNumber(),product.getId(),product.getMinimal_amount()*2,min);
            }
        }
        for (Integer sup:ordersPerSupplier.keySet()) {
            List<Integer> unique_stores=new LinkedList<>();
            Date date =  new Date(Calendar.getInstance().getTimeInMillis());
            for (ProductToOrder pto:ordersPerSupplier.get(sup)) {
                if(!unique_stores.contains(pto.getStoreNum()))
                    unique_stores.add(pto.getStoreNum());
            }
            for (Integer store_id:unique_stores) {
                InsertOrder(new Order_DTO(sup,store_id,date, 0));
            }

            for (ProductToOrder pto:ordersPerSupplier.get(sup)) {
                InsetProductAtOrder(new Products_at_orders_DTO(sup,pto.getStoreNum(),date,pto.getPid(),pto.getAmount(),pto.getPricePerUnit()));
            }
        }
    }
    private void summarizeOrders(int supplier,int storeNum, int prodId, int amount, double pricePerUnit){
            if(ordersPerSupplier.containsKey(supplier)){
                ordersPerSupplier.get(supplier).add(new ProductToOrder(prodId,storeNum,amount,pricePerUnit));
            } else{
                ordersPerSupplier.put(supplier,new LinkedList<>());
                ordersPerSupplier.get(supplier).add(new ProductToOrder(prodId,storeNum,amount,pricePerUnit));
            }
    }
    public int get_shelfamount(int pid) {
        return productContainer.getsehlfamount(pid);
    }
    public void reduce_adddmg(int pid,int amount)
    {
        productContainer.reduce_adddmg(pid,amount);
    }
    public boolean id_exsist(int product_id)
    {
        return productContainer.id_exsist(product_id);
    }
    public boolean checkcategoryid(int id)
    {
        LinkedList<Integer> ids = allcategories.getallcategoriesID();
        return ids.contains(id);
    }
    public void insert_product(int product_id, int weight, String name,int category,int minimal_amount,String location,int storedID,String producer,int price)
    {
        productContainer.insert(product_id,weight, name,category,minimal_amount,location,storedID,producer,price);
    }

    public void delete_product(int pid) {
        productContainer.deleteProduct(pid);
    }


    private static int readInput(int lowerBound, int higherBound){

        System.out.print("Choice: ");
        String inputString = reader.next();
        reader.nextLine();
        try {
            int inputNumeric = Integer.parseInt(inputString);

            while (inputNumeric < lowerBound | inputNumeric > higherBound) //not valid
            {
                System.out.println("Not in range, please refer to the menu");
                inputString = reader.next();
                reader.nextLine();
                inputNumeric = Integer.parseInt(inputString);

            }
            return inputNumeric;
        }

        catch (NumberFormatException ex) {
            System.out.println("Invalid input, please refer to the menu\n");
            return readInput(lowerBound, higherBound);
        }
    }
    public void cancelNotYetCanceldOrder(Order order, int role){
      if(!isOrderInCancelTable(order)) {
          if (role == Role.StoreKeeper.getRoleId()) {
              supplierContainer.insertNewCancellationOrderApproval_Dao(new CancellationApproval_DTO(order.getSupplierId(),order.getStoreId(),order.getTime(),1,0,0));
          } else if (role == Role.TransportManager.getRoleId()) {
              supplierContainer.insertNewCancellationOrderApproval_Dao(new CancellationApproval_DTO(order.getSupplierId(),order.getStoreId(),order.getTime(),0,1,0));
          } else { //role2 - HrManager
              supplierContainer.insertNewCancellationOrderApproval_Dao(new CancellationApproval_DTO(order.getSupplierId(),order.getStoreId(),order.getTime(),0,0,1));
          }
      } else {
          System.out.println("this order is in cancellation table, you need approve it ");
      }

    }
    private boolean isOrderInCancelTable(Order order){
        List<CancellationOrder>lst=supplierContainer.getAllCancelledOrders();
        for(CancellationOrder cancellationOrder: lst) {
            if( cancellationOrder.getOrder().getSupplierId()==order.getSupplierId() &&
            cancellationOrder.getOrder().getStoreId()==order.getStoreId() &&
            cancellationOrder.getOrder().getTime().getTime()==order.getTime().getTime()) {
                    return true;
            }

        }
        return false;
    }

    //orderCancelltionApproval
    public void approveOrderCancellation(Order order, int role) {  //role 0 = storekeeper, role 1=transportManager , role2=Hrmanager

        CancellationOrder cancellationOrder = supplierContainer.getCancellationOrderApprovmentsFromContainer(order);
        if(cancellationOrder==null) {
            System.out.println("this order cancelling isn't waiting for your approval/disapproval");
            return;
        }
        int approvedByTransportManager = 0;
        int approvedByHr = 0;
        int approvedByStoreKeeper = 0;
        if (cancellationOrder.isApprovedByTransportManager()) {
            approvedByTransportManager = 1;
        }
        if (cancellationOrder.isApprovedByHrManager()) {
            approvedByHr = 1;
        }
        if (cancellationOrder.isApprovedByStoreKeeper()) {
            approvedByStoreKeeper = 1;
        }
        if (role == Role.StoreKeeper.getRoleId()) {
            if (checkCancellationApprovedByRestRoles(order, role)) {
                supplierContainer.deleteOrder_Dao(new Order_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), 0));  //delete order From order Table
                deleteAllProductsAtOrder(order);  //delete prod at orders
                supplierContainer.deleteOrderCancellarion_Dao(new CancellationApproval_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), 1, 1, 1)); //delete from cancelorder table
            } else {
                supplierContainer.updateOrderCancellation_Dao(new CancellationApproval_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), 1, approvedByTransportManager, approvedByHr));
            }
        } else if (role == Role.TransportManager.getRoleId()) {

            if (checkCancellationApprovedByRestRoles(order, role)) {
                supplierContainer.deleteOrder_Dao(new Order_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), 0));
                deleteAllProductsAtOrder(order);
                supplierContainer.deleteOrderCancellarion_Dao(new CancellationApproval_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), 1, 1, 1));
            } else {
                supplierContainer.updateOrderCancellation_Dao(new CancellationApproval_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), approvedByStoreKeeper, 1, approvedByHr));
            }
        } else { //role2 - HrManager

            if (checkCancellationApprovedByRestRoles(order, role)) {
                supplierContainer.deleteOrder_Dao(new Order_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), 0));
                deleteAllProductsAtOrder(order);
                supplierContainer.deleteOrderCancellarion_Dao(new CancellationApproval_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), 1, 1, 1));
            } else {
                supplierContainer.updateOrderCancellation_Dao(new CancellationApproval_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), approvedByStoreKeeper, approvedByTransportManager, 1));
            }
        }
   }

    public void disApproveCancellationOrder(Order order) {
        //just delete this order from the table of disapproved delete orders
        CancellationOrder cancellationOrder = supplierContainer.getCancellationOrderApprovmentsFromContainer(order);
        if(cancellationOrder==null) {
            System.out.println("this order cancelling isn't waiting for your approval/disapproval");
            return;
        }
        int approvedByTransportManager = 0;
        int approvedByHr = 0;
        int approvedByStoreKeeper = 0;
        if (cancellationOrder.isApprovedByTransportManager()) {
            approvedByTransportManager = 1;
        }
        if (cancellationOrder.isApprovedByHrManager()) {
            approvedByHr = 1;
        }
        if (cancellationOrder.isApprovedByStoreKeeper()) {
            approvedByStoreKeeper = 1;
        }
        supplierContainer.deleteOrderCancellarion_Dao(new CancellationApproval_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), approvedByStoreKeeper, approvedByTransportManager, approvedByHr));
   }

    private void deleteAllProductsAtOrder(Order order) {
        List<ProductAtOrder> lstProductsAtOrder = supplierContainer.getAllProductsAtOrderByOrder(order);
        for (ProductAtOrder pao : lstProductsAtOrder) {
            supplierContainer.deleteProductAtOrder_Dao(new Products_at_orders_DTO(order.getSupplierId(), order.getStoreId(), order.getTime(), pao.getPid(), pao.getAmount(), 0.0));
        }
    }

    private boolean checkCancellationApprovedByRestRoles(Order order, int role) {
        CancellationOrder cancellationOrder = supplierContainer.getCancellationOrderApprovmentsFromContainer(order);
        if (role == Role.StoreKeeper.getRoleId()) {
            if (cancellationOrder.isApprovedByHrManager() && cancellationOrder.isApprovedByTransportManager()) {
                return true;
            }
            return false;
        } else if (role == Role.TransportManager.getRoleId()) {
            if (cancellationOrder.isApprovedByHrManager() && cancellationOrder.isApprovedByStoreKeeper()) {
                return true;
            }
            return false;
        } else { // role=HrManger
            if (cancellationOrder.isApprovedByStoreKeeper() && cancellationOrder.isApprovedByTransportManager()) {
                return true;
            }
            return false;
        }
    }

    public void printOrdersThatAvilableForCancelltion() {
        List<Order> lstOrder = supplierContainer.getAllOrdersFromContainer();
        List<CancellationOrder> lstOrdersCancellation = supplierContainer.getAllCancelledOrders();
        System.out.println("Orders that avilable for cancellation : ");
        for (Order order : lstOrder) {
            for (CancellationOrder cancellationOrder : lstOrdersCancellation) {
                if (order.getSupplierId() == cancellationOrder.getOrder().getSupplierId() && order.getTime() == cancellationOrder.getOrder().getTime() &&
                        order.getStoreId() == cancellationOrder.getOrder().getStoreId()) {
                        System.out.println("Order : supplier id : " + order.getSupplierId() + ", store id: " + order.getStoreId() + ", date " + order.getTime().toString());
                }
            }
        }
    }
    public boolean printOrdersNotInCancellationTable(){
        List<Order> lstOrder = supplierContainer.getAllOrdersFromContainer();
        if(lstOrder.size()==0){
            System.out.println("there arn't any orders avilable for cancel right now ");
            return false;
        }
        List<CancellationOrder> lstOrdersCancellation = supplierContainer.getAllCancelledOrders();
        boolean notInCancellationTable=true;
        System.out.println("Orders that not cancelled by anyone yet : ");
        for (Order order : lstOrder) {
            for (CancellationOrder cancellationOrder : lstOrdersCancellation) {
                if (order.getSupplierId() == cancellationOrder.getOrder().getSupplierId() && order.getTime() == cancellationOrder.getOrder().getTime() &&
                        order.getStoreId() == cancellationOrder.getOrder().getStoreId()) {
                    notInCancellationTable=false;
                }
            }
            if(notInCancellationTable) {
                System.out.println("Order : supplier id : " + order.getSupplierId() + ", store id: " + order.getStoreId() + ", date " + order.getTime().toString());
            }
            notInCancellationTable=true;
        }
        return true;
    }

    public boolean printOrdersThatneedToApproved(int role) {
        List<CancellationOrder> lstOrdersCancellation = supplierContainer.getAllCancelledOrders();
        if(lstOrdersCancellation.size()==0){
            System.out.println("There aren't any orders that are waiting for your approval / Disapproval");
            return false;
        }
        System.out.println("Orders Cancellation that are waiting for approval / Disapproval by you :");
        int count=0;

        for (CancellationOrder cancellationOrder : lstOrdersCancellation) {
            if(role== Role.StoreKeeper.getRoleId()){
                if(!cancellationOrder.isApprovedByStoreKeeper()){
                    System.out.println("Order : supplier id : " + cancellationOrder.getOrder().getSupplierId() + ", store id: " + cancellationOrder.getOrder().getStoreId() + ", date " + cancellationOrder.getOrder().getTime().toString());
                    count++;
                }
            }
            if(role==Role.TransportManager.getRoleId()){
                if(!cancellationOrder.isApprovedByTransportManager()){
                    System.out.println("Order : supplier id : " + cancellationOrder.getOrder().getSupplierId() + ", store id: " + cancellationOrder.getOrder().getStoreId() + ", date " + cancellationOrder.getOrder().getTime().toString());
                    count++;
                }
            }
            if(role==Role.HrManager.getRoleId()){
                if(!cancellationOrder.isApprovedByHrManager()){
                    System.out.println("Order : supplier id : " + cancellationOrder.getOrder().getSupplierId() + ", store id: " + cancellationOrder.getOrder().getStoreId() + ", date " + cancellationOrder.getOrder().getTime().toString());
                    count++;
                }
            }
        }
        if(count==0) {
            System.out.println("There aren't any orders that are waiting for your approval / Disapproval");
            return false;
        }
      return true;
    }


    public void stopAutomaticOrdersHandler(){
        automaticOrdersHandler.stopExecution();
    }

    public void manageArrivedDeliveries() {
        System.out.println("The deliveries which need to be managed are:");
        List<DeliveryForm> deliveries =  supplierContainer.getDeliveries(curStoreNum);

        if (deliveries.isEmpty()) {
            System.out.println("Sorry no deliveries to manage.");
            return;
        }

        System.out.println("Please enter a row number of the delivery you wish to manage in range of 1-" + deliveries.size());

        int choice = readInput(1, deliveries.size());

        DeliveryForm chosen = deliveries.get(choice-1);

        List<ProductAtOrder> paos = supplierContainer.getProductsAtOrdersByDelivery(chosen);
        StringBuilder sb = new StringBuilder();
        for ( ProductAtOrder pao: paos) {
            int amount = pao.getAmount();
            Product p = null;
            try {
                 p = productContainer.getProduct(pao.getPid());
            }
            catch (Exception e)
            {
                System.out.println("Wrong Product arrived to wrong Store by mistake");
                sb.append("Wrong PID " + pao.getPid());
                continue;
            }
            if(p == null)
            {
                System.out.println("Wrong Product arrived to wrong Store by mistake");
                sb.append("Wrong PID " + pao.getPid());
                continue;
            }
            System.out.printf("Got %d of the product - %s -\n How many are valid? Please enter the amount below\n", amount, p.short_to_string());
            choice = readInput(0, pao.getAmount());
            int diff = amount - choice;
            if (diff > 0) {
                String err = "PID " + p.getId() + " had " + diff + " damaged\n";
                sb.append(err);
            }

            buyProduct(p.getId(), pao.getPrice_per_unit(), choice);
        }

        System.out.println("Done!");
        supplierContainer.resolveDelivery(chosen, sb.toString());


    }
    public Order getOrder(int supId,int storenum,Date date) {
        return supplierContainer.getOrderFromDb(supId,storenum,date);
    }
}
