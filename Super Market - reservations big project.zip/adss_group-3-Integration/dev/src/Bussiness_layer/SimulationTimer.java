package Bussiness_layer;

import Bussiness_layer.Passive_objects.DeliveryForm;
import Bussiness_layer.Passive_objects.Driver;
import Bussiness_layer.Passive_objects.Truck;

import java.util.TimerTask;

public abstract class SimulationTimer extends TimerTask {
    private Driver driver;
    private Truck truck;
    private DeliveryForm form;
    private int routeIdx;
    private int totalWeightToUpdateWith;
    private int numOfOrders;

    public SimulationTimer(Driver driver, Truck truck, DeliveryForm form, int routeIdx, int totalWeightToUpdateWith, int numOfOrders) {
        this.driver = driver;
        this.truck = truck;
        this.form = form;
        this.routeIdx = routeIdx;
        this.totalWeightToUpdateWith = totalWeightToUpdateWith;
        this.numOfOrders = numOfOrders;
    }

    public Truck getTruck() {
        return truck;
    }

    public DeliveryForm getForm() {
        return form;
    }

    public int getRouteIdx() {
        return routeIdx;
    }

    public int getTotalWeightToUpdateWith() {
        return totalWeightToUpdateWith;
    }

    public int getNumOfOrders() {
        return numOfOrders;
    }

    public Driver getDriver() {
        return driver;
    }
}
