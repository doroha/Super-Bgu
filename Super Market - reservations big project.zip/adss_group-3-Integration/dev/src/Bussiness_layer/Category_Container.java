package Bussiness_layer;

import Bussiness_layer.DAO.CategoryDAO;
import Bussiness_layer.Passive_objects.Category;
import Persistent_layer.DatabaseManager;

import java.util.LinkedList;
import java.util.List;

public class Category_Container {
    private List<Category> allcategories;
    private int highest_ID;
    private CategoryDAO cdao;
    public Category_Container()
    {
        allcategories = new LinkedList<Category>();
        cdao = new CategoryDAO();
    }
    // Get all categories From CategoryDAO
    public void cdbupdate(DatabaseManager dbmg) //Take all categories from DB
    {

        allcategories = cdao.getallcategories(dbmg);
        highest_ID = 0;
        for (Category current: allcategories)
        {
            if(current.getID() > highest_ID){highest_ID = current.getID();}
        }
    }
    // Need to find a way to update all the sons into the Container from the DB
    public void updatesons(DatabaseManager dbmg)
    {

        for (Category curr_category: allcategories)
        {
            LinkedList<Category> curr_sons = new LinkedList<>();
            //Get all direct sons
            curr_sons = cdao.getallsons(curr_category.getID(), dbmg);
            curr_category.setSons(curr_sons);
        }
    }
    public void InsertCategory(String name, int fatherid ,DatabaseManager dbmg)
    {
        if(checkValidityofname(name))
        {
            Category n_category = new Category(fatherid, highest_ID+1,name);
            highest_ID++;
            allcategories.add(n_category);
            cdao.insertcategory(n_category, dbmg);
            if(fatherid != 0)
            {
                find_and_insert_father(fatherid,n_category);
            }
        }


    }
    private void find_and_insert_father(int id, Category n_son)
    {
        for (Category father: allcategories)
        {
            if(father.getID() == id)
            {
                father.insertson(n_son);
            }
        }
    }

    public List<Category> getAllcategories() {
        return allcategories;
    }

    public int getHighest_ID() {
        return highest_ID;
    }
    private boolean checkValidityofname(String name)
    {
        for (Category category: allcategories)
        {
            if(category.getName().equals(name)){return false;}
        }
        return true;
    }

    public Category findcategory(int cid)
    {
        for (Category category: allcategories)
        {
            if(category.getID() == cid)
            {
                return category;
            }
        }
        return null;
    }
    public void delete_ctree(int cid, DatabaseManager dbmg)
    {
        Category d = findcategory(cid);
        if(d == null)
        {
            System.out.println("No such Category ID");
            return;
        }
        for (Category son: d.getSons())
        {
            delete_ctree(son.getID(),dbmg);
        }
        cdao.delete_tree(d.getID(), dbmg);
        allcategories.remove(d);
    }
    public void insert_discount(int cid,int discount,String end_date,DatabaseManager dbmg)
    {
        Category cat = findcategory(cid);
        if(cat == null)
        {
            System.out.println("No such Category id"+cid);
            return;
        }
        cat.setMy_discount(discount);
        cat.setMy_date_discount(end_date);
        cdao.updateM(cid,discount,end_date,dbmg);
        if(cat.getBest_discount() < discount)
        {
            cat.setBest_discount(discount);
            cdao.updateC(cid,discount,dbmg);
            check_discount_update(cid,discount,dbmg);
        }
    }
    private void check_discount_update(int father_id,int discount, DatabaseManager dbmg)
    {
        Category father = findcategory(father_id);
        if(father == null)
        {
            System.out.println("No such Category id"+father_id);
            return;
        }
        for (Category son: father.getSons())
        {
            if(son.getBest_discount() < discount)
            {
                check_discount_update(son.getID(),discount,dbmg);
                son.setBest_discount(discount);
                cdao.updateC(son.getID(),discount,dbmg);
            }
        }
    }
    public LinkedList<Integer> getallcategoriesID()
    {
        LinkedList<Integer> ids = new LinkedList<>();
        for (Category c:allcategories)
        {
            ids.add(c.getID());
        }
        return ids;
    }
}
