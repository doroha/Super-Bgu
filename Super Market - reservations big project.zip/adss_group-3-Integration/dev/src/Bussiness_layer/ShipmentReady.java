package Bussiness_layer;

import Bussiness_layer.Passive_objects.Order;
import Bussiness_layer.Passive_objects.Site;

import java.util.LinkedList;
import java.util.List;

public class ShipmentReady {
    private List<Order> orders = new LinkedList<>();
    private Site origin;

    public ShipmentReady() {}

    public Site getOrigin() {
        return origin;
    }

    public void setOrigin(Site origin) {
        this.origin = origin;
    }

    public void addOrder(Order order) {
        orders.add(order);
    }

    public boolean isEmpty() {
        return orders.isEmpty();
    }

    public List<Order> getOrders() {
        return orders;
    }


    public int getTotalShipmentWeight() {
        int weight = 0;
        for (Order or : orders) {
            weight += or.getTotalWeight();
        }
        return weight;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Order or : orders) {
            sb.append(or.toString());
            sb.append("\n============================\n");
        }
        sb.append(String.format("Total shipment weight: %d", getTotalShipmentWeight()));
        return sb.toString();
    }
}
