
CREATE TABLE IF NOT EXISTS trucks (
	plate_id varchar(255) PRIMARY KEY NOT NULL,
	model int NOT NULL,
	net_weight int NOT NULL,
	max_weight int NOT NULL,
	occupied int NOT NULL,
	check (max_weight>net_weight AND net_weight>=0 AND net_weight>=0 AND model>=0)
);

CREATE TABLE IF NOT EXISTS sites (
	  address varchar(255) NOT NULL PRIMARY KEY,
    phone varchar(255) NOT NULL,
    area varchar(1) NOT NULL,
    contact_name varchar(255) NOT NULL
);


CREATE TABLE IF NOT EXISTS categories (
                CID int NOT NULL,
                FID int NOT NULL,
                Name varchar (50) NOT NULL,
                end_date varchar (12),
                my_discount int NOT NULL,
                current_discount int NOT NULL,
                constraint fk_father_id foreign key (FID) references categories(CID),
                constraint o_p primary key (CID));


CREATE TABLE IF NOT EXISTS stores (
	id int PRIMARY KEY NOT NULL,
	site_id varchar(255) NOT NULL,
	constraint stores_fk_site_id foreign key (site_id) references sites(address)
);

CREATE TABLE IF NOT EXISTS suppliers (
	id int PRIMARY KEY NOT NULL,
	Bank_account int NOT NULL,
	Payment_terms int NOT NULL,
	Delivery_routine int NOT NULL,
	site_id varchar(255) NOT NULL,
	constraint suppliers_fk_site_id foreign key (site_id) references sites(address),
	check (delivery_routine between 0 and 2)
);


CREATE TABLE IF NOT EXISTS Supply_Days (
                SID int NOT NULL,
                Day int NOT NULL,
                constraint fk_sid foreign key (SID) references suppliers(id),
                constraint pk_supDay_pk primary key (SID,Day));


CREATE TABLE IF NOT EXISTS Contacts (
                Cid int PRIMARY KEY NOT NULL,
                Sid int NOT NULL,
                First_name varchar(255) NOT NULL,
                Last_name varchar(255) NOT NULL,
                Phone_num varchar (255) NOT NULL,
                Email varchar (255) NOT NULL,
                constraint fk_supplier_id FOREIGN KEY (sid) REFERENCES suppliers(id));



CREATE TABLE IF NOT EXISTS products (
      id int NOT NULL,
      name varchar(50),
      st_amount int NOT NULL,
      sh_amount int NOT NULL,
      last_category int NOT NULL,
      minimal_amount int NOT NULL,
      location varchar (50) NOT NULL,
      store_num int NOT NULL,
      producer varchar (50),
      selling_cost int NOT NULL,
      discount_cost int,
      end_discount varchar (12),
      weight int NOT NULL,
      constraint fk_P_category foreign key (last_category) references categories(CID),
      constraint fk_P_stores foreign key (store_num) references stores(id),
      constraint pk_products primary key (id));


CREATE TABLE IF NOT EXISTS Sellings (
                receipt_ID int NOT NULL,
                PID int NOT NULL,
                store_num int NOT NULL,
                buy_price int NOT NULL,
                sell_price int NOT NULL,
                amount int NOT NULL,
                constraint fk_S_products foreign key (PID) references products(id),
                constraint fk_S_stores foreign key (store_num) references stores(id),
                constraint pk_sellings primary key (receipt_ID));


/* Damaged products found by customers */
CREATE TABLE IF NOT EXISTS Damaged_products (
                PID int NOT NULL,
                store_num int NOT NULL,
                location varchar (50) NOT NULL,
                amount int NOT NULL,
                constraint fk_D_products foreign key (PID) references products(id),
                constraint fk_D_stores foreign key (store_num) references stores(id),
                constraint pk_damaged primary key (PID,store_num,location));


--datetime!=date
CREATE TABLE IF NOT EXISTS orders (
	sid int NOT NULL,
	store_num int NOT NULL,
	date TEXT NOT NULL,
	start_handle_after_days int NOT NULL,
	constraint orders_s_s_d primary key (sid, store_num, date),
	constraint orders_fk_sid foreign key (sid) references suppliers(id),
	constraint orders_fk_store_num foreign key (store_num) references stores(id)
);

CREATE TABLE IF NOT EXISTS Agreements (
                supplier_id int NOT NULL,
                product_id int NOT NULL,
                prod_price double NOT NULL,
                discount_thres int NOT NULL,
                discount_percent double NOT NULL,
                constraint fk_supplier_id foreign key (supplier_id) references suppliers(id),
                constraint fk_product_id foreign key (product_id) references products(id),
                constraint pk_agreements primary key (supplier_id, product_id));


CREATE TABLE IF NOT EXISTS products_at_orders (
	sid int NOT NULL,
	store_num int NOT NULL,
	date TEXT NOT NULL,
	product_id int NOT NULL,
	amount int NOT NULL,
	price_per_unit double NOT NULL,
	constraint products_at_orders_pk primary key (sid, store_num, date, product_id),
	constraint products_at_orders_fk_orders foreign key (sid, store_num, date) references orders(sid, store_num, date),
	constraint products_at_orders_fk_product_id foreign key (product_id) references products(id),
	check (amount>0)
);


CREATE TABLE IF NOT EXISTS destinations (
	began_at TEXT NOT NULL,
	truck_id int NOT NULL,
	site_id int NOT NULL,
	idx int NOT NULL,
	constraint destinations_pk primary key (began_at, truck_id, site_id, idx),
	constraint destinations_fk_transports foreign key (began_at, truck_id) references transports(began_at, truck_id),
	constraint destinations_fk_site_id foreign key (site_id) references stores(id)
);

CREATE TABLE IF NOT EXISTS delivery_forms (
	began_at TEXT NOT NULL,
	truck_id int NOT NULL,
	sid int NOT NULL,
	store_num int NOT NULL,
	date TEXT NOT NULL,
	truck_weight int default 0 NOT NULL,
	revised int NOT NULL,
    issues TEXT NULL,
	constraint delivery_forms_pk primary key (sid, store_num, date),
	constraint delivery_forms_fk_transports foreign key (began_at, truck_id) references transports(began_at, truck_id),
	constraint delivery_forms_fk_orders foreign key (sid, store_num, date) references orders(sid, store_num, date)
);

CREATE TABLE IF NOT EXISTS workers (
    worker_ssn int PRIMARY KEY NOT NULL,
    first_name varchar(255) NOT NULL,
    last_name varchar(255) NOT NULL,
    bankAcount int NOT NULL,
    startDate TEXT NOT NULL,
    conditions varchar(255),
    salary int NOT NULL,
    storeId int NULL,
    job varchar(255) NOT NULL,
	constraint workers_fk_stores foreign key (storeId) references stores(id)
);

CREATE TABLE IF NOT EXISTS stores_managers (
	ssn int NOT NULL,
	constraint stores_managers_pk primary key (ssn),
	constraint stores_managers_fk_workers foreign key (ssn) references workers(worker_ssn)
);

CREATE TABLE IF NOT EXISTS stores_cashiers (
	ssn int NOT NULL,
	constraint stores_cashiers_pk primary key (ssn),
	constraint stores_cashiers_fk_workers foreign key (ssn) references workers(worker_ssn)
);

CREATE TABLE IF NOT EXISTS users (
	username varchar(255) PRIMARY KEY NOT NULL,
	ssn int NOT NULL,
	password varchar(255) NOT NULL,
	permissions int NOT NULL,
	constraint users_fk_workers foreign key (ssn) references workers(worker_ssn)
);


CREATE TABLE IF NOT EXISTS transports (
	began_at TEXT NOT NULL,
	truck_id int NOT NULL,
	dssn int NOT NULL,
	org varchar(255) NOT NULL,
	constraint transports_pk primary key (began_at, truck_id),
	constraint transports_fk_truck_id foreign key(truck_id) references trucks(plate_id),
	constraint transports_fk_org foreign key(org) references sites(address),
	constraint transports_fk_dssn foreign key(dssn) references drivers(ssn)
);


CREATE TABLE IF NOT EXISTS drivers (
	ssn int NOT NULL,
	license_type int NOT NULL,
	occupied int NOT NULL,
	constraint drivers_pk primary key (ssn),
	constraint drivers_fk_workers foreign key (ssn) references workers(worker_ssn)
);

CREATE VIEW IF NOT EXISTS get_drivers (
                                     ssn,
                                     first_name,
                                     last_name,
                                     license_type,
                                     occupied
    )
AS
SELECT ssn, first_name, last_name,  license_type, occupied as 'is currently on a ride' from drivers inner join workers on workers.worker_ssn = drivers.ssn;

CREATE TABLE IF NOT EXISTS storekeeper (
  ssn int NOT NULL,
	constraint storekeeper_pk primary key (ssn),
	constraint storekeeper_fk_workers foreign key (ssn) references workers(worker_ssn)
);

CREATE TABLE IF NOT EXISTS shifts (
    ssn int NOT NULL,
    date TEXT NOT NULL,
    shift_type int NOT NULL,
    constraint shifts_pk primary key (ssn, date),
	constraint shifts_fk_workers foreign key (ssn) references workers(worker_ssn)
);

CREATE TABLE IF NOT EXISTS workers_availability (
    ssn int NOT NULL,
    day1 int NOT NULL,
    day2 int NOT NULL,
    day3 int NOT NULL,
    day4 int NOT NULL,
    day5 int NOT NULL,
    day6 int NOT NULL,
    day7 int NOT NULL,
	constraint workers_availability_pk primary key (ssn),
	constraint workers_availability_fk_workers foreign key (ssn) references workers(worker_ssn)
);
CREATE TABLE IF NOT EXISTS orders_Cancellation_Approvals (
	sid int NOT NULL,
	store_num int NOT NULL,
	date TEXT NOT NULL,
	storeKeeperApproved int NOT NULL,
	TransportMangerApproved int NOT NULL,
	HrManagerApproved int NOT NULL,
	constraint orders_s_s_d primary key (sid, store_num, date),
	constraint orders_fk_sid foreign key (sid) references suppliers(id),
	constraint orders_fk_store_num foreign key (store_num) references stores(id)

);

CREATE VIEW IF NOT EXISTS get_todays_storekeepers (
                                     keeper_ssn,
                                     storeId,
                                     shift_date,
                                     shift_type,
                                     start_time,
                                     end_time
    )
AS
SELECT workers.worker_ssn AS keeper_ssn,
       workers.storeId AS storeId,
       shifts.date AS shift_date,
       shifts.shift_type AS shift_type,
       CASE shift_type WHEN 2 THEN time('14:00:00') ELSE time('04:00:00') END AS start_time,
       CASE shift_type WHEN 1 THEN time('13:59:59') ELSE time('23:59:59') END AS end_time
FROM storekeeper
         INNER JOIN
     workers ON storekeeper.ssn = worker_ssn
         INNER JOIN
     shifts ON worker_ssn = shifts.ssn
WHERE strftime('%Y-%m-%d', shifts.date) = date('now', 'localtime');


CREATE VIEW IF NOT EXISTS stores_without_storekeeper AS
SELECT id as 'storeId'
FROM stores
WHERE id NOT IN (
    SELECT storeId
    FROM get_todays_storekeepers
    WHERE time('now', 'localtime') BETWEEN start_time AND end_time
);

CREATE VIEW IF NOT EXISTS order_management (
                              supplier_address,
                              sid,
                              store_num,
                              date,
                              store_address,
                              phone,
                              area,
                              contact_name,
                              product_id,
                              amount,
                              weight,
                              order_weight,
                              available_keeper
    )
AS
SELECT suppliers.site_id AS supplier_address,
       orders.sid AS sid,
       orders.store_num AS store_num,
       orders.date AS date,
       stores.site_id AS store_address,
       sites.phone AS phone,
       sites.area AS area,
       sites.contact_name AS contact_name,
       products_at_orders.product_id,
       products_at_orders.amount,
       products.weight,
       (amount * weight) AS order_weight,
       CASE WHEN stores_without_storekeeper.storeId IS NULL THEN 1 ELSE 0 END AS available_keeper
FROM suppliers
         INNER JOIN
     orders ON suppliers.id = orders.sid
         INNER JOIN
     stores ON orders.store_num = stores.id
         INNER JOIN
     sites ON stores.site_id = sites.address
         INNER JOIN
     products_at_orders ON products_at_orders.sid = orders.sid AND
                           products_at_orders.date = orders.date AND
                           products_at_orders.store_num = orders.store_num
         INNER JOIN
     products ON products.id = products_at_orders.product_id
         LEFT JOIN
     stores_without_storekeeper ON orders.store_num = stores_without_storekeeper.storeId
     WHERE orders.start_handle_after_days != -1 AND orders.start_handle_after_days != -2
ORDER BY orders.date ASC;
-- -2 will be used to mark orders as being handled while -1 will make them as failed to be handled after 7 days.




