-- Static inserts assumed by the software exists in the database.

-- 12 Sites, 9 stores and 3 suppliers
insert into sites (address, phone, area, contact_name) values
('North 1', '135648899', 'N', 'Yaniv'),
('North 2', '165198499', 'N', 'Noa'),
('North 3', '165498499', 'N', 'Nir'),

('Merkaz 1', '165198465', 'M', 'Aviv'),
('Merkaz 2', '646464984', 'M', 'Hason'),
('Merkaz 3', '646464985', 'M', 'Rafy'),

('Darom 1', '135648888', 'D', 'David'),
('Darom 2', '135648887', 'D', 'Aviel'),
('Darom 3', '135648885', 'D', 'Dor'),

-- Suppliers
('Supplier site 1', '135648890', 'N','SUP1'),
('Supplier site 2', '135648891', 'M','SUP2'),
('Supplier site 3', '135648892', 'D','SUP3');

-- 4 Stores
insert into stores (id, site_id) values
(1, 'North 1'),
(2, 'North 2'),
(3, 'North 3'),

(4, 'Merkaz 1'),
(5, 'Merkaz 2'),
(6, 'Merkaz 3'),

(7, 'Darom 1'),
(8, 'Darom 2'),
(9, 'Darom 3');


insert into workers (worker_ssn, first_name, last_name, bankAcount, startDate,
					conditions, salary, storeId, job)
					values
-- 1 Workers manager
		('4876443', 'dor', 'qweqwe', '1513568', '2019-03-25 16:37:00', '', 50000, null,'workers manager'),
        -- 1 Workers manager
        ('4876449', 'aviel', 'qweqwe', '1513568', '2019-03-25 16:37:00', '', 50000, null,'transportations manager'),
-- 3 suppliers
        ('4876453', 'sup1', 'fsup1', '1513568', '2019-03-25 16:37:00', '', 50000, null,'sup3'),
          ('4876463', 'sup2', 'fsup2', '1513568', '2019-03-25 16:37:00', '', 50000, null,'sup4'),
          ('4876473', 'sup3', 'fsup3', '1513568', '2019-03-25 16:37:00', '', 50000, null,'sup5'),

-- 9 stores, so 27 workers, for each store, 1 manager, 1 regular workers, 1 storekeeper

-- Manager for storeid 1
					('1234564', 'aviel', 'ozan', '131313', '2019-03-25 16:37:00', '', 5000, 1,'store manager'),
-- Regular worker for storeid 1
					('423456', 'dor', 'abc', '313156', '2019-03-25 16:38:00', '', 3000, 1,'store keeper'),
-- Store keeper worker for storeid 1
					('2312456', 'miro', 'barbiro', '232313', '2019-03-25 16:39:00', '', 3500, 1,'food section'),
-- Store cashier for storeid 1
					('231244', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 1,'store cashier'),

-- Manager for storeid 2
					('5373582', 'mordi', 'fedida', '513513', '2019-03-25 16:40:00', '', 5000, 2,'store manager'),
-- Regular worker for storeid 2
					('6849', 'dor', 'abcd', '313156', '2019-03-25 16:41:00', '', 3000, 2,'store keeper'),
-- Store keeper worker for storeid 2
					('15135', 'uzi', 'barbiro', '232313', '2019-03-25 16:42:00', '', 3500, 2,'food section'),
-- Store cashier for storeid 2
					('124123', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 2,'store cashier'),


-- Manager for storeid 3
					('4635233', 'david', 'fedida', '46834234', '2019-03-25 16:43:00', '', 5000, 3,'store manager'),
-- Regular worker for storeid 3
					('215613', 'eli', 'rom', '13673538', '2019-03-25 16:44:00', '', 3000, 3,'store keeper'),
-- Store keeper worker for storeid 3
					('41313332', 'luna', 'barbiro', '708754', '2019-03-25 16:45:00', '', 3500, 3,'food section'),
-- Store cashier for storeid 3
					('1241234', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 3,'store cashier'),

-- Manager for storeid 4
					('1341309', 'eti', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 4,'store manager'),
-- Regular worker for storeid 4
					('96966690', 'eli', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 4,'store keeper'),
-- Store keeper worker for storeid 4
					('1357135', 'romi', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 4,'food section'),
-- Store cashier for storeid 3
					('1241232', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 4,'store cashier'),

-- Manager for storeid 5
					('13413095', 'eti5', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 5,'store manager'),
-- Regular worker for storeid 5
					('969666905', 'eli5', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 5,'store keeper'),
-- Store keeper worker for storeid 5
					('13571355', 'romi5', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 5,'food section'),
-- Store cashier for storeid 5
					('1241230', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 5,'store cashier'),

-- Manager for storeid 6
					('13413096', 'eti6', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 6,'store manager'),
-- Regular worker for storeid 6
					('969666906', 'eli6', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 6,'store keeper'),
-- Store keeper worker for storeid 6
					('13571356', 'romi6', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 6,'food section'),
-- Store cashier for storeid 6
					('1241239', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 6,'store cashier'),

-- Manager for storeid 7
					('13413097', 'eti7', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 7,'store manager'),
-- Regular worker for storeid 7
					('969666907', 'eli7', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 7,'store keeper'),
-- Store keeper worker for storeid 7
					('13571357', 'romi7', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 7,'food section'),
-- Store cashier for storeid 7
					('1241236', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 7,'store cashier'),

-- Manager for storeid 8
					('13413098', 'eti8', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 8,'store manager'),
-- Regular worker for storeid 8
					('969666908', 'eli8', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 8,'store keeper'),
-- Store keeper worker for storeid 8
					('13571358', 'romi8', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 8,'food section'),
-- Store cashier for storeid 8
					('12412355', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 8,'store cashier'),

-- Manager for storeid 9
					('13413099', 'eti9', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 9,'store manager'),
-- Regular worker for storeid 9
					('969666909', 'eli9', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 9,'store keeper'),
-- Store keeper worker for storeid 9
					('13571359', 'romi9', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 9,'food section'),
-- Store cashier for storeid 9
					('12412354', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 9,'store cashier'),



-- Now let's add 4 more workers that will be drivers. Note they are not linked into a specific store.
		('1001348', 'd1', 'd2', '88684', '2019-03-25 16:48:00', '', 4250, null,'driver'),

		('4757355', 'd3', 'd4', '42527', '2019-03-25 16:48:00', '', 4250, null,'driver'),

		('648385', 'd5', 'd6', '957562', '2019-03-25 16:48:00', '', 4250, null,'driver'),

		('423423', 'd7', 'd8', '2452575', '2019-03-25 16:48:00', '', 4250, null,'driver');


-- Stores managers
insert into stores_managers(ssn) values
('1234564'),
('5373582'),
('4635233'),
('1341309'),
('13413095'),
('13413096'),
('13413097'),
('13413098'),
('13413099');

-- Stores keepers
insert into storekeeper(ssn) values
('423456'),
('6849'),
('215613'),
('96966690'),
('969666905'),
('969666906'),
('969666907'),
('969666908'),
('969666909');



-- Stores cashiers
insert into stores_cashiers(ssn) values
('231244'),
('124123'),
('1241234'),
('1241232'),
('1241230'),
('1241239'),
('1241236'),
('12412355'),
('12412354');


-- 4 Drivers
insert into drivers (ssn, license_type, occupied) values
('1001348', 0, 0),
('4757355', 1, 0),
('648385', 0, 0),
('423423', 1, 0);

-- 1 Workers manager
-- 1 Transportation manager
insert into users (username, ssn, password, permissions) values
('dor', '4876443', '123456', 1),
('aviel', '4876449', '123456', 2),
('sup3', '4876453', '123456', 3),
('sup4', '4876463', '123456', 4),
('sup5', '4876473', '123456', 5),


-- 9 stores managers
('aviel1', '1234564', '123456', 0),
('aviel4', '5373582', '123456', 0),
('aviel7', '4635233', '123456', 0),
('aviel10', '1341309', '123456', 0),
('aviel13', '13413095', '123456', 0),
('aviel16', '13413096', '123456', 0),
('aviel19', '13413097', '123456', 0),
('aviel23', '13413098', '123456', 0),
('aviel26', '13413099', '123456', 0),


-- 9 Store keepers
('aviel2', '423456', '123456', 0),
('aviel17', '969666906', '123456', 0),
('aviel5', '6849', '123456', 0),
('aviel8', '215613', '123456', 0),
('aviel11', '96966690', '123456', 0),
('aviel14', '969666905', '123456', 0),
('aviel21', '969666907', '123456', 0),
('aviel24', '969666908', '123456', 0),
('aviel27', '969666909', '123456', 0),



-- 9 Regular store workers
('aviel3', '2312456', '123456', 0),
('aviel6', '15135', '123456', 0),
('aviel9', '41313332', '123456', 0),
('aviel12', '1357135', '123456', 0),
('aviel15', '13571355', '123456', 0),
('aviel18', '13571356', '123456', 0),
('aviel22', '13571357', '123456', 0),
('aviel25', '13571358', '123456', 0),
('aviel20', '13571359', '123456', 0),


-- 9 cashiers
('aviel32', '231244', '123456', 0),
('aviel33', '124123', '123456', 0),
('aviel34', '1241234', '123456', 0),
('aviel35', '1241232', '123456', 0),
('aviel36', '1241230', '123456', 0),
('aviel37', '1241239', '123456', 0),
('aviel38', '1241236', '123456', 0),
('aviel39', '12412355', '123456', 0),
('aviel40', '12412354', '123456', 0),



-- 4 drivers users
('aviel28', '1001348', '123456', 0),
('aviel29', '4757355', '123456', 0),
('aviel30', '648385', '123456', 0),
('aviel31', '423423', '123456', 0);


-- 3 Suppliers
insert into suppliers (id,Bank_account,Payment_terms,Delivery_routine, site_id) values
(3, 123, 'Term 1', 0, 'Supplier site 1'),
(4, 132, 'Term 2', 1,'Supplier site 2'),
(5, 312, 'Term 3', 2,'Supplier site 3');

-- 4 Trucks, remember weights are in Kilograms
insert into trucks (plate_id, model, net_weight, max_weight, occupied) values
('7986548', 2010, 5000, 12000, 0),
('4256564', 2011, 6000, 15000, 0),
('5256563', 2012, 6000, 12000, 0),
('6256561', 2013, 6000, 15000, 0);

-- 4 Categories
INSERT INTO Categories (CID,FID,Name,end_date,my_discount,current_discount) values
(0,0,'Main_Root',NULL,0,0),
(1,0,'Diary',NULL,0,0),
(2,1,'Milk',NULL,0,0),
(3,1,'Cheese',NULL,0,0);

-- 5 Products
INSERT INTO products (
id,name,
st_amount,
sh_amount,
last_category,
minimal_amount,
location,
store_num,
producer,
selling_cost,
weight,
discount_cost,
end_discount)
values
(1,'Milk 3%',123,300,2,100,'42A',1,'Tnuva',10, 5, NULL, NULL),
(2,'Milk 3%',20,90,2,100,'42B',1,'Yotvata',30, 3, NULL, NULL),
(3,'Emek 28%',10,38,3,70,'32F',1,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(4,'Emek 9%',45,40,3,20,'31F',1,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(5,'Milk 3%',121,94,2,100,'64B',1,'Yotvata', 7, 30, NULL, NULL),

(11,'Milk 3%',123,300,2,100,'42A',2,'Tnuva',10, 5, NULL, NULL),
(12,'Milk 3%',20,90,2,100,'42B',2,'Yotvata',30, 3, NULL, NULL),
(13,'Emek 28%',10,38,3,70,'32F',2,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(14,'Emek 9%',45,40,3,20,'31F',2,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(15,'Milk 3%',121,94,2,100,'64B',2,'Yotvata', 7, 30, NULL, NULL),

(21,'Milk 3%',123,300,2,100,'42A',3,'Tnuva',10, 5, NULL, NULL),
(22,'Milk 3%',20,90,2,100,'42B',3,'Yotvata',30, 3, NULL, NULL),
(23,'Emek 28%',10,38,3,70,'32F',3,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(24,'Emek 9%',45,40,3,20,'31F',3,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(25,'Milk 3%',121,94,2,100,'64B',3,'Yotvata', 7, 30, NULL, NULL),

(31,'Milk 3%',123,300,2,100,'42A',4,'Tnuva',10, 5, NULL, NULL),
(32,'Milk 3%',20,90,2,100,'42B',4,'Yotvata',30, 3, NULL, NULL),
(33,'Emek 28%',10,38,3,70,'32F',4,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(34,'Emek 9%',45,40,3,20,'31F',4,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(35,'Milk 3%',121,94,2,100,'64B',4,'Yotvata', 7, 30, NULL, NULL),

(41,'Milk 3%',123,300,2,100,'42A',5,'Tnuva',10, 5, NULL, NULL),
(42,'Milk 3%',20,90,2,100,'42B',5,'Yotvata',30, 3, NULL, NULL),
(43,'Emek 28%',10,38,3,70,'32F',5,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(44,'Emek 9%',45,40,3,20,'31F',5,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(45,'Milk 3%',121,94,2,100,'64B',5,'Yotvata', 7, 30, NULL, NULL),

(51,'Milk 3%',123,300,2,100,'42A',6,'Tnuva',10, 5, NULL, NULL),
(52,'Milk 3%',20,90,2,100,'42B',6,'Yotvata',30, 3, NULL, NULL),
(53,'Emek 28%',10,38,3,70,'32F',6,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(54,'Emek 9%',45,40,3,20,'31F',6,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(55,'Milk 3%',121,94,2,100,'64B',6,'Yotvata', 7, 30, NULL, NULL),

(61,'Milk 3%',123,300,2,100,'42A',7,'Tnuva',10, 5, NULL, NULL),
(62,'Milk 3%',20,90,2,100,'42B',7,'Yotvata',30, 3, NULL, NULL),
(63,'Emek 28%',10,38,3,70,'32F',7,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(64,'Emek 9%',45,40,3,20,'31F',7,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(65,'Milk 3%',121,94,2,100,'64B',7,'Yotvata', 7, 30, NULL, NULL),

(71,'Milk 3%',123,300,2,100,'42A',8,'Tnuva',10, 5, NULL, NULL),
(72,'Milk 3%',20,90,2,100,'42B',8,'Yotvata',30, 3, NULL, NULL),
(73,'Emek 28%',10,38,3,70,'32F',8,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(74,'Emek 9%',45,40,3,20,'31F',8,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(75,'Milk 3%',121,94,2,100,'64B',8,'Yotvata', 7, 30, NULL, NULL),

(81,'Milk 3%',123,300,2,100,'42A',9,'Tnuva',10, 5, NULL, NULL),
(82,'Milk 3%',20,90,2,100,'42B',9,'Yotvata',30, 3, NULL, NULL),
(83,'Emek 28%',10,38,3,70,'32F',9,'Yotvata',25, 4, 10, '2019-08-02 00:00:00'),
(84,'Emek 9%',45,40,3,20,'31F',9,'Tnuva',25, 6, 30,'2019-08-02 00:00:00'),
(85,'Milk 3%',121,94,2,100,'64B',9,'Yotvata', 7, 30, NULL, NULL);



-- 3 Selling
INSERT INTO Sellings
(receipt_ID,PID,store_num,buy_price,sell_price,amount) values
(0,3,1,10,23,5),
(1,3,2,10,23,3),
(2,2,3,15,30,7),
(3,3,4,10,23,5),
(4,3,5,10,23,3),
(5,2,6,15,30,7),
(6,3,7,10,23,5),
(7,3,8,10,23,3),
(8,2,9,15,30,7);

-- 1 Damaged product
INSERT INTO Damaged_products (PID,store_num,location,amount) values
(5,1,'64B',14),
(5,2,'64B',41),
(5,3,'64B',12),
(5,4,'64B',18),
(5,5,'64B',22),
(5,6,'64B',28),
(5,7,'64B',35),
(5,8,'64B',50),
(5,9,'64B',8);


-- 1 Agreement
INSERT INTO Agreements
                (supplier_id,product_id,prod_price,discount_thres,discount_percent) values
                (3,14,100.0,100,50.0),
                (4,3,100.0,200,50.0),
                (5,1,70.0,30,20.0),
                (3,1,40.0,90,40.0),
                (4,2,170.0,10,80.0),
                (5,2,20.0,120,30.0),
                (3,12,20.0,120,30.0),
                (3,11,20.0,120,30.0),
                (3,13,20.0,120,30.0),
                (4,5,90.0,400,20.0);


INSERT INTO Supply_Days (SID,Day) values
  (3,2),
  (4,6);

