package Persistent_layer;

import Bussiness_layer.Config;
import Bussiness_layer.DAO.ProductDAO;
import Bussiness_layer.MovingShipment;
import Bussiness_layer.Passive_objects.*;
import Bussiness_layer.Passive_objects.Driver;
import Bussiness_layer.ShipmentReady;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;


public class DatabaseManager {

    private Connection conn;

    public DatabaseManager(Connection connection) {
        conn = connection;
        initStatements();
    }

    public Connection getConn() {
        return conn;
    }

    private void initStatements() {

        List<String> initStatements = new LinkedList<>();
        // Make sure that in the program was shut down during a shipment, meaning the software
        // were in an intermediate state, a driver/truck won't remain forever occupied.
        initStatements.add("update trucks set occupied = 0;");
        initStatements.add("update drivers set occupied = 0;");
        try {
            Statement stmt = conn.createStatement();
            for (String query : initStatements) {
                stmt.executeUpdate(query);
            }
            stmt.close(); // Will execute all.
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private int getBestFreeTruckCapacity() {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(Queries.best_free_truck_capacity);
            if (rs.next()) {
                return rs.getInt("max_weight");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private Site getSupplierSiteById(int id) {
        Site s = null;
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.get_supplier_site_by_id);
            stmt.setInt(1, id);
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                s = new Site(res.getString("address"), res.getString("phone"), res.getString("area"), res.getString("contact_name"));
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return s;
    }

    public ShipmentReady getNextShipment() {
        try {
            ProductDAO pdao = new ProductDAO(this);
            SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);
            Statement stmt = conn.createStatement();
            // Get currently(in terms of trucks) max weight a truck can carry.
            int max_weight = getBestFreeTruckCapacity();
            ResultSet res = stmt.executeQuery(Queries.get_legal_orders);
            List<Pair<Product, Integer>> current_order_products = new LinkedList<>();
            ShipmentReady shipmentReady = new ShipmentReady();
            boolean hasNext = res.next();
            int routeIdx = 1;
            int current_shipment_weight = 0;
            while (hasNext) {
                int iter_weight = res.getInt("weight"), iter_product_amount = res.getInt("amount"), iter_product_id = res.getInt("product_id"), iter_store_id = res.getInt("store_num"), iter_supplier_id = res.getInt("sid");
                String iter_time = res.getString("date"), iter_contact_name = res.getString("contact_name"), iter_phone = res.getString("phone"), iter_area = res.getString("area"), iter_address = res.getString("store_address");
                boolean isFirst = res.isFirst();
                if (isFirst) {
                    Site supplierSite = getSupplierSiteById(iter_supplier_id);
                    if (supplierSite == null) {
                        System.out.println(String.format("Failed to find a supplier site with id of: %d", iter_supplier_id));
                        break;
                    }
                    shipmentReady.setOrigin(supplierSite);
                }
                java.util.Date d = null;
                try {
                    d = formatter.parse(iter_time);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                hasNext = res.next();
                if (!hasNext) {
                    current_order_products.add(new Pair<>(pdao.getProductById(iter_product_id), iter_product_amount));
                    Order order = new Order(iter_supplier_id, iter_store_id, d, routeIdx, new Site(iter_address, iter_phone, iter_area, iter_contact_name), current_order_products);
                    routeIdx++;
                    current_order_products = new LinkedList<>();
                    // If the weight collected + current order weight overweight the maximum
                    // weight my biggest truck can handle, skip this order.
                    int orderTotalWeight = order.getTotalWeight();
                    if ((current_shipment_weight + orderTotalWeight) > max_weight) {
                        System.out.println(String.format("\n\n**Skipping shipment to <%s> due to overweight or lack of store keeper at destination, will try to collect different one.**\n\n", order.getDestination().getAddress()));
                    } else {
                        current_shipment_weight += orderTotalWeight;
                        shipmentReady.addOrder(order);
                    }
                } else {
                    current_order_products.add(new Pair<>(pdao.getProductById(iter_product_id), iter_product_amount));
                    if ((!iter_time.equals(res.getString("date"))
                            || iter_supplier_id != res.getInt("sid")
                            || iter_store_id != res.getInt("store_num"))) {
                        Order order = new Order(iter_supplier_id, iter_store_id, d, routeIdx, new Site(iter_address, iter_phone, iter_area, iter_contact_name), current_order_products);
                        routeIdx++;
                        current_order_products = new LinkedList<>();
                        // If the weight collected + current order weight overweight the maximum
                        // weight my biggest truck can handle, skip this order.
                        int orderTotalWeight = order.getTotalWeight();

                        if ((current_shipment_weight + orderTotalWeight) > max_weight) {
                            System.out.println(String.format("\n\n**Skipping shipment to <%s> due to overweight or lack of store keeper at destination, will try to collect different one.**\n\n", order.getDestination().getAddress()));
                        } else {
                            current_shipment_weight += orderTotalWeight;
                            shipmentReady.addOrder(order);
                        }
                    }
                }
            }
            stmt.close();
            return shipmentReady;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean clearOrders(List<Order> orders) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);
            for (Order or : orders) {
                PreparedStatement stmt2 = conn.prepareStatement(Queries.orders_update_as_handled);
                stmt2.setInt(1, or.getSupplierId());
                stmt2.setInt(2, or.getStoreId());
                stmt2.setString(3, formatter.format(or.getTime()));
                if (stmt2.executeUpdate() == 0) {
                    System.out.println("Failed to remove an order.");
                    stmt2.close();
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return true;
    }

    public MovingShipment startShipment(ShipmentReady shipmentReady, Truck truck, Driver driver) {
        MovingShipment result = null;
        boolean exceptionThrown = false;
        Transport trans = new Transport(new Date(System.currentTimeMillis()), truck.getPlateId(), driver.getSsn(), shipmentReady.getOrigin());
        SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);
        List<DeliveryForm> deliveryForms = new LinkedList<>();
        try {
            final boolean oldAutoCommit = conn.getAutoCommit();
            conn.setAutoCommit(false);
            try {
                PreparedStatement stmt0 = conn.prepareStatement(Queries.transport_insertion);
                PreparedStatement stmt1 = conn.prepareStatement(Queries.delivery_forms_insertion);
                PreparedStatement stmt2 = conn.prepareStatement(Queries.destinations_insertion);

                // When the transport began.
                String begDateTime = formatter.format(trans.getBeganAt());

                // First add the Transport row.
                stmt0.setString(1, begDateTime);
                stmt0.setString(2, trans.getTruckId());
                stmt0.setInt(3, driver.getSsn());
                stmt0.setString(4, shipmentReady.getOrigin().getAddress());
                stmt0.executeUpdate();

                for (Order order : shipmentReady.getOrders()) {
                    // When specific order was requested.
                    String reqDateTime = formatter.format(order.getTime());

                    // Now add the delivery forms
                    deliveryForms.add(new DeliveryForm(trans.getBeganAt(), trans.getTruckId(), order.getSupplierId(), order.getStoreId(), order.getTime()));
                    stmt1.setString(1, begDateTime);
                    stmt1.setString(2, trans.getTruckId());
                    stmt1.setInt(3, order.getSupplierId());
                    stmt1.setInt(4, order.getStoreId());
                    stmt1.setString(5, reqDateTime);
                    stmt1.executeUpdate();

                    // Finally the destinations
                    stmt2.setString(1, begDateTime);
                    stmt2.setString(2, trans.getTruckId());
                    stmt2.setString(3, order.getDestination().getAddress());
                    stmt2.setInt(4, order.getRouteIdx());
                    stmt2.executeUpdate();
                }
            } catch (Exception e) {
                System.out.println(String.format("Error: %s", e.getMessage()));
                conn.rollback();
                exceptionThrown = true;
            } finally {
                conn.commit();
                conn.setAutoCommit(oldAutoCommit);
                if (!exceptionThrown) {
                    result = new MovingShipment(driver, truck, shipmentReady.getOrders(), deliveryForms);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }



    /*
     * An helper method that can be used by tests and the application itself to determine
     * if a record exists.
     * */
    public boolean isRecord(String table, String column, String strId, int intId, String keyType) {
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM " + table + " WHERE " + column + " = ?;");
            if (keyType.equals("string")) {
                stmt.setString(1, strId);
            } else {
                stmt.setInt(1, intId);
            }
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateFormWithTruckWeight(Truck truck, DeliveryForm form, int productsWeight) {
        SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);
        try {
            PreparedStatement stmt = conn.prepareStatement(Queries.update_truck_weight);
            stmt.setInt(1, truck.getNetWeight() + productsWeight);
            stmt.setInt(2, form.getSupplierId());
            stmt.setInt(3, form.getStoreId());
            stmt.setString(4, formatter.format(form.getRequestDate()));
            if (stmt.executeUpdate() != 1) {
                return false;
            }
            stmt.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public User login(String username, String password) {
        User user = null;
        try {
            String query = Queries.login;
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.executeQuery();
            user = getUserInfo(stmt);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return user;
    }

    private User getUserInfo(PreparedStatement stmt) {
        User user = null;
        try {
            ResultSet res = stmt.executeQuery();
            if (res.next()) {
                user = new User(
                        res.getString("username"),
                        res.getInt("ssn"),
                        res.getString("password"),
                        res.getInt("permissions"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    public int getShiftType() {
        int shift_type;
        LocalTime localTime = LocalTime.now();
        LocalTime day_shift = LocalTime.of(14, 0, 0);
        shift_type = localTime.compareTo(day_shift);
        if (shift_type < 0) //meaning current time is before 14:00 (= day shift)
            return 1;
        else {
            return 2; // meaning current time is after 14:00 (= night shift)
        }
    }

    private List<Integer> getIllegalStores() {
        List<Integer> illegalStores = new LinkedList<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet res = stmt.executeQuery(Queries.get_stores_without_storekeeper);
            while (res.next()) {
                illegalStores.add(res.getInt("storeId"));
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return illegalStores;
    }

}
