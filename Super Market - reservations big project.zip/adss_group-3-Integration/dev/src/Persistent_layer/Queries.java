package Persistent_layer;

public class Queries {
    public static String drivers_view = "select * from get_drivers";
    public static String get_truck = "select * from trucks where occupied = 0 and (max_weight-net_weight) >= ? order by (max_weight-net_weight) limit 1";
    public static String truck_occupation = "update trucks set occupied = 1 where plate_id = ?;";
    public static String truck_release = "update trucks set occupied = 0 where plate_id = ?;";
    public static String orders_delete = "DELETE FROM orders WHERE sid=? and store_num=? and date=?;";
    public static String products_at_orders_delete = "DELETE FROM products_at_orders WHERE sid=? and store_num=? and date=?;";
    public static String get_supplier_site_by_id = "select * from sites inner join suppliers on sites.address = suppliers.site_id where suppliers.id = ?;";
    public static String get_driver = "select * from drivers where occupied = 0 and license_type >= ? order by license_type limit 1;";
    public static String driver_occupation = "update drivers set occupied = 1 where ssn = ?;";
    public static String driver_release = "update drivers set occupied = 0 where ssn = ?;";
    public static String update_truck_weight = "update delivery_forms set truck_weight = ? where sid = ? and store_num = ? and date = ?;";
    public static String transport_insertion = "INSERT INTO transports (began_at, truck_id, dssn, org) VALUES (?,?,?,?);";
    public static String delivery_forms_insertion = "INSERT INTO delivery_forms (began_at, truck_id, sid, store_num, date, revised) VALUES (?,?,?,?,?,0);";
    public static String siteBySupplierId = "SELECT * FROM sites INNER JOIN suppliers ON sites.address = suppliers.site_id WHERE id = ?;";
    public static String destinations_insertion = "INSERT INTO destinations (began_at, truck_id, site_id, idx) VALUES (?,?,?,?);";
    public static String login = "SELECT * FROM users WHERE username = ? AND password = ?";
    public static String driver_name = "select first_name, last_name from workers where worker_ssn = ?";

    /**
     * @implNote first arg is shift_type
     * second arg is license_type
     */
    public static String select_driver = "select * from drivers where drivers.ssn in\n" +
            "            (select ssn from\n" +
            "            (select drivers.ssn, drivers.occupied ,drivers.license_type, strftime('%Y-%m-%d', shifts.date) as date2, shift_type from \n" +
            "                        shifts inner join drivers on shifts.ssn = drivers.ssn\n" +
            "                         where date2 = date('now','localtime'))\n" +
            "    where occupied = 0 AND (shift_type = ? OR shift_type = 3)) AND license_type >= ? order by license_type limit 1; ";
    public static String get_stores_without_storekeeper = "select * from stores_without_storekeeper";
    public static String get_legal_orders = "select * from order_management where available_keeper = 1 and (sid,area) in (\t\n" +
            "select sid,area from order_management where available_keeper = 1 order by date limit 1) order by date;";
    public static String best_free_truck_capacity = "select max(max_weight - net_weight) as max_weight from trucks where occupied = 0;";


    public static String site_insert = "INSERT INTO sites (address, phone, area, contact_name) VALUES (?,?,?,?);";
    public static String store_by_id = "SELECT * FROM stores WHERE id=?";
    public static String supplier_by_id = "SELECT * FROM suppliers WHERE id=?";
    public static String get_all_stores = "SELECT * FROM stores";
    public static String delete_store_by_id = "DELETE FROM stores WHERE id = ?;";
    public static String store_insert = "INSERT INTO stores (id,site_id) VALUES (?,?)";
    public static String delete_truck_by_id = "DELETE FROM trucks WHERE plate_id = ?;";
    public static String truck_insert = "INSERT INTO trucks (plate_id, model, net_weight, max_weight, occupied) VALUES (?,?,?,?,0)";
    public static String delete_site_by_address = "DELETE FROM sites WHERE address = ?;";
    public static String getShiftBySsn = "SELECT ssn, strftime('%Y-%m-%d', shifts.date) as date, shift_type FROM shifts WHERE ssn = ?";
    public static String get_all_shifts = "SELECT ssn, strftime('%Y-%m-%d', shifts.date) as date, shift_type FROM shifts";
    public static String shift_insert = "INSERT INTO shifts (ssn,date,shift_type) VALUES (?,?,?)";
    public static String insert_availability = "INSERT INTO workers_availability (ssn,day1, day2, day3, day4 , day5 , day6, day7) VALUES (?,?,?,?,?,?,?,?)";
    public static String delete_availability_by_ssn = "DELETE FROM workers_availability WHERE ssn = ?;";
    public static String getAvailabilityBySsn = "SELECT * FROM workers_availability WHERE ssn=?";
    public static String workers_insert = "insert into workers (worker_ssn, first_name, last_name, bankAcount, startDate,conditions, salary, storeId, job) VALUES (?,?,?,?,?,?,?,?,?)";
    public static String getWorkerBySsn = "SELECT * FROM workers WHERE worker_ssn=?";
    public static String get_all_workers = "SELECT * FROM workers";
    public static String delete_worker_by_ssn = "DELETE FROM workers WHERE worker_ssn = ?;";
    public static String insert_driver = "INSERT INTO drivers (ssn, license_type, occupied) VALUES (?,?,0)";
    public static String update_user_password = "UPDATE users SET password = ?";
    public static String delete_driver_by_ssn = "DELETE FROM drivers WHERE ssn = ?;";
    public static String insert_user = "INSERT INTO users (username, ssn, password, permissions) VALUES (?,?,?,?)";
    public static String delete_user_by_username = "DELETE FROM users WHERE username=?";
    public static String delete_shift_by_date_ssn = "DELETE FROM shifts WHERE date LIKE ? AND ssn =?";
    public static String get_shift_by_date_type = "SELECT ssn, strftime('%Y-%m-%d', shifts.date) as date, shift_type FROM shifts WHERE date LIKE ? AND shift_type =?";
    public static String delete_shift_by_date_type = "DELETE FROM shifts WHERE date LIKE ? AND shift_type=?";
    public static String update_worker_constraints = "UPDATE workers_availability SET day1=?,day2=?,day3=?,day4=?,day5=?,day6=?,day7=? where ssn=?";
    public static String delete_shift_by_ssn = "DELETE FROM shifts WHERE ssn = ?";
    public static String get_shift_by_date_type_or_double = "SELECT ssn, strftime('%Y-%m-%d', shifts.date) as date, shift_type FROM shifts WHERE date LIKE ? AND shift_type =? OR shift_type=3";
    public static String delete_user_by_ssn = "DELETE FROM users WHERE ssn = ?";
    public static String store_id_by_ssn = "select storeId from workers inner join stores_managers on stores_managers.ssn = workers.worker_ssn where workers.worker_ssn=?;";
    public static String store_id_by_ssn_storekeeper = "select storeId from workers inner join storekeeper on storekeeper.ssn = workers.worker_ssn where workers.worker_ssn=?;";
    public static String get_product_by_id = "SELECT * FROM products WHERE id = ?";
    public static String expired_orders_update_min1 = "update orders set start_handle_after_days = -1 where start_handle_after_days != -1 and start_handle_after_days != -2 and start_handle_after_days+7 < ?;";
    public static String getDriverBySsn = "SELECT * FROM drivers WHERE ssn=?";
    public static String delete_store_manager_by_ssn = "DELETE FROM stores_managers where ssn=?;";
    public static String delete_store_cashier_by_ssn = "DELETE FROM stores_cashiers where ssn=?;";
    public static String delete_storekeeper_by_ssn = "DELETE FROM storekeeper where ssn=?;";
    public static String orders_update_as_handled = "UPDATE orders SET start_handle_after_days = -2 WHERE sid=? and store_num=? and date=?;";
    public static String getOrder = "select * from orders where date = ? and store_num = ? and sid = ?;";
    public static String site_by_id = "select * from sites where address = ?;";
    public static String site_inner_stores_by_id = "select * from sites inner join stores on sites.address = stores.site_id where address = ?;";
    public static String store_keeper_by_ssn = "select * from storekeeper where ssn = ?";
    public static String store_manager_by_ssn = "select * from stores_managers where ssn = ?";
    public static String insert_manager = "insert into stores_managers (ssn) values (?);";
    public static String insert_storekeeper = "insert into storekeeper (ssn) values (?);";
}
