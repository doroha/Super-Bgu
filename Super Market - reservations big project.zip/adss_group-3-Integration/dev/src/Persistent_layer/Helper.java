package Persistent_layer;

import Bussiness_layer.Config;
import Bussiness_layer.DAO.Shift_DAO;
import Bussiness_layer.DAO.Worker_DAO;
import Bussiness_layer.Passive_objects.Shift;
import Bussiness_layer.Passive_objects.Worker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class Helper {
    private static Random rnd = new Random();

    public static void fillDemoShifts(DatabaseManager dbm) {
        Worker_DAO worker_dao = new Worker_DAO(dbm);
        Shift_DAO shift_dao = new Shift_DAO(dbm);
        List<Worker> workers = worker_dao.getWorkers();
        String ndt = nowDateTime();
        for (Worker w : workers) {
            shift_dao.Insert(new Shift(w.getSsn(), ndt, 3));
        }
    }

    public static int nextSsn(DatabaseManager dbm) {
        int generatedSsn = -1;
        boolean fail = true;
        while (fail) {
            generatedSsn = rnd.nextInt(Config.ssn_limit);
            Worker_DAO wdao = new Worker_DAO(dbm);
            fail = wdao.workerExist(generatedSsn);
        }
        return generatedSsn;
    }

    public static String nowDateTime() {
        SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);
        return formatter.format(new Date());
    }

    public static Date addDays(Date date, int days)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); //minus number would decrement the days
        return cal.getTime();
    }
}
