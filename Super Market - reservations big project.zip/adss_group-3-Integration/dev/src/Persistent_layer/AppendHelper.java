package Persistent_layer;

import Bussiness_layer.Config;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;

public class AppendHelper {
    public static void append(String txt) {
        try {
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(Config.logFile, true)  //Set true for append mode
            );
            writer.newLine();// Add new line
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            writer.write(timestamp.toString() + " : " + txt);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
