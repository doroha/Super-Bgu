-- Increase specific order amount
update products_at_orders set amount = amount * 5 where date = '2019-03-28 16:37:00' and store_num = 2 and sid = 1;


-- Test query for shifts
select ssn, date, shift_type, storeId, job from
((select storekeeper.ssn, date, shift_type from
shifts inner join storekeeper on shifts.ssn = storekeeper.ssn) as storekeepers
 inner join workers on storekeepers.ssn = workers.worker_ssn) as fullsk;

-- No workers constraints
update workers_availability set
day1=3,
day2=3,
day3=3,
day4=3,
day5=3,
day6=3,
day7=3;



-- Delete all tables + views
PRAGMA writable_schema = 1;
delete from sqlite_master where type in ('table', 'index', 'trigger', 'view');
PRAGMA writable_schema = 0;


-- Queries to deliveries revision
-- For fetching delivery_forms of unrevised deliveries.
select * from delivery_forms where revised = 0 and where store_num = ?;

-- From the query above you extract the date(not began_at, different column named date), sid and store_num
-- Which will be used to query specific products
select products_at_orders.* from delivery_forms inner join orders on
	delivery_forms.date=orders.date and
	delivery_forms.sid=orders.sid and
	delivery_forms.store_num=orders.store_num
	inner join products_at_orders on
	products_at_orders.date=orders.date and
	products_at_orders.sid=orders.sid and
	products_at_orders.store_num=orders.store_num
	where orders.sid = 3 and orders.store_num=2 and orders.date = '2019-01-03 16:37:00';


-- From here you will use an update of the following form
update delivery_forms set issues = 'Some issue....', revised = 1
	where delivery_forms.sid = 3 and delivery_forms.store_num=2 and delivery_forms.date = '2019-01-03 16:37:00';