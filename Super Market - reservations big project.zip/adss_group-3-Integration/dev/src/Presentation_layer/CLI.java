package Presentation_layer;

import Bussiness_layer.*;
import Bussiness_layer.DAO.*;
import Bussiness_layer.Passive_objects.*;
import Persistent_layer.DatabaseManager;
import Persistent_layer.Helper;
import Persistent_layer.ResultSetPrinter;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;

public class CLI {
    private static Scanner input = new Scanner(System.in);
    private static DatabaseManager dbm;
    private static Connection conn;
    private static User_Handler main_handler;


    private static void sop(String s) {
        System.out.println(s);
    }

    public static void main(String[] args) {

        File dbFile = new File(Config.dbFile);
        if (!dbFile.exists()) {
            sop("Database file was not found");
            return;
        }
        conn = DatabaseConnector.getConn(Config.dbFile);
        if (conn != null) {
            dbm = new DatabaseManager(conn);
            DaysThread dt = new DaysThread(conn);
            Thread daysThread = new Thread(dt);

            System.out.print("Username: ");
            String username = input.nextLine();
            System.out.print("Password: ");
            String password = input.nextLine();
            User user = dbm.login(username, password);
            sop("Checking credentials...");
            if (user != null) {
                // Fill all workers with shifts for today.
                Helper.fillDemoShifts(dbm);
                main_handler = new User_Handler(dbm, dt);
                // Initiates days thread
                daysThread.start();
                // Check missing products
                main_handler.checkProductsMinimalAmountAllStores();
                main_handler.getAutomaticOrdersHandlerThread().start();
                sop("Login successful\n");
                boolean showMenu = true;
                while (showMenu) {
                    sop(String.format("Please choose a sub-system: \n%s", "1) Workers\n2) Transportation\n3) Inventory\n4) Suppliers\n5) Quit"));
                    String op = input.nextLine();
                    switch (op) {
                        case "1":
                            initConsole1(user);
                            break;
                        case "2":
                            if (user.permissionLevel() != 2) {
                                sop("Only transportation managers can enter this sub-system");
                            } else {
                                initConsole2(user);
                            }
                            break;
                        case "3":
                            initConsole3(user, dt);
                            break;
                        case "4":
                            Supplier_DAO supplier_dao = new Supplier_DAO(dbm);
                            if (!supplier_dao.isExist(user.permissionLevel())) {
                                sop("The user permission level doesn't match any existing supplier");
                            } else {
                                initConsole4(user, dt);
                            }
                            break;
                        case "5":
                            showMenu = false;
                            break;
                        default:
                            sop("Option does not exists, please try again.");
                            break;
                    }
                }
            } else {
                sop("Login failed!\n");
            }
            try {
                sop("Closing up threads, can take a sec...");
                if (main_handler != null && main_handler.getAutomaticOrdersHandler() != null) {
                    main_handler.getAutomaticOrdersHandler().stopExecution();
                    main_handler.getAutomaticOrdersHandlerThread().interrupt();
                    dt.stop();
                    daysThread.join();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } else {
            sop("Database connection wasn't established");
        }
    }

    private static void printCommandsPanel1(User user) {
        sop("Commands:");
        if (user.permissionLevel() == 1) {
            sop("\t1. Insert");
            sop("\t2. Update");
            sop("\t3. Info");
            sop("\t4. Delete");
            sop("\t5. Cancel Order");
            sop("\t6. Approve Order Cancelling");
            sop("\t7. Disapprove Order Cancelling");
            sop("\t8. Exit");
        } else {
            sop("\t1. Insert schedule");
            sop("\t2. Update");
            sop("\t8. Exit");
        }
    }


    // Inventory
    public static void initConsole3(User user, DaysThread dt) {
        Store_DAO store_dao = new Store_DAO(dbm);
        String choise = "";
        boolean stay = true;
        int storeId = store_dao.getStoreIdBySsn(user.getSsn());
        if (storeId == -1) {
            storeId = store_dao.getStorekeeperIdBySsn(user.getSsn());
            if (storeId == -1) {
                sop("The logged user isn't a store manager or Storekeeper");
                return;
            }
            sop("The logged user is a storekeeper");
            if (main_handler == null) {
                main_handler = new User_Handler(dbm, dt);
            }
            main_handler.setStoreNumber(storeId);
            while (stay) {
                initConsoStoreKeeper();
                choise = input.nextLine();
                switch (choise) {
                    case "1":
                        initConsoleView(user, stay);
                        break;
                    case "2":
                        initStoreKeeperOptions(user, stay,storeId);
                        break;
                    case "3":
                        stay = false;
                        break;
                    default:
                        sop("Option does not exists, please try again.");
                        break;
                }
            }
        } else {
            sop("The logged user is a store manager");
            if (main_handler == null) {
                main_handler = new User_Handler(dbm, dt);
            }
            main_handler.setStoreNumber(storeId);
            while (stay) {
                stay = initConsoleView(user, stay);
            }

        }


    }

    public static void printsupplierMenu()
    {
        System.out.println("-----------------------------");
        System.out.println("|                            |");
        System.out.println("|      SUPPLIERS MODULE      |");
        System.out.println("|                            |");
        System.out.println("-----------------------------");
        System.out.println("1 : Add new Supplier Card");
        System.out.println("2 : Update Existing Supplier Card");
        System.out.println("3 : Delete Supplier Card");
        System.out.println("4 : Print Supplier Card");
        System.out.println("5 : Print all suppliers");
        System.out.println("6 : Add New Product(s) to Agreement");
        System.out.println("7 : Update product At Agreement");
        System.out.println("8 : Delete Product From Agreement");
        System.out.println("9 : Print all supplier own product");
        System.out.println("10: in order to return to previous menu");

    }


    private static int readInput(int lowerBound, int higherBound){
        System.out.print("Choice: ");
        String inputString = input.next();
        input.nextLine();
        try {
            int inputNumeric = Integer.parseInt(inputString);

            while (inputNumeric < lowerBound | inputNumeric > higherBound) //not valid
            {
                System.out.println("Invalid input, please refer to the menu");
                inputString = input.next();
                inputNumeric = Integer.parseInt(inputString);
            }
            return inputNumeric;
        }

        catch (NumberFormatException ex) {
            System.out.println("Invalid input, please refer to the menu\n");
            return readInput(lowerBound,higherBound);}
    }
//=============================Inventory====================================
    public static boolean initConsoleView(User user, boolean stay)
    {
        sop("1 - Print all products");
        sop("2 - Print all categories");
        sop("3 - print all DamagedProducts");
        sop("4 - print Sellings History");
        sop("5 - Get product report by category");
        sop("6 - Exit");
        String Vo = "";
        Vo = input.nextLine();
        switch (Vo){
            case "1":
                main_handler.print_list_of_products();
                break;
            case "2":
                main_handler.printallcategories();
                break;
            case "3":
                main_handler.print_list_of_damaged_products();
                break;
            case "4":
                main_handler.printAllSoldProducts();
                break;
            case "5":
                LinkedList<Integer> category_ids = new LinkedList<>();
                String cat = "";
                while (!(cat.equals("-1")))
                {
                    main_handler.printallcategories();
                    System.out.println("Choose Category ID for report");
                    System.out.println("back for exit");
                    System.out.println("-1 to lunch");
                    cat = input.nextLine();
                    if (cat.equals("back")) {break;}
                    if (!(cat.equals("-1")))
                    {
                        try {
                            int i = (Integer.parseInt(cat));
                            category_ids.add(i);
                        }
                        catch(Exception ex)
                        {
                            System.out.println("Input is not an int\n");
                            break;
                        }

                    }
                }
                main_handler.print_all_products_By_categories(category_ids);
                break;
            case "6":
                return false;
            default:
                sop("Option does not exists, please try again.");
                break;
        }

        return true;

    }
    static private Order queryForOrderFromUser(){
        int supId;
        SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);
        int storeNum;
        Date ordrDate = null;
        try{
            System.out.println("Please eneter supplier ID (number)");
            supId=Integer.parseInt(input.nextLine());

            System.out.println("Please insert date (including time) [yyyy-MM-dd HH:mm:ss]");
            String ds = input.nextLine();
            try {
                ordrDate = formatter.parse(ds);
            } catch (Exception e) {
                sop("Invalid date/time given.");
                return null;
            }
            System.out.println("Please insert order storeNum (number)");
            storeNum=Integer.parseInt(input.nextLine());
        } catch(Exception ex) {
            System.out.println("Illegal inputs, try again");
            return null;
        }
     Order order=main_handler.getOrder(supId,storeNum,ordrDate);
        return order;
    }
    static private void cancelOrder(int role_id){
        if(main_handler.printOrdersNotInCancellationTable()) {
            Order order=queryForOrderFromUser();
            if(order==null){
                System.out.println("invlaid args has been passed,try again");
            } else {
                main_handler.cancelNotYetCanceldOrder(order,role_id);
            }
        }

    }
    static private void approveCancelOrder(int role_id) {
        if(main_handler.printOrdersThatneedToApproved(role_id)) {
            Order order = queryForOrderFromUser();
            if (order == null) {
                System.out.println("invlaid args has been passed,try again");
            } else {
                main_handler.approveOrderCancellation(order, role_id);
            }
        }
    }
    static private void disApproveCancelOrder(int role_id) {
       if(main_handler.printOrdersThatneedToApproved(role_id)) {
           Order order1=queryForOrderFromUser();
           if(order1==null){
               System.out.println("invlaid args has been passed,try again");
           } else {
               main_handler.disApproveCancellationOrder(order1);
           }
       }
    }
    public static void initConsoStoreKeeper()
    {
        sop("1 - View menu");
        sop("2 - Storekeeper menu");
        sop("3 - Exit");
    }
    public static void initStoreKeeperOptions(User user,boolean stay,int storeID) {
        sop("1 - Insert new category");
        sop("2 - Delete category");
        sop("3 - Delete product");
        sop("4 - Insert new product");
        sop("5 - Report damaged product");
        sop("6 - Manage Arrived deliveries");
        sop("7 - Assign Discount to a product"); // ask sundy
        sop("8 - Assign Discount to a category");
        sop("9 - Cancel Order");
        sop("10 - Approve order cancellation");
        sop("11 - Disapprove order cancellation");
        sop("12 - Exit");
        String STV = "";
        STV = input.nextLine();

        switch (STV) {
            case "1":
                int father_id = 0;
                System.out.println("Printing all categories under the root");
                main_handler.printallsons(father_id);
                String cid = "";
                while (!(cid.equals("b")))
                {
                    System.out.println("Choose Category ID in order to go deeper OR");
                    System.out.println("a - Add new category under this father");
                    System.out.println("b - quit the operation");
                    cid = input.nextLine();

                    if (cid.equals("b")) {break;}
                    if (cid.equals("a"))
                    {
                        String tmp = cid;
                        System.out.println("Insert new category name");
                        cid = input.nextLine();
                        String name = cid;
                        cid = tmp;
                        main_handler.insertnewcategory(name, father_id);
                        break;
                    }
                    try {
                        int i = (Integer.parseInt(cid));
                        father_id = i;
                        main_handler.printallsons(father_id);
                    }
                    catch(Exception ex)
                    {
                        System.out.println("Input is not an int\n");
                        break;
                    }
                }
                break;
            case "2":
                String dco = "";
                System.out.println("Note: All sub-categories will get deleted");
                System.out.println("To cancel press b");
                main_handler.printallcategories();
                System.out.println("Enter Category ID");
                dco = input.nextLine();
                if (dco.equals("b")) {break;}
                try {
                    int category_id = (Integer.parseInt(dco));
                    main_handler.delete_ctree(category_id);
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }
                break;
            case "3":
                String prid = "";
                main_handler.print_list_of_products();
                System.out.println("Choose product id or b to exit");
                prid = input.nextLine();
                if (prid.equals("b")) {break;}
                try {
                    int product_id = (Integer.parseInt(prid));
                    main_handler.delete_product(product_id);
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }
                break;
            case "4":
                String prod = "";
                main_handler.print_list_of_products();
                System.out.println("Choose product id or b to exit");
                prod = input.nextLine();
                int product_id_to_insert;
                if (prod.equals("b")) {break;}
                try {
                    product_id_to_insert = (Integer.parseInt(prod));
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }
                if (main_handler.id_exsist(product_id_to_insert))
                {
                    System.out.println("This ID is already taken: " + product_id_to_insert);
                    break;
                }
                else
                {
                    System.out.println("Enter the name");
                    prod = input.nextLine();
                    String name = prod;
                    main_handler.printallcategories();
                    System.out.println("Enter the last_category: ");
                    prod = input.nextLine();
                    int l_category;
                    try {
                        l_category = (Integer.parseInt(prod));
                    }
                    catch(Exception ex) {
                        System.out.println("Input is not an int\n");
                        break;
                    }
                    if (main_handler.checkcategoryid(l_category))
                    {
                        System.out.println("Enter minimal amount: ");
                        prod = input.nextLine();
                        int minimal_amount;
                        try {
                            minimal_amount = (Integer.parseInt(prod));
                        }
                        catch(Exception ex) {
                            System.out.println("Input is not an int\n");
                            break;
                        }
                        System.out.println("Enter location");
                        prod = input.nextLine();
                        String location = prod;
                        System.out.println("Enter producer");
                        prod = input.nextLine();
                        String producer = prod;
                        System.out.println("Enter selling price: ");
                        prod = input.nextLine();
                        int price;
                        try {
                            price = (Integer.parseInt(prod));
                        }
                        catch(Exception ex) {
                            System.out.println("Input is not an int\n");
                            break;
                        }
                        System.out.println("Enter weight: ");
                        prod = input.nextLine();
                        int weight;
                        try {
                            weight = (Integer.parseInt(prod));
                        }
                        catch(Exception ex) {
                            System.out.println("Input is not an int\n");
                            break;
                        }
                        main_handler.insert_product(product_id_to_insert,weight, name, l_category, minimal_amount, location, storeID, producer, price);
                    }
                    else
                    {
                        System.out.println("No such category id" + l_category);
                    }
                }
                break;
            case "5":
                String prod_to_report = "";
                main_handler.print_list_of_products();
                System.out.println("Choose product id or b to exit");
                prod_to_report = input.nextLine();
                int product_id;
                if (prod_to_report.equals("b")) {break;}
                try {
                    product_id = (Integer.parseInt(prod_to_report));
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }

                int shelf_amount = main_handler.get_shelfamount(product_id);
                if (shelf_amount == -1) {
                    System.out.println("PID not found");
                    break;
                }
                System.out.println("Amount on shelf: " + shelf_amount);
                System.out.println("Choose the amount");
                prod_to_report = input.nextLine();
                int amount_to_report;
                try {
                    amount_to_report = (Integer.parseInt(prod_to_report));
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }
                if (amount_to_report > shelf_amount)
                {
                    System.out.println("The amount is to high");
                }
                else
                {
                    main_handler.reduce_adddmg(product_id, amount_to_report);
                }
                break;
            case "6":
                    main_handler.manageArrivedDeliveries();
                break;
            case "7":
                String prod_disc = "";
                System.out.println("===============All prodcuts===========");
                main_handler.print_list_of_products();
                System.out.println("=======================================");
                System.out.println("Choose product id or b to exit");
                prod_disc = input.nextLine();
                int p_id;
                if (prod_disc.equals("b")) {break;}
                try {
                    p_id = (Integer.parseInt(prod_disc));
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }
                System.out.println("Enter discount amount in % only complete numbers");
                prod_disc = input.nextLine();
                int precantage;
                try {
                    precantage = (Integer.parseInt(prod_disc));
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }
                System.out.println("Enter end_date");
                prod_disc = input.nextLine();
                main_handler.insert_product_discount(storeID, p_id, precantage, prod_disc);
                break;
            case "8":
                String cat_pid = "";
                System.out.println("===============All categories===========");
                main_handler.printallcategories();
                System.out.println("=======================================");
                System.out.println("Choose category id or b to exit");
                cat_pid = input.nextLine();
                int c_id;
                if (cat_pid.equals("b")) {break;}
                try {
                    c_id = (Integer.parseInt(cat_pid));
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }
                System.out.println("Enter discount amount in % only complete numbers");
                cat_pid = input.nextLine();
                int c_discount;
                try {
                    c_discount = (Integer.parseInt(cat_pid));
                }
                catch(Exception ex) {
                    System.out.println("Input is not an int\n");
                    break;
                }
                System.out.println("Enter end_date");
                cat_pid = input.nextLine();
                main_handler.insert_discount(c_id, c_discount, cat_pid);
                break;
            case "9":                //Approve Order Cancel
                cancelOrder(0);
                break;
            case "10":                //Disapprove Order Cancel
                approveCancelOrder(0);
                break;
            case "11":                //Disapprove Order Cancel
                disApproveCancelOrder(0);
                break;
            case "12":
                break;
            default:
                sop("Option does not exists, please try again.");
                break;
        }
    }



//=============================Inventory====================================
        // Suppliers
        public static void initConsole4 (User user, DaysThread dt){
            if (main_handler == null) {
                main_handler = new User_Handler(dbm, dt);
            }
            printsupplierMenu();
            int u_choice = readInput(1, 11);
            switch (u_choice) {
                case 1:
                    main_handler.addNewSupplierCard();
                    break;
                case 2:
                    main_handler.updateSupplierCard();
                    break;
                case 3:
                    main_handler.deleteSupplierCard();
                    break;
                case 4:
                    main_handler.printSupplierCard();
                    break;
                case 5:
                    main_handler.printAllSuppliers();
                    break;
                case 6:
                    main_handler.addProductsToAgreement();
                    break;
                case 7:
                    main_handler.updateProductAtAgreement();
                    break;
                case 8:
                    main_handler.deleteProductFromAgreement();
                    break;
                case 9:
                    main_handler.printSuppliersByProdId();
                    break;
                case 10:
                    // main_handler.getBestOffer();
                    break;
            }
        }



    private static void initConsole1(User user) {

        boolean display = true;
        int command;
        Scanner input = new Scanner(System.in);

        Availability_DAO availability_dao = new Availability_DAO(dbm);
        Shift_DAO shiftDao = new Shift_DAO(dbm);
        Store_DAO storeDao = new Store_DAO(dbm);
        Worker_DAO workerDao = new Worker_DAO(dbm);
        Driver_DAO driverDao = new Driver_DAO(dbm);
        User_DAO userDao = new User_DAO(dbm);

        while (display) {
            printCommandsPanel1(user);
            try {
                command = input.nextInt();
            } catch (Exception ex) {
                sop("Invalid input");
                break;
            }
            switch (command) {
                case 1: //insert
                    if (user.permissionLevel() == 1) {
                        sop("\t1. Worker");
                        sop("\t2. Shift");
                        sop("\t3. return");
                    } else {
                        sop("\t1. Constraints - Be advised, shifts will reset.");
                        sop("\t3. return");
                    }
                    int choice = 0;
                    String[] in;
                    int index = 0;
                    try {
                        choice = input.nextInt();
                    } catch (Exception ex) {
                        System.out.println("Invalid input");
                        break;
                    }
                    switch (choice) {
                        case 1:
                            if (user.permissionLevel() == 1) {
                                workerDao.Insert(addWorker());
                                sop("Worker added.");
                            } else {
                                sop("\tExpected format: d1 d2 ... d7 where dx may be\n\t(0-Not possible,1-morning,2-evening,3- both)");
                                String s = input.nextLine();
                                s = input.nextLine();
                                in = s.trim().split(" ");
                                availability_dao.Insert(new Availability(user.getSsn(), Integer.parseInt(in[index++]), Integer.parseInt(in[index++]), Integer.parseInt(in[index++]), Integer.parseInt(in[index++]), Integer.parseInt(in[index++]), Integer.parseInt(in[index++]), Integer.parseInt(in[index++])));
                            }
                            break;
                        case 2:
                            if (user.permissionLevel() == 1) {
                                int id;
                                String dateInp;
                                sop("\tPlease insert Worker ssn:");
                                try {
                                    id = input.nextInt();
                                } catch (Exception ex) {
                                    System.out.println("Invalid input");
                                    break;
                                }
                                if (!workerDao.workerExist(id)) {
                                    sop(String.format("Failed to found worker with ssn: %d", id));
                                    return;
                                }
                                sop("\tPlease insert date[yyyy-MM-dd] of shift:");
                                input.nextLine(); // Due to /n
                                dateInp = input.nextLine();
                                String[] parts = dateInp.trim().split("-");
                                Date d;
                                int day, month, year;
                                try {
                                    if (parts.length != 3) {
                                        throw new Exception();
                                    }
                                    day = Integer.valueOf(parts[2]);
                                    month = Integer.valueOf(parts[1]);
                                    year = Integer.valueOf(parts[0]);

                                    d = new GregorianCalendar(year, month - 1, day).getTime();
                                } catch (Exception e) {
                                    sop("Invalid date given");
                                    return;
                                }
                                sop("\tInsert work expected format: d1 d2 .... where dx may be (0=don't need,1=morning,2=evening,3=double)");
                                String s = input.nextLine();
                                String[] requirements = s.trim().split(" ");
                                int[] requirements_i = new int[requirements.length];
                                int i = 0;
                                for (String req : requirements) {
                                    if (!req.equals("0") && !req.equals("1") && !req.equals("2") && !req.equals("3")) {
                                        sop("Invalid array given, expected 1,2 or 3");
                                        return;
                                    }
                                    requirements_i[i] = Integer.valueOf(req);
                                    i++;
                                }

                                // Date is ok
                                SimpleDateFormat formatter = new SimpleDateFormat(Config.timestamp_pattern);
                                String date = formatter.format(d);

                                if (workerDao.getWorker(id) == null) break;
                                Availability availability = availability_dao.getSchedule(id);
                                if (availability != null) {
                                    int[] daysConstraints = availability.getDays();
                                    // from 1 (Monday) to 7 (Sunday)
                                    DayOfWeek dow = LocalDate.of(year, month, day).getDayOfWeek();
                                    int dy = dow.getValue() + 1;
                                    // Now 1 is sunday, 7 is saturday
                                    if (dy == 8) {
                                        dy = 1;
                                    }
                                    dy--; // Now 0 is sunday, 6 is saturday

                                    int req_i_len = requirements_i.length;
                                    int j = 0;
                                    while (j < req_i_len) {

                                        // Was the worker even requested this day.
                                        if (requirements_i[j] > 0) {
                                            int dConstraint = daysConstraints[dy];
                                            /*
                                             * The assigning will work if there is a match
                                             * or there is no match and then it can work
                                             * only if dConstraint = 3
                                             * */
                                            if ((dConstraint == requirements_i[j])
                                                    || (dConstraint != requirements_i[j] && dConstraint == 3)) {
                                                shiftDao.Insert(new Shift(id, date, requirements_i[j]));
                                                sop(String.format("Worker constraint accepted shift idx: %d", j));
                                            } else { // dConstraint=0 or req=morning,cont=evening or vise-versa
                                                sop(String.format("Worker constraint rejected shift idx: %d with constraint: %d", j, dConstraint));
                                            }
                                        }
                                        try {
                                            Date myDate = formatter.parse(date);
                                            d = Helper.addDays(myDate, 1);
                                            date = formatter.format(d);
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                        dy = (dy + 1) % 7;
                                        j++;
                                    }
                                } else {
                                    int req_i_len = requirements_i.length;
                                    int j = 0;
                                    while (j < req_i_len) {
                                        if (requirements_i[j] > 0) {
                                            shiftDao.Insert(new Shift(id, date, requirements_i[j]));
                                            sop(String.format("Inserted shift idx: %d", j));
                                        }
                                        try {
                                            Date myDate = formatter.parse(date);
                                            d = Helper.addDays(myDate, 1);
                                            date = formatter.format(d);
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                        j++;
                                    }
                                }
                            }
                        break;
                        case 3:
                            break;
                    }
                    break;
                case 2: //Update
                    if (user.permissionLevel() == 1) {
                        sop("\t1. Worker");
                        sop("\t3. return");
                    } else {
                        sop("\t1. Worker");
                        sop("\t2. Constraints - Be advised, shifts will reset.");
                        sop("\t3. return");
                    }
                    int ch = 0;
                    int id;
                    Worker w;
                    try {
                        ch = input.nextInt();
                    } catch (Exception ex) {
                        System.out.println("Invalid input");
                        break;
                    }
                    switch (ch) {
                        case 1: //worker
                            id = user.getSsn();
                            if (user.permissionLevel() == 1) {
                                sop("\tPlease insert ssn");
                                try {
                                    id = input.nextInt();
                                } catch (Exception ex) {
                                    sop("Invalid input");
                                    break;
                                }
                                if (!workerDao.workerExist(id)) {
                                    sop("Worker with this ssn doesn't exists");
                                    break;
                                }
                            }
                            sop("\tPlease insert Update Details");
                            sop("\t1. Bank account");
                            if (user.permissionLevel() == 1) {
                                sop("\t2. Salary");
                                sop("\t3. Store");
                                sop("\t4. Condition");
                                sop("\t5. Job");
                                sop("\t6. return");
                            }
                            else {
                                sop("\t2. return");
                            }

                            int c;
                            int var = 0;
                            try {
                                c = input.nextInt();
                            } catch (Exception ex) {
                                System.out.println("Invalid input");
                                break;
                            }
                            if (user.permissionLevel() == 0 && c >= 2) {
                                break;
                            }
                            if (user.permissionLevel() != 1 && c == 2) {
                                break;
                            }
                            switch (c) {
                                case 1:
                                    sop("\tPlease insert new detail");
                                    try {
                                        var = input.nextInt();
                                    } catch (Exception ex) {
                                        sop("Invalid input");
                                        break;
                                    }
                                    w = workerDao.getWorker(id);
                                    if (workerDao.updateBankAccount(w.getSsn(), var)) {
                                        sop("Bank account updated successfully");
                                    }
                                    else {
                                        sop("Bank account update failed");
                                    }
                                    break;
                                case 2:
                                    sop("\tPlease insert new detail");
                                    try {
                                        var = input.nextInt();
                                    } catch (Exception ex) {
                                        sop("Invalid input");
                                        break;
                                    }
                                    w = workerDao.getWorker(id);
                                    if (workerDao.updateSalary(w.getSsn(), var)) {
                                        sop("Salary updated successfully");
                                    } else {
                                        sop("Salary update failed");
                                    }
                                    break;
                                case 3:
                                    sop("\tPlease insert new detail");
                                    try {
                                        var = input.nextInt();
                                        if (!storeDao.isExist(var)) { throw new Exception(); }
                                    } catch (Exception ex) {
                                        sop("Invalid input / Store doesn't exists");
                                        break;
                                    }
                                    w = workerDao.getWorker(id);
                                    if (workerDao.updateStoreId(w.getSsn(), var)) {
                                        sop("Store updated successfully");
                                    }
                                    else {
                                        sop("Store update failed");
                                    }
                                   break;
                                case 4:
                                    sop("\tPlease insert new detail");
                                    input.nextLine(); // Due to the tab
                                    String co = input.nextLine();
                                    w = workerDao.getWorker(id);
                                    if (workerDao.updateCondition(w.getSsn(), co)) {
                                        sop("Condition updated successfully");
                                    }
                                    else {
                                        sop("Condition update failed");
                                    }
                                    break;
                                case 5:
                                    String jo;
                                    sop("\tPlease insert new detail");
                                    input.nextLine(); // To clear the buffer.
                                    jo = input.nextLine();
                                    w = workerDao.getWorker(id);
                                    if (workerDao.updateJob(w.getSsn(), jo)) {
                                        sop("Job description updated successfully");
                                    }
                                    else {
                                        sop("Job description update failed");
                                    }
                                    break;
                                case 6: //return
                                    break;
                            }
                            break;
                        case 2: //Constraints
                            if (user.permissionLevel() == 1) {
                                sop("Error");
                                break;
                            }
                            int constraint;
                            Availability availability = availability_dao.getSchedule(user.getSsn());
                            sop("\tPlease insert day[1-7] to update");
                            int dayI;
                            try {
                                dayI = input.nextInt();
                            } catch (Exception ex) {
                                sop("Invalid input");
                                break;
                            }
                            input.nextLine(); // Consume \n
                            if (dayI < 1 || dayI > 7) {
                                sop("Invalid day");
                                break;
                            }
                            sop("\tPlease insert constraint 0=Can't/1=Morning/2=Evening/3=Double");
                            try {
                                constraint = input.nextInt();
                            } catch (Exception ex) {
                                sop("Invalid input");
                                break;
                            }
                            availability.setDayX(dayI, constraint);
                            availability_dao.updateConstraints(workerDao.getWorker(user.getSsn()), availability);
                            break;
                        case 3: //return
                            break;
                    }
                    break;
                case 3: //info
                    sop("\t1. Worker");
                    sop("\t2. Workers");
                    sop("\t3. Store");
                    sop("\t4. Stores");
                    sop("\t5. Shift");
                    sop("\t6. Shifts");
                    sop("\t7. return");
                    int c;
                    try {
                        c = input.nextInt();
                    } catch (Exception ex) {
                        sop("Invalid input");
                        break;
                    }
                    switch (c) {
                        case 1:
                            sop("\tPlease insert ssn");
                            try {
                                id = input.nextInt();
                            } catch (Exception ex) {
                                sop("Invalid input");
                                break;
                            }
                            if (id != 0) {
                                workerDao.printWorker(id);
                                sop("Schedule:\n");
                                availability_dao.printAvailabilityBySsn(id);
                                sop("Shifts:\n");
                                shiftDao.printShift(id);
                            } else
                                sop("Worker id doesn't exists");
                            break;
                        case 2:
                            LinkedList<Worker> workers = workerDao.getWorkers();
                            if (workers != null) {
                                for (Worker wr : workers) {
                                    workerDao.printWorker(wr.getSsn());
                                    sop("Schedule:\n");
                                    availability_dao.printAvailabilityBySsn(wr.getSsn());
                                    sop("Shifts:\n");
                                    shiftDao.printShift(wr.getSsn());
                                }
                            } else
                                sop("There are no workers in the system");
                            break;
                        case 3: //shift
                            sop("\tPlease insert store id");
                            try {
                                id = input.nextInt();
                            } catch (Exception ex) {
                                sop("Invalid input");
                                break;
                            }
                            storeDao.printStoreById(id);
                            break;
                        case 4:
                            LinkedList<Store> stores = storeDao.getStores();
                            if (stores != null) {
                                for (Store s : stores)
                                    storeDao.printStoreById(s.getID());
                            } else
                                sop("There are no stores in the system");
                            break;
                        case 5: //shift
                            sop("\tPlease insert date[yyyy-MM-dd] of shift");
                            String dateInp = input.next();
                            String[] parts = dateInp.trim().split("-");
                            int day, month, year;
                            if (parts.length != 3) {
                                sop("Invalid date given.");
                                break;
                            }
                            day = Integer.valueOf(parts[2]);
                            month = Integer.valueOf(parts[1]);
                            year = Integer.valueOf(parts[0]);
                            try {
                                new GregorianCalendar(year, month - 1, day).getTime();
                            } catch (Exception e) {
                                sop("Invalid date given");
                                break;
                            }
                            sop("\tPlease insert morning(1) or evening(2)");
                            int type;
                            try {
                                type = input.nextInt();
                            } catch (Exception ex) {
                                sop("Invalid input");
                                break;
                            }
                            LinkedList<Integer> workersOfShift = shiftDao.getWorkersOfShift(dateInp.trim(), type);
                            if (type == 1) {
                                sop("\tShift morning on date - " + dateInp.trim());
                            } else {
                                sop("\tShift evening on date - " + dateInp.trim());
                            }
                            sop("\nWorkers on the shift: ");
                            for (Integer ws : workersOfShift) {
                                sop(workerDao.getWorker(ws).toString() + ",");
                            }
                            break;
                        case 6: //shifts
                            LinkedList<Shift> shifts = shiftDao.getShifts();
                            if (shifts != null) {
                                for (Shift s : shifts) {
                                    if (s.getShift_type() == 1)
                                        sop("\tShift morning on day - " + s.getDate());
                                    else sop("\tShift evening on day - " + s.getDate());
                                    LinkedList<Integer> workersInShift = shiftDao.getWorkersOfShift(s.getDate(), s.getShift_type());
                                    sop("\nWorkers on the shift: ");
                                    for (Integer ws : workersInShift)
                                        sop(workerDao.getWorker(ws).toString() + ",");
                                    sop("\n");
                                }
                            } else
                                sop("There are no shifts in the system");
                            break;
                        case 7:
                            break;
                    }
                    break;
                case 4: //Delete
                    sop("\t1. Worker");
                    sop("\t2. Shift assigned to worker");
                    sop("\t3. return");
                    int cd = 0;
                    try {
                        cd = input.nextInt();
                    } catch (Exception ex) {
                        sop("Invalid input");
                    }
                    switch (cd) {
                        case 1: //worker
                            sop("\tPlease insert ssn:");
                            try {
                                id = input.nextInt();
                            } catch (Exception ex) {
                                sop("Invalid input");
                                break;
                            }
                            if (!workerDao.workerExist(id)) {
                                sop("There is no worker with this ssn");
                                break;
                            }
                            Worker worToRemove = workerDao.getWorker(id);
                            workerDao.Delete(worToRemove); // Internally will delete shifts,availability,user and worker.
                            break;
                        case 2:  //WorkerInShift
                            sop("\tPlease insert ssn:");
                            try {
                                id = input.nextInt();
                            } catch (Exception ex) {
                                sop("Invalid input");
                                break;
                            }
                            if (!workerDao.workerExist(id)) {
                                sop("Worker doesn't exists");
                                break;
                            }
                            sop("\tPlease choose date[yyyy-MM-dd] of shift");
                            String dateInp = input.next();
                            String[] parts = dateInp.trim().split("-");
                            int day, month, year;
                            if (parts.length != 3) {
                                sop("Invalid date given.");
                                break;
                            }
                            day = Integer.valueOf(parts[2]);
                            month = Integer.valueOf(parts[1]);
                            year = Integer.valueOf(parts[0]);
                            try {
                                new GregorianCalendar(year, month - 1, day).getTime();
                            } catch (Exception e) {
                                sop("Invalid date given");
                                break;
                            }
                            shiftDao.Delete(new Shift(id, dateInp.trim(), 0));
                            break;
                        case 3:  //return
                            break;
                    }
                    break;
                case 5: // cancel order
                    if (user.permissionLevel() == 1) {
                        cancelOrder(2);
                    }
                    else {
                        display = false;
                    }
                    break;
                case 6: // cancel order
                    if (user.permissionLevel() == 1) {
                        approveCancelOrder(2);
                    }
                    break;
                case 7: //disapprove cancel order
                    if(user.permissionLevel()==1) {
                        disApproveCancelOrder(2);
                    }
                    break;
                case 8: //Exit
                    display = false;
                    break;
            }
        }
    }

    private static void initConsole2(User user) {
        printCommandsPanel2(user);
        ShipmentReady currentSR = null;
        Truck currentTruck = null;
        Driver currentDriver = null;
        List<Timer> timerList = new LinkedList<>();
        Driver_DAO driversDAO = new Driver_DAO(dbm);
        Truck_DAO trucksDAO = new Truck_DAO(dbm);
        Site_DAO sitesDAO = new Site_DAO(dbm);


        while (true) {
            // Read command
            System.out.print(user.getUsername() + "> ");
            String str = input.nextLine();
            String[] parts = str.trim().split(" ");

            // Exit program
            if (parts.length == 1 && parts[0].equals("exit")) {
                if (timerList.size() > 0) {
                    for (Timer t : timerList) {
                        t.cancel();
                    }
                }
                break;
                // Show commands panel
            } else if (parts.length == 1 && parts[0].equals("help")) {
                printCommandsPanel2(user);
                // The next procedure
            } else if (parts.length == 1 && parts[0].equals("next")) {
                if (currentSR != null) {
                    sop("Enter clear command to reuse next.");
                    continue;
                }
                ShipmentReady sr = dbm.getNextShipment();
                if (sr.isEmpty()) {
                    if (sr.getOrigin() == null) {
                        sop("No orders found that can be delivered now.");
                    } else {
                        sop("Couldn't resolve an order. Reason might be:" +
                                "  1. No available truck for the orders found." +
                                "  2. No available driver for the orders found" +
                                "  3. No available store keeper at order's destination" +
                                "Please try again later.");
                    }
                } else {
                    sop(sr.toString());
                    currentSR = sr;
                }
            } else if (parts.length == 1 && parts[0].equals("clear")) {
                if (currentTruck != null) {
                    sop("Please use release command first to release truck.");
                } else if (currentSR == null) {
                    sop("Shipment wasn't set.");
                } else {
                    currentSR = null;
                    sop("Current shipment cleared.");
                }
            } else if (parts.length == 3 && parts[0].equals("disapprove") && parts[1].equals("cancel") && parts[2].equals("order")) {
                disApproveCancelOrder(1);
            } else if (parts.length == 2 && parts[0].equals("cancel") && parts[1].equals("order")) {
                cancelOrder(1);
            }else if (parts.length == 3 && parts[0].equals("approve") && parts[1].equals("cancel") && parts[2].equals("order")) {
                approveCancelOrder(1);
            } else if (parts.length == 2 && parts[0].equals("acquire") && parts[1].equals("truck")) {
                if (currentSR != null) {
                    if (currentTruck == null) {
                        currentTruck = trucksDAO.getTruckForWeightOf(currentSR.getTotalShipmentWeight());
                        if (currentTruck == null) {
                            sop("All trucks were busy, please try again later.");
                        } else {
                            sop(String.format("Truck <%s> was acquired with capacity of %d tons", currentTruck.getPlateId(), currentTruck.getMaxWeight() / 1000));
                        }
                    } else {
                        sop("A truck was already acquired, to re-acquire use release first.");
                    }
                } else {
                    sop("No shipment defined. Use next command first.");
                }
            } else if (parts.length == 2 && parts[0].equals("release") && parts[1].equals("truck")) {
                if (currentDriver == null) {
                    if (currentTruck != null) {
                        trucksDAO.freeTruck(currentTruck.getPlateId());
                        sop(String.format("Truck <%s> was released", currentTruck.getPlateId()));
                        currentTruck = null;
                    } else {
                        sop("No truck was acquired to be released.");
                    }
                } else {
                    sop("A driver was acquired, please release the driver before releasing this truck.");
                }

            } else if (parts.length == 2 && parts[0].equals("acquire") && parts[1].equals("driver")) {
                if (currentTruck != null) {
                    // Notice that I add just here the net weight of the truck
                    currentDriver = driversDAO.getDriverForWeightOf(currentSR.getTotalShipmentWeight() + currentTruck.getNetWeight());
                    if (currentDriver == null) {
                        sop("All drivers were busy, please try again later.");
                    } else {
                        String driver_name = driversDAO.getDriverName(currentDriver.getSsn());
                        sop(String.format("Driver <%s / %s> was acquired with license type %d", driver_name, currentDriver.getSsn(), currentDriver.getLicenseType()));
                    }
                } else {
                    sop("No truck was acquired yet.");
                }
            } else if (parts.length == 2 && parts[0].equals("release") && parts[1].equals("driver")) {
                if (currentDriver != null) {
                    String driver_name = driversDAO.getDriverName(currentDriver.getSsn());
                    driversDAO.freeDriver(currentDriver.getSsn());
                    sop(String.format("Driver <%s / %s> was released", driver_name, currentDriver.getSsn()));
                    currentDriver = null;
                } else {
                    sop("No driver was acquired to be released.");
                }
            } else if (parts.length == 1 && parts[0].equals("execute")) {
                // Note that there is no way that currentSR or currentTruck are null because defining a driver
                // Requires defining a truck and defining a truck requires defining an SR object.
                if (currentDriver != null) {

                    /*
                     * From here we initiate a transaction(database transaction using batches) where:
                     *  1) A transport object get's inserted followed by
                     *  2) Destinations objects get's inserted followed by
                     *  3) Delivery forms get's inserted.
                     *
                     *  If one of the above fail, we rollback and back to the point before hitting execute.
                     * */

                    // Initiate the shipment object
                    MovingShipment shipment = dbm.startShipment(currentSR, currentTruck, currentDriver);
                    if (shipment == null) {
                        sop("Something went wrong, shipment failed.");
                    } else {
                        // Delete the orders I'm about to deliver, as the system avoids overloads the deliveries will always be supplied.
                        if (dbm.clearOrders(currentSR.getOrders())) {
                            sop("Orders cleared. Shipment began. Transport logs are within ./logs file.");
                        } else {
                            sop("Failed to clear orders.");
                        }
                        timerList.add(shipment.beginSimulation(dbm));
                        currentSR = null;
                        currentTruck = null;
                        currentDriver = null;
                    }
                } else {
                    sop("No driver was acquired. use acquire driver command first.");
                }
            } else if (parts.length == 2 && parts[0].equals("show")) {
                if (Config.validToShowTables.contains(parts[1])) {
                    if (parts[1].equals("drivers")) {
                        ResultSetPrinter.printTable(conn, "get_drivers");
                    } else {
                        ResultSetPrinter.printTable(conn, parts[1]);
                    }
                } else {
                    sop("Invalid command");
                }
            } else if (parts.length == 2 && parts[0].equals("add")) {
                switch (parts[1]) {
                    case "driver":
                        driversDAO.Insert(addDriver());
                        break;
                    case "truck":
                        trucksDAO.Insert(addTruck());
                        break;
                    case "site":
                        sitesDAO.Insert(addSite());
                        break;
                    default:
                        sop("Invalid command");
                        break;
                }
            } else if (parts.length == 2 && parts[0].equals("del")) {
                switch (parts[1]) {
                    case "driver":
                        driversDAO.Delete(delDriver());
                        break;
                    case "truck":
                        trucksDAO.Delete(delTruck());
                        break;
                    case "site":
                        sitesDAO.Delete(delSite());
                        break;
                    default:
                        sop("Invalid command");
                        break;
                }
            } else {
                sop("Invalid command");
            }
        }
    }

    private static Truck delTruck() {
        sop("Truck plate id: ");
        String plateId = input.nextLine();
        return new Truck(plateId, 0, 0, 0);
    }

    private static Truck addTruck() {
        String plateId, model, netWeight, maxWeight;
        sop("Truck plate id: ");
        plateId = input.nextLine();
        sop("Truck model[year]: ");
        model = input.nextLine();
        sop("Truck net weight[in kilograms, at most 14K]: ");
        netWeight = input.nextLine();
        sop("Truck max weight[in kilograms, 12K or 15K]: ");
        maxWeight = input.nextLine();
        int modelI, netWeightI, maxWeightI;
        try {
            modelI = Integer.valueOf(model);
        } catch (NumberFormatException noe) {
            sop("Expected a model to be a number.");
            return null;
        }
        try {
            netWeightI = Integer.valueOf(netWeight);
        } catch (NumberFormatException noe) {
            sop("Expected a net weight to be a number.");
            return null;
        }

        try {
            maxWeightI = Integer.valueOf(maxWeight);
        } catch (NumberFormatException noe) {
            sop("Expected a max weight to be a number.");
            return null;
        }

        if (netWeightI > maxWeightI) {
            sop("Net weight cannot be bigger than the max weight.");
        } else if (netWeightI > 14000) {
            sop("Net weight cannot be bigger than 14K");
        } else if (maxWeightI != Config.TYPE_0_LICENSE_MAX_WEIGHT && maxWeightI != Config.TYPE_1_LICENSE_MAX_WEIGHT) {
            sop("Max weight can be 12K or 15K.");
        } else if (modelI <= 0) {
            sop("Please choose a valid year.");
        } else if (plateId.length() == 0) {
            sop("Plate id given empty.");
        } else {
            return new Truck(plateId, modelI, netWeightI, maxWeightI);
        }
        return null;
    }

    private static Site delSite() {
        sop("Site address: ");
        String addr = input.nextLine();
        return new Site(addr, null, null, null);
    }

    private static Site addSite() {
        String address, phone, area, contactName;
        sop("Site address: ");
        address = input.nextLine();
        sop("Site phone: ");
        phone = input.nextLine();
        sop(String.format("Site area[%s]: ", Config.validAreas.toString()));
        area = input.nextLine();
        sop("Contact name: ");
        contactName = input.nextLine();
        if (address.length() == 0) {
            sop("Empty address given.");
        } else if (phone.length() == 0) {
            sop("Empty phone given.");
        } else if (area.length() == 0 || !Config.validAreas.contains(area)) {
            sop("Invalid area given.");
        } else if (contactName.length() == 0) {
            sop("Empty contact name given.");
        } else {
            return new Site(address, phone, area, contactName);
        }
        return null;
    }

    private static Driver delDriver() {
        sop("Driver ssn: ");
        String ssn = input.nextLine();
        try {
            int i = Integer.parseInt(ssn);
            return new Driver(0, 0, new Worker(i, "", "", 0, "", "", 0, 0, ""));
        } catch (NumberFormatException e) {
            sop("Integer expected.");
            return delDriver();
        }
    }

    private static Worker addWorker() {
        String conditions, bankAccount, fname, lname, salary, jobDesc, storeId;
        int bankAccount_i = 0, salary_i = 0, storeId_i = 0;
        sop("Bank account: ");
        bankAccount = input.nextLine();
        try {
            bankAccount_i = Integer.parseInt(bankAccount);
        } catch (NumberFormatException e) {
            sop("Integer expected.");
            return addWorker();
        }
        sop("Salary: ");
        salary = input.nextLine();
        try {
            salary_i = Integer.parseInt(salary);
        } catch (NumberFormatException e) {
            sop("Integer expected.");
            return addWorker();
        }
        sop("Store id: ");
        storeId = input.nextLine();
        try {
            storeId_i = Integer.parseInt(storeId);
            Store_DAO store_dao = new Store_DAO(dbm);
            if (!store_dao.isExist(storeId_i)) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            sop("Integer of exists store expected.");
            return addWorker();
        }
        sop("First name: ");
        fname = input.nextLine();
        sop("Last name: ");
        lname = input.nextLine();
        sop("Conditions");
        conditions = input.nextLine();
        sop("Job description");
        jobDesc = input.nextLine();
        if (jobDesc.length() == 0) {
            sop("Empty job description given.");
        } else if (fname.length() == 0) {
            sop("First name given empty");
        } else if (lname.length() == 0) {
            sop("Last name given empty");
        } else {
            try {
                return new Worker(Helper.nextSsn(dbm), fname, lname, bankAccount_i, Helper.nowDateTime(), conditions, salary_i, storeId_i, jobDesc);
            } catch (NumberFormatException e) {
                sop("Integer expected as ssn.");
            }
        }
        return null;
    }

    private static Driver addDriver() {
        String license_type, bankAccount, fname, lname, salary;
        int bankAccount_i = 0, salary_i = 0;
        sop("Bank account: ");
        bankAccount = input.nextLine();
        try {
            bankAccount_i = Integer.parseInt(bankAccount);
        } catch (NumberFormatException e) {
            sop("Integer expected.");
            return addDriver();
        }
        sop("Salary: ");
        salary = input.nextLine();
        try {
            salary_i = Integer.parseInt(salary);
        } catch (NumberFormatException e) {
            sop("Integer expected.");
            return addDriver();
        }
        sop("First name: ");
        fname = input.nextLine();
        sop("Last name: ");
        lname = input.nextLine();
        sop("Driver license type[0 or 1]: ");
        license_type = input.nextLine();
        if (!license_type.equals("1") && !license_type.equals("0")) {
            sop("Invalid license type given, expected 0 or 1.");
        } else if (fname.length() == 0) {
            sop("First name given empty");
        } else if (lname.length() == 0) {
            sop("Last name given empty");
        } else {
            try {
                return new Driver(Integer.valueOf(license_type), 0, new Worker(Helper.nextSsn(dbm), fname, lname, bankAccount_i, Helper.nowDateTime(), "", salary_i, -1, "Driver"));
            } catch (NumberFormatException e) {
                sop("Integer expected as ssn.");
            }
        }
        return null;
    }

    private static void printCommandsPanel2(User user) {
        sop("Commands:");
        if (user.permissionLevel() == 2) {
            sop("Delivery management: ");
            sop("\t`next` - Show the next batch of orders that can be delivered.");
            sop("\t`clear` - Clear taken orders.");
            sop("\t`acquire truck` - Fetch a truck for these orders if available.");
            sop("\t`release truck` - Release the lock on the truck acquired.");
            sop("\t`acquire driver` - Fetch a driver for the acquired truck if available.");
            sop("\t`release driver` - Release the lock on the driver acquired.");
            sop("\t`execute` - Initiate delivery simulation, adding logs and clearing resources.");


            sop("Orders handling(approve/disapprove): ");
            sop("\t`cancel order - Approve order cancellation`");
            sop("\t`disapprove cancel order - Approve order cancellation`");
            sop("\t`approve cancel order - Disapprove order cancellation`");

            sop("Resources management: ");

            sop("\t`show transports` - Show all transports made and their details.");
            sop("\t`show drivers` - Show all drivers and their details.");
            sop("\t`show trucks` - Show all trucks and their details.");
            sop("\t`show sites` - Show all sites their details.");

            sop("\t`add driver` - Adding driver.");
            sop("\t`add truck` - Adding truck.");
            sop("\t`add site` - Adding site.");

            sop("\t`del driver` - Deleting driver.");
            sop("\t`del truck` - Deleting truck.");
            sop("\t`del site` - Deleting site.");
        }
        sop("\t`help` - will reshow this panel");
        System.out.print("\t`exit` - exit the program\n");
    }

    private static void printInventoryMenu()
    {
        System.out.println("4  : Enter Discount");

    }
}
