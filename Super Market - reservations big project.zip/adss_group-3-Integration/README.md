# Team
- David zigler - 313375545
- Noa ben ami - 308409606
- Israel aviel fedida - 205652324
- Dor ohayon - 204450985
- Lynn Nabulsy - 319091401
- Sunders Bruskin - 205657406
- Naor Kolet - 205533060
- Liav Bachar – 205888472
- Chen Doytshman - 205644941

# Instructions
Instructions documents are within the docs folder.
But before you read them, please read this document first, **it clarify critical info.**

# The login takes time
Instead of inserting tons of shifts ahead, as we don't 
know how long it will take until the work will be checked.
Each time a user logs in we inserts demo shifts for all workers.
As result of that, a login might take about 2 seconds.

# 4 Users types
Due to the permissions systems we have many types of users:
1.  Logistics / Transports manager, username: aviel, password: 123456, this user alone can access transportation menu.
2.  HR / Workers manager, username: dor, password: 123456, any other user can enter the Worker menu but with different permissions.
3.  Inventory managers(stores managers) / Store keepers - both can access the inventory menu but with different permissions, to manage specific store check the users specified below.
4.  Suppliers - there are 3 employees we added that can handle interactions with suppliers, only these users can access this menu.

Stores managers details:

| username | password | store id |
| ------ | ------ |------ |
| aviel1 | 123456 |1|
| aviel4 | 123456 | 2|


Stores keepers details:

| username | password | store id |
| ------ | ------ | ------ |
| aviel2 | 123456 |1|
| aviel5 | 123456 | 2|


Suppliers workers:

| username | password |
| ------ | ------ |
| sup3 | 123456 |
| sup4 | 123456 |
| sup5 | 123456 |

Workers manager:

| username | password |
| ------ | ------ |
| dor | 123456 |


Transports manager:

| username | password |
| ------ | ------ |
| aviel | 123456 |

From here, rest of the usage is described within the instructions pdf file within the docs folder.

# Database filled data
The data.db file is already filled with plenty of diverse data.
The data should be suffice for few iterations of deliveries(different areas).
To restart the database we supplied 3 files within the folder Persistent_layer
 - creations.sql - contains DDL for the database.
 - inserts.sql - Data to fill the database with.
 - quaries.sql - contain the main query the algorithm uses + a query for updating shipment weights and final a query to delete all tables.
 - Restart procedure will use the last query within queries.sql to delete all tables, then we will use the DDL code from creations.sql and finally fill the database using the DML within inserts.sql.

# External jars used
 - junit-4.12
 - sqlite-jdbc-3.23.1
 - hamcrest-2.1