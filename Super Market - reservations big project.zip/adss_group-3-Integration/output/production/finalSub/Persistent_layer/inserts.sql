-- Static inserts assumed by the software exists in the database.

-- 12 Sites, 9 stores and 3 suppliers
insert into sites (address, phone, area, contact_name) values
('North 1', '135648899', 'N', 'Yaniv'),
('North 2', '165198499', 'N', 'Noa'),
('North 3', '165498499', 'N', 'Nir'),

('Merkaz 1', '165198465', 'M', 'Aviv'),
('Merkaz 2', '646464984', 'M', 'Hason'),
('Merkaz 3', '646464985', 'M', 'Rafy'),

('Darom 1', '135648888', 'D', 'David'),
('Darom 2', '135648887', 'D', 'Aviel'),
('Darom 3', '135648885', 'D', 'Dor'),

-- Suppliers
('Supplier site 1', '135648890', 'N','SUP1'),
('Supplier site 2', '135648891', 'M','SUP2'),
('Supplier site 3', '135648892', 'D','SUP3');

-- 4 Stores
insert into stores (id, site_id) values
(1, 'North 1'),
(2, 'North 2'),
(3, 'North 3'),

(4, 'Merkaz 1'),
(5, 'Merkaz 2'),
(6, 'Merkaz 3'),

(7, 'Darom 1'),
(8, 'Darom 2'),
(9, 'Darom 3');


insert into workers (worker_ssn, first_name, last_name, bankAcount, startDate,
					conditions, salary, storeId, job)
					values
-- 1 Workers manager
		('4876443', 'dor', 'qweqwe', '1513568', '2019-03-25 16:37:00', '', 50000, null,'workers manager'),
        -- 1 Workers manager
        ('4876449', 'aviel', 'qweqwe', '1513568', '2019-03-25 16:37:00', '', 50000, null,'transportations manager'),
-- 3 suppliers
        ('4876453', 'sup1', 'fsup1', '1513568', '2019-03-25 16:37:00', '', 50000, null,'sup3'),
          ('4876463', 'sup2', 'fsup2', '1513568', '2019-03-25 16:37:00', '', 50000, null,'sup4'),
          ('4876473', 'sup3', 'fsup3', '1513568', '2019-03-25 16:37:00', '', 50000, null,'sup5'),

-- 9 stores, so 27 workers, for each store, 1 manager, 1 regular workers, 1 storekeeper

-- Manager for storeid 1
					('1234564', 'aviel', 'ozan', '131313', '2019-03-25 16:37:00', '', 5000, 1,'store manager'),
-- Regular worker for storeid 1
					('423456', 'dor', 'abc', '313156', '2019-03-25 16:38:00', '', 3000, 1,'store keeper'),
-- Store keeper worker for storeid 1
					('2312456', 'miro', 'barbiro', '232313', '2019-03-25 16:39:00', '', 3500, 1,'food section'),
-- Store cashier for storeid 1
					('231244', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 1,'store cashier'),

-- Manager for storeid 2
					('5373582', 'mordi', 'fedida', '513513', '2019-03-25 16:40:00', '', 5000, 2,'store manager'),
-- Regular worker for storeid 2
					('6849', 'dor', 'abcd', '313156', '2019-03-25 16:41:00', '', 3000, 2,'store keeper'),
-- Store keeper worker for storeid 2
					('15135', 'uzi', 'barbiro', '232313', '2019-03-25 16:42:00', '', 3500, 2,'food section'),
-- Store cashier for storeid 2
					('124123', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 2,'store cashier'),


-- Manager for storeid 3
					('4635233', 'david', 'fedida', '46834234', '2019-03-25 16:43:00', '', 5000, 3,'store manager'),
-- Regular worker for storeid 3
					('215613', 'eli', 'rom', '13673538', '2019-03-25 16:44:00', '', 3000, 3,'store keeper'),
-- Store keeper worker for storeid 3
					('41313332', 'luna', 'barbiro', '708754', '2019-03-25 16:45:00', '', 3500, 3,'food section'),
-- Store cashier for storeid 3
					('1241234', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 3,'store cashier'),

-- Manager for storeid 4
					('1341309', 'eti', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 4,'store manager'),
-- Regular worker for storeid 4
					('96966690', 'eli', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 4,'store keeper'),
-- Store keeper worker for storeid 4
					('1357135', 'romi', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 4,'food section'),
-- Store cashier for storeid 3
					('1241232', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 4,'store cashier'),

-- Manager for storeid 5
					('13413095', 'eti5', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 5,'store manager'),
-- Regular worker for storeid 5
					('969666905', 'eli5', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 5,'store keeper'),
-- Store keeper worker for storeid 5
					('13571355', 'romi5', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 5,'food section'),
-- Store cashier for storeid 5
					('1241230', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 5,'store cashier'),

-- Manager for storeid 6
					('13413096', 'eti6', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 6,'store manager'),
-- Regular worker for storeid 6
					('969666906', 'eli6', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 6,'store keeper'),
-- Store keeper worker for storeid 6
					('13571356', 'romi6', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 6,'food section'),
-- Store cashier for storeid 6
					('1241239', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 6,'store cashier'),

-- Manager for storeid 7
					('13413097', 'eti7', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 7,'store manager'),
-- Regular worker for storeid 7
					('969666907', 'eli7', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 7,'store keeper'),
-- Store keeper worker for storeid 7
					('13571357', 'romi7', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 7,'food section'),
-- Store cashier for storeid 7
					('1241236', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 7,'store cashier'),

-- Manager for storeid 8
					('13413098', 'eti8', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 8,'store manager'),
-- Regular worker for storeid 8
					('969666908', 'eli8', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 8,'store keeper'),
-- Store keeper worker for storeid 8
					('13571358', 'romi8', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 8,'food section'),
-- Store cashier for storeid 8
					('12412355', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 8,'store cashier'),

-- Manager for storeid 9
					('13413099', 'eti9', 'fedida', '657242', '2019-03-25 16:46:00', '', 5000, 9,'store manager'),
-- Regular worker for storeid 9
					('969666909', 'eli9', 'ohana', '13513616', '2019-03-25 16:47:00', '', 3000, 9,'store keeper'),
-- Store keeper worker for storeid 9
					('13571359', 'romi9', 'barbiro', '16313513', '2019-03-25 16:48:00', '', 3500, 9,'food section'),
-- Store cashier for storeid 9
					('12412354', 'cash', 'know', '232313', '2019-03-25 16:39:00', '', 3500, 9,'store cashier'),



-- Now let's add 4 more workers that will be drivers. Note they are not linked into a specific store.
		('1001348', 'd1', 'd2', '88684', '2019-03-25 16:48:00', '', 4250, null,'driver'),

		('4757355', 'd3', 'd4', '42527', '2019-03-25 16:48:00', '', 4250, null,'driver'),

		('648385', 'd5', 'd6', '957562', '2019-03-25 16:48:00', '', 4250, null,'driver'),

		('423423', 'd7', 'd8', '2452575', '2019-03-25 16:48:00', '', 4250, null,'driver');


-- Stores managers
insert into stores_managers(ssn) values
('1234564'),
('5373582'),
('4635233'),
('1341309'),
('13413095'),
('13413096'),
('13413097'),
('13413098'),
('13413099');

-- Stores keepers
insert into storekeeper(ssn) values
('423456'),
('6849'),
('215613'),
('96966690'),
('969666905'),
('969666906'),
('969666907'),
('969666908'),
('969666909');



-- Stores cashiers
insert into stores_cashiers(ssn) values
('231244'),
('124123'),
('1241234'),
('1241232'),
('1241230'),
('1241239'),
('1241236'),
('12412355'),
('12412354');


-- 4 Drivers
insert into drivers (ssn, license_type, occupied) values
('1001348', 0, 0),
('4757355', 1, 0),
('648385', 0, 0),
('423423', 1, 0);

-- 1 Workers manager
-- 1 Transportation manager
insert into users (username, ssn, password, permissions) values
('dor', '4876443', '123456', 1),
('aviel', '4876449', '123456', 2),
('sup3', '4876453', '123456', 3),
('sup4', '4876463', '123456', 4),
('sup5', '4876473', '123456', 5),


-- 9 stores managers
('aviel1', '1234564', '123456', 0),
('aviel4', '5373582', '123456', 0),
('aviel7', '4635233', '123456', 0),
('aviel10', '1341309', '123456', 0),
('aviel13', '13413095', '123456', 0),
('aviel16', '13413096', '123456', 0),
('aviel19', '13413097', '123456', 0),
('aviel23', '13413098', '123456', 0),
('aviel26', '13413099', '123456', 0),


-- 9 Store keepers
('aviel2', '423456', '123456', 0),
('aviel17', '969666906', '123456', 0),
('aviel5', '6849', '123456', 0),
('aviel8', '215613', '123456', 0),
('aviel11', '96966690', '123456', 0),
('aviel14', '969666905', '123456', 0),
('aviel21', '969666907', '123456', 0),
('aviel24', '969666908', '123456', 0),
('aviel27', '969666909', '123456', 0),



-- 9 Regular store workers
('aviel3', '2312456', '123456', 0),
('aviel6', '15135', '123456', 0),
('aviel9', '41313332', '123456', 0),
('aviel12', '1357135', '123456', 0),
('aviel15', '13571355', '123456', 0),
('aviel18', '13571356', '123456', 0),
('aviel22', '13571357', '123456', 0),
('aviel25', '13571358', '123456', 0),
('aviel20', '13571359', '123456', 0),


-- 9 cashiers
('aviel32', '231244', '123456', 0),
('aviel33', '124123', '123456', 0),
('aviel34', '1241234', '123456', 0),
('aviel35', '1241232', '123456', 0),
('aviel36', '1241230', '123456', 0),
('aviel37', '1241239', '123456', 0),
('aviel38', '1241236', '123456', 0),
('aviel39', '12412355', '123456', 0),
('aviel40', '12412354', '123456', 0),



-- 4 drivers users
('aviel28', '1001348', '123456', 0),
('aviel29', '4757355', '123456', 0),
('aviel30', '648385', '123456', 0),
('aviel31', '423423', '123456', 0);


-- 3 Suppliers
insert into suppliers (id,Bank_account,Payment_terms,Delivery_routine, site_id) values
(3, 123, 'Term 1', 0, 'Supplier site 1'),
(4, 132, 'Term 2', 1,'Supplier site 2'),
(5, 312, 'Term 3', 2,'Supplier site 3');

-- 4 Trucks, remember weights are in Kilograms
insert into trucks (plate_id, model, net_weight, max_weight, occupied) values
('7986548', 2010, 5000, 12000, 0),
('4256564', 2011, 6000, 15000, 0),
('5256563', 2012, 6000, 12000, 0),
('6256561', 2013, 6000, 15000, 0);

-- 4 Categories
INSERT INTO Categories (CID,FID,Name,end_date,my_discount,current_discount) values
(0,0,'Main_Root',NULL,0,0),
(1,0,'Diary',NULL,0,0),
(2,1,'Milk',NULL,0,0),
(3,1,'Cheese',NULL,0,0);

-- 5 Products
INSERT INTO products (
id,
name,
st_amount,
sh_amount,
last_category,
minimal_amount,
location,
store_num,
producer,
selling_cost,
weight,
discount_cost,
end_discount)
values
(1,'Milk 3%',123,300,2,100,'42A',1,'Tnuva',10, 5, NULL, NULL),
(2,'Milk 3%',20,90,2,100,'42B',1,'Yotvata',30, 3, NULL, NULL),
(3,'Emek 28%',11,38,3,70,'32F',2,'Yotvata',25, 4, 10, '2019-08-02'),
(4,'Emek 9%',5,40,3,20,'31F',2,'Tnuva',25, 6, 30,'2019-08-02'),
(5,'Milk 3%',21,94,2,100,'64B',2,'Yotvata', 7, 30, NULL, NULL);


insert into orders (sid, store_num, date, start_handle_after_days) values
(3, 1, '2019-01-02 16:37:00', 13),
(3, 2, '2019-01-03 16:37:00', 16),
(3, 3, '2019-01-04 16:37:00', 18),

(4, 4, '2019-01-05 16:37:00', 16),
(4, 5, '2019-01-06 16:37:00', 14),
(4, 6, '2019-01-07 16:37:00', 16),

(5, 7, '2019-01-08 16:37:00', 15),
(5, 8, '2019-01-09 16:37:00', 13),
(5, 9, '2019-06-09 16:37:00', 11),

(3, 1, '2019-06-08 16:37:00', 12),
(3, 2, '2019-06-07 16:37:00', 14),
(3, 3, '2019-06-06 16:37:00', 18),

(4, 4, '2019-06-05 16:37:00', 16),
(4, 5, '2019-06-04 16:37:00', 14),
(4, 6, '2019-06-03 16:37:00', 12),

(5, 7, '2019-06-02 16:37:00', 11),
(5, 8, '2019-03-07 16:37:00', 13),
(5, 9, '2019-03-06 16:37:00', 15),

(3, 1, '2019-03-05 16:37:00', 12),
(3, 2, '2019-03-03 16:37:00', 13),
(3, 3, '2019-03-08 16:37:00', 16),

(4, 4, '2019-03-09 16:37:00', 17),
(4, 5, '2019-03-04 16:37:00', 15),
(4, 6, '2019-03-02 16:37:00', 16);

insert into products_at_orders (sid, store_num, date, product_id, amount, price_per_unit) values
(3, 1, '2019-01-02 16:37:00', 3, 180, 3.3),
(3, 1, '2019-01-02 16:37:00', 4, 230, 4.3),

(3, 2, '2019-01-03 16:37:00', 1, 120, 3.1),
(3, 2, '2019-01-03 16:37:00', 2, 150, 3.2),

(3, 3, '2019-01-04 16:37:00', 3, 220, 3.4),
(3, 3, '2019-01-04 16:37:00', 5, 230, 5.3),

(4, 4, '2019-01-05 16:37:00', 3, 230, 2.5),
(4, 4, '2019-01-05 16:37:00', 2, 180, 5.1),

(4, 5, '2019-01-06 16:37:00', 3, 200, 2.7),
(4, 5, '2019-01-06 16:37:00', 1, 100, 7.3),

(4, 6, '2019-01-07 16:37:00', 2, 100, 2.4),
(4, 6, '2019-01-07 16:37:00', 3, 220, 4.3),

(5, 7, '2019-01-08 16:37:00', 5, 100, 6.3),
(5, 7, '2019-01-08 16:37:00', 4, 220, 2.9),

(5, 8, '2019-01-09 16:37:00', 3, 220, 1.1),
(5, 8, '2019-01-09 16:37:00', 1, 230, 2.2),

(5, 9, '2019-06-09 16:37:00', 3, 110, 4.3),
(5, 9, '2019-06-09 16:37:00', 4, 205, 3.3),

(3, 1, '2019-06-08 16:37:00', 1, 100, 5.6),
(3, 1, '2019-06-08 16:37:00', 2, 210, 6.4),

(3, 2, '2019-06-07 16:37:00', 3, 220, 4.6),
(3, 2, '2019-06-07 16:37:00', 5, 230, 4.8),

(3, 3, '2019-06-06 16:37:00', 3, 130, 8.3),
(3, 3, '2019-06-06 16:37:00', 2, 170, 11.3),

(4, 4, '2019-06-05 16:37:00', 3, 140, 2.3),
(4, 4, '2019-06-05 16:37:00', 1, 100, 3.3),

(4, 5, '2019-06-04 16:37:00', 2, 210, 5.3),
(4, 5, '2019-06-04 16:37:00', 3, 90, 3.5),

(4, 6, '2019-06-03 16:37:00', 5, 210, 3.7),
(4, 6, '2019-06-03 16:37:00', 4, 205, 7.3),

(5, 7, '2019-06-02 16:37:00', 3, 210, 1.2),
(5, 7, '2019-06-02 16:37:00', 1, 220, 2.4),

(5, 8, '2019-03-07 16:37:00', 3, 210, 9.3),
(5, 8, '2019-03-07 16:37:00', 4, 220, 3.9),

(5, 9, '2019-03-06 16:37:00', 1, 210, 9.4),
(5, 9, '2019-03-06 16:37:00', 2, 205, 5.7),

(3, 1, '2019-03-05 16:37:00', 3, 210, 8.1),
(3, 1, '2019-03-05 16:37:00', 5, 220, 1.8),

(3, 2, '2019-03-03 16:37:00', 3, 180, 4.2),
(3, 2, '2019-03-03 16:37:00', 2, 170, 2.1),

(3, 3, '2019-03-08 16:37:00', 3, 130, 7.7),
(3, 3, '2019-03-08 16:37:00', 1, 220, 7.8),

(4, 4, '2019-03-09 16:37:00', 2, 250, 8.9),
(4, 4, '2019-03-09 16:37:00', 3, 170, 9.5),

(4, 5, '2019-03-04 16:37:00', 5, 175, 1.3),
(4, 5, '2019-03-04 16:37:00', 4, 185, 3.2),

(4, 6, '2019-03-02 16:37:00', 3, 145, 6.6),
(4, 6, '2019-03-02 16:37:00', 1, 210, 5.5);


-- 3 Selling
INSERT INTO Sellings
                (receipt_ID,PID,store_num,buy_price,sell_price,amount) values
                (0,3,1,10,23,5),
                (1,3,5,10,23,3),
                (2,2,9,15,30,7);

-- 1 Damaged product
INSERT INTO Damaged_products (PID,store_num,location,amount) values (5,1,'64B',4);

-- 1 Agreement
INSERT INTO Agreements
                (supplier_id,product_id,prod_price,discount_thres,discount_percent) values
                (3,3,100.0,100,50.0),
                (4,3,100.0,200,50.0),
                (5,1,70.0,30,20.0),
                (3,1,40.0,90,40.0),
                (4,2,170.0,10,80.0),
                (5,2,20.0,120,30.0),
                (3,4,20.0,120,30.0),
                (4,5,90.0,400,20.0);


INSERT INTO Supply_Days (SID,Day) values
  (3,2),
  (4,6);

