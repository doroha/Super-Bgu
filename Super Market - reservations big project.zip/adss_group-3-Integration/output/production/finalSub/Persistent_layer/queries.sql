-- Increase specific order amount
update products_at_orders set amount = amount * 5 where date = '2019-03-28 16:37:00' and store_num = 2 and sid = 1;


-- Test query for shifts
select ssn, date, shift_type, storeId, job from
((select storekeeper.ssn, date, shift_type from
shifts inner join storekeeper on shifts.ssn = storekeeper.ssn) as storekeepers
 inner join workers on storekeepers.ssn = workers.worker_ssn) as fullsk;

-- No workers constraints
update workers_availability set
day1=3,
day2=3,
day3=3,
day4=3,
day5=3,
day6=3,
day7=3;



-- Delete all tables + views
PRAGMA writable_schema = 1;
delete from sqlite_master where type in ('table', 'index', 'trigger', 'view');
PRAGMA writable_schema = 0;


